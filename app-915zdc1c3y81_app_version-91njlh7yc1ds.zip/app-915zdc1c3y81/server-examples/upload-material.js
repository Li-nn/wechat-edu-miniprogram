/**
 * 阿里云服务器上传资料示例
 * 
 * 使用方法：
 * 1. 安装依赖: npm install @supabase/supabase-js
 * 2. 配置环境变量（见下方）
 * 3. 运行: node upload-material.js
 */

const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const path = require('path');

// ==================== 配置信息 ====================
// 请从小程序项目的 .env 文件中获取这些信息
const SUPABASE_URL = process.env.SUPABASE_URL || '你的Supabase项目URL';
const SERVICE_ROLE_KEY = process.env.SERVICE_ROLE_KEY || '你的SERVICE_ROLE_KEY';
const APP_ID = 'app-915zdc1c3y81';

// 初始化 Supabase 客户端
const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

// ==================== 工具函数 ====================

/**
 * 上传单个资料
 */
async function uploadMaterial(options) {
  const {
    title,
    description,
    coverImagePath,
    filePath,
    categoryId
  } = options;

  console.log(`\n开始上传资料: ${title}`);
  console.log('='.repeat(50));

  try {
    // 1. 上传封面图片
    console.log('步骤 1/3: 上传封面图片...');
    const coverExt = path.extname(coverImagePath).slice(1);
    const coverFileName = `material_cover_${Date.now()}.${coverExt}`;
    const coverFile = fs.readFileSync(coverImagePath);
    
    const { data: coverData, error: coverError } = await supabase.storage
      .from(`${APP_ID}_images`)
      .upload(coverFileName, coverFile, {
        contentType: `image/${coverExt}`,
        upsert: false
      });

    if (coverError) {
      throw new Error(`封面上传失败: ${coverError.message}`);
    }

    const { data: coverUrlData } = supabase.storage
      .from(`${APP_ID}_images`)
      .getPublicUrl(coverFileName);

    console.log(`✓ 封面上传成功`);
    console.log(`  URL: ${coverUrlData.publicUrl}`);

    // 2. 上传资料文件
    console.log('\n步骤 2/3: 上传资料文件...');
    const fileExt = path.extname(filePath).slice(1);
    const fileName = `material_${Date.now()}.${fileExt}`;
    const file = fs.readFileSync(filePath);
    
    const contentTypeMap = {
      'pdf': 'application/pdf',
      'doc': 'application/msword',
      'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'xls': 'application/vnd.ms-excel',
      'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'ppt': 'application/vnd.ms-powerpoint',
      'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
    };

    const { data: fileData, error: fileError } = await supabase.storage
      .from(`${APP_ID}_files`)
      .upload(fileName, file, {
        contentType: contentTypeMap[fileExt] || 'application/octet-stream',
        upsert: false
      });

    if (fileError) {
      throw new Error(`文件上传失败: ${fileError.message}`);
    }

    const { data: fileUrlData } = supabase.storage
      .from(`${APP_ID}_files`)
      .getPublicUrl(fileName);

    console.log(`✓ 文件上传成功`);
    console.log(`  URL: ${fileUrlData.publicUrl}`);
    console.log(`  大小: ${(file.length / 1024).toFixed(2)} KB`);

    // 3. 创建资料记录
    console.log('\n步骤 3/3: 创建资料记录...');
    const { data: materialData, error: materialError } = await supabase
      .from('materials')
      .insert({
        title,
        description,
        cover_image: coverUrlData.publicUrl,
        file_url: fileUrlData.publicUrl,
        file_type: fileExt,
        category_id: categoryId,
        is_active: true
      })
      .select()
      .single();

    if (materialError) {
      throw new Error(`创建资料记录失败: ${materialError.message}`);
    }

    console.log(`✓ 资料记录创建成功`);
    console.log(`  ID: ${materialData.id}`);
    console.log('\n' + '='.repeat(50));
    console.log(`✓ 资料 "${title}" 上传完成！`);
    
    return {
      success: true,
      data: materialData
    };

  } catch (error) {
    console.error(`\n✗ 上传失败: ${error.message}`);
    return {
      success: false,
      error: error.message,
      title
    };
  }
}

/**
 * 批量上传资料
 */
async function batchUploadMaterials(materials) {
  console.log(`\n准备批量上传 ${materials.length} 个资料...`);
  console.log('='.repeat(50));
  
  const results = [];
  
  for (let i = 0; i < materials.length; i++) {
    console.log(`\n[${i + 1}/${materials.length}]`);
    const result = await uploadMaterial(materials[i]);
    results.push(result);
    
    // 避免请求过快，稍作延迟
    if (i < materials.length - 1) {
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
  
  // 统计结果
  const successCount = results.filter(r => r.success).length;
  const failCount = results.length - successCount;
  
  console.log('\n' + '='.repeat(50));
  console.log('批量上传完成！');
  console.log(`总计: ${results.length} 个`);
  console.log(`成功: ${successCount} 个`);
  console.log(`失败: ${failCount} 个`);
  
  if (failCount > 0) {
    console.log('\n失败列表:');
    results.filter(r => !r.success).forEach(r => {
      console.log(`  - ${r.title}: ${r.error}`);
    });
  }
  
  return results;
}

/**
 * 获取所有分类
 */
async function getCategories() {
  const { data, error } = await supabase
    .from('material_categories')
    .select('*')
    .order('name');
  
  if (error) {
    console.error('获取分类失败:', error.message);
    return [];
  }
  
  return data;
}

/**
 * 显示分类列表
 */
async function showCategories() {
  console.log('\n可用的资料分类:');
  console.log('='.repeat(50));
  
  const categories = await getCategories();
  
  if (categories.length === 0) {
    console.log('暂无分类');
    return;
  }
  
  categories.forEach((cat, index) => {
    console.log(`${index + 1}. ${cat.name}`);
    console.log(`   ID: ${cat.id}`);
  });
  
  console.log('='.repeat(50));
}

// ==================== 使用示例 ====================

// 示例1: 上传单个资料
async function example1() {
  await uploadMaterial({
    title: '小学数学上学期习题集',
    description: '涵盖小学数学上学期所有重点知识点，包含基础练习和拓展题目，适合课后巩固和考前复习。',
    coverImagePath: '/path/to/cover.jpg',  // 替换为实际路径
    filePath: '/path/to/document.pdf',      // 替换为实际路径
    categoryId: '22222222-2222-2222-2222-222222222221'  // 从分类列表中获取
  });
}

// 示例2: 批量上传资料
async function example2() {
  const materials = [
    {
      title: '小学数学第一单元习题',
      description: '第一单元重点习题集',
      coverImagePath: '/path/to/cover1.jpg',
      filePath: '/path/to/file1.pdf',
      categoryId: '22222222-2222-2222-2222-222222222221'
    },
    {
      title: '小学数学第二单元习题',
      description: '第二单元重点习题集',
      coverImagePath: '/path/to/cover2.jpg',
      filePath: '/path/to/file2.pdf',
      categoryId: '22222222-2222-2222-2222-222222222221'
    }
  ];
  
  await batchUploadMaterials(materials);
}

// ==================== 主函数 ====================

async function main() {
  console.log('教育资源小程序 - 服务器端上传工具');
  console.log('='.repeat(50));
  
  // 检查配置
  if (SUPABASE_URL.includes('你的') || SERVICE_ROLE_KEY.includes('你的')) {
    console.error('\n错误: 请先配置 SUPABASE_URL 和 SERVICE_ROLE_KEY');
    console.log('可以通过以下方式配置:');
    console.log('1. 设置环境变量:');
    console.log('   export SUPABASE_URL="你的URL"');
    console.log('   export SERVICE_ROLE_KEY="你的密钥"');
    console.log('2. 或直接修改本文件中的配置信息');
    return;
  }
  
  // 显示分类列表
  await showCategories();
  
  // 运行示例（取消注释以运行）
  // await example1();  // 单个上传
  // await example2();  // 批量上传
  
  console.log('\n提示: 请修改示例代码中的文件路径和分类ID后运行');
}

// 运行主函数
if (require.main === module) {
  main().catch(console.error);
}

// 导出函数供其他模块使用
module.exports = {
  uploadMaterial,
  batchUploadMaterials,
  getCategories,
  showCategories
};
