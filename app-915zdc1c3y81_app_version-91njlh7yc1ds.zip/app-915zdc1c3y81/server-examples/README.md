# 欢迎使用你的秒哒应用代码包
秒哒应用链接
    URL:https://www.miaoda.cn/projects/app-915zdc1c3y81

# 服务器端管理工具

本目录包含从阿里云服务器或其他外部服务器管理小程序后台的示例代码。

## 快速开始

### 1. 安装依赖

```bash
cd server-examples
npm install
```

### 2. 配置环境变量

创建 `.env` 文件：

```bash
SUPABASE_URL=你的Supabase项目URL
SERVICE_ROLE_KEY=你的SERVICE_ROLE_KEY
```

或者直接在命令行设置：

```bash
export SUPABASE_URL="你的Supabase项目URL"
export SERVICE_ROLE_KEY="你的SERVICE_ROLE_KEY"
```

### 3. 查看可用分类

```bash
npm run categories
```

### 4. 上传资料

编辑 `upload-material.js` 文件，修改示例代码中的文件路径和分类ID，然后运行：

```bash
npm run upload
```

### 5. 导出资料链接（用于公众号配置）

导出所有资料的小程序链接，用于配置微信公众号自动回复：

```bash
npm run export-links
```

这将生成两个文件：
- `资料链接列表.csv` - Excel可直接打开
- `资料链接列表.json` - JSON格式数据

每个资料都有独立的访问路径，格式为：
```
pages/material-detail/index?id=资料ID
```

**在公众号中使用**：
1. 打开生成的CSV文件
2. 复制对应资料的"小程序路径"
3. 在公众号后台配置关键词自动回复
4. 选择"小程序卡片"类型
5. 粘贴小程序路径（注意：路径前不要加 `/`）

## 文件说明

- `upload-material.js` - 主要的上传工具脚本
- `package.json` - 依赖配置
- `README.md` - 本文档

## 功能特性

- ✅ 单个资料上传
- ✅ 批量资料上传
- ✅ 自动上传封面图片和文件
- ✅ 错误处理和重试
- ✅ 上传进度显示
- ✅ 分类管理
- ✅ 导出资料链接（用于公众号配置）

## 使用示例

### 上传单个资料

```javascript
const { uploadMaterial } = require('./upload-material');

uploadMaterial({
  title: '小学数学上学期习题集',
  description: '涵盖小学数学上学期所有重点知识点',
  coverImagePath: '/path/to/cover.jpg',
  filePath: '/path/to/document.pdf',
  categoryId: '22222222-2222-2222-2222-222222222221'
});
```

### 批量上传资料

```javascript
const { batchUploadMaterials } = require('./upload-material');

const materials = [
  {
    title: '资料1',
    description: '描述1',
    coverImagePath: '/path/to/cover1.jpg',
    filePath: '/path/to/file1.pdf',
    categoryId: 'category-id'
  },
  {
    title: '资料2',
    description: '描述2',
    coverImagePath: '/path/to/cover2.jpg',
    filePath: '/path/to/file2.pdf',
    categoryId: 'category-id'
  }
];

batchUploadMaterials(materials);
```

## 注意事项

1. **安全性**: SERVICE_ROLE_KEY 拥有完全权限，请妥善保管
2. **文件大小**: 默认限制50MB，可在Supabase控制台调整
3. **并发控制**: 批量上传时会自动控制请求频率
4. **错误处理**: 上传失败会显示详细错误信息

## 支持的文件格式

- **图片**: JPG, PNG, GIF, WEBP
- **文档**: PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX

## 常见问题

### 1. 认证失败

检查 `SUPABASE_URL` 和 `SERVICE_ROLE_KEY` 是否正确配置。

### 2. 文件上传失败

- 检查文件路径是否正确
- 检查文件大小是否超过限制
- 检查网络连接

### 3. 找不到分类ID

运行 `npm run categories` 查看所有可用分类。

## 更多信息

详细的API文档请参考项目根目录的 `API_DOCUMENTATION.md` 文件。
