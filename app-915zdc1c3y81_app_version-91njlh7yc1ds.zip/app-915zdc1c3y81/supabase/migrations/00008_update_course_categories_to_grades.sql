/*
# 更新课程分类为年级分类

## 说明
将课程分类从原有的分类改为与资料页面一致的年级分类：
- 小五、小六、初一、初二、初三、高一、高二、高三

## 变更内容
1. 删除原有的课程分类数据
2. 插入新的年级分类数据
3. 保持与material_categories表一致的分类体系

## 注意
- 保留course_categories表结构不变
- 只更新数据内容
- 使用与material_categories相同的ID，便于统一管理
*/

-- 删除原有的课程分类数据
DELETE FROM course_categories;

-- 插入新的年级分类数据（与material_categories保持一致）
INSERT INTO course_categories (id, name, type, sort_order) VALUES
  ('22222222-2222-2222-2222-222222222221', '小五', 'recorded', 1),
  ('22222222-2222-2222-2222-222222222222', '小六', 'recorded', 2),
  ('22222222-2222-2222-2222-222222222223', '初一', 'recorded', 3),
  ('22222222-2222-2222-2222-222222222224', '初二', 'recorded', 4),
  ('22222222-2222-2222-2222-222222222225', '初三', 'recorded', 5),
  ('22222222-2222-2222-2222-222222222226', '高一', 'recorded', 6),
  ('22222222-2222-2222-2222-222222222227', '高二', 'recorded', 7),
  ('22222222-2222-2222-2222-222222222228', '高三', 'recorded', 8)
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  type = EXCLUDED.type,
  sort_order = EXCLUDED.sort_order;