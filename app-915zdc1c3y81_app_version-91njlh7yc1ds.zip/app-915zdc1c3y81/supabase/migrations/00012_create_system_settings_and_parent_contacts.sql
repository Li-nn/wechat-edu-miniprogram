/*
# 创建系统设置表和家长留资表

1. 新增表
    - `system_settings`
        - `id` (uuid, primary key, default: gen_random_uuid())
        - `admin_wechat` (text) - 管理员微信号
        - `wechat_qr_code` (text) - 微信二维码URL
        - `created_at` (timestamptz, default: now())
        - `updated_at` (timestamptz, default: now())
    
    - `parent_contacts`
        - `id` (uuid, primary key, default: gen_random_uuid())
        - `user_id` (uuid, references auth.users) - 用户ID（可选）
        - `parent_name` (text, not null) - 家长姓名
        - `phone` (text, not null) - 联系电话
        - `student_name` (text) - 学生姓名
        - `grade` (text) - 年级
        - `notes` (text) - 备注
        - `status` (text, default: 'pending') - 状态：pending/contacted/completed
        - `created_at` (timestamptz, default: now())

2. 安全策略
    - system_settings表：所有人可读，管理员可写
    - parent_contacts表：用户可创建自己的记录，管理员可查看所有记录

3. 初始数据
    - 插入一条默认的系统设置记录
*/

-- 创建系统设置表
CREATE TABLE IF NOT EXISTS system_settings (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    admin_wechat text,
    wechat_qr_code text,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- 创建家长留资表
CREATE TABLE IF NOT EXISTS parent_contacts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id),
    parent_name text NOT NULL,
    phone text NOT NULL,
    student_name text,
    grade text,
    notes text,
    status text DEFAULT 'pending' CHECK (status IN ('pending', 'contacted', 'completed')),
    created_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_parent_contacts_user_id ON parent_contacts(user_id);
CREATE INDEX IF NOT EXISTS idx_parent_contacts_status ON parent_contacts(status);
CREATE INDEX IF NOT EXISTS idx_parent_contacts_created_at ON parent_contacts(created_at DESC);

-- 启用RLS
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE parent_contacts ENABLE ROW LEVEL SECURITY;

-- system_settings策略：所有人可读
CREATE POLICY "Anyone can read system settings" ON system_settings
    FOR SELECT USING (true);

-- system_settings策略：管理员可写
CREATE POLICY "Admins can update system settings" ON system_settings
    FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- parent_contacts策略：用户可创建
CREATE POLICY "Users can create parent contacts" ON parent_contacts
    FOR INSERT WITH CHECK (true);

-- parent_contacts策略：管理员可查看所有
CREATE POLICY "Admins can view all parent contacts" ON parent_contacts
    FOR SELECT TO authenticated USING (is_admin(auth.uid()));

-- parent_contacts策略：用户可查看自己的
CREATE POLICY "Users can view own parent contacts" ON parent_contacts
    FOR SELECT USING (auth.uid() = user_id);

-- 插入默认系统设置
INSERT INTO system_settings (admin_wechat, wechat_qr_code)
VALUES ('', '')
ON CONFLICT DO NOTHING;
