/*
# 创建扣除积分的RPC函数

1. 功能
    - 扣除用户积分
    - 记录积分变动
    - 原子操作，确保数据一致性

2. 参数
    - p_user_id: 用户ID
    - p_amount: 扣除积分数量
    - p_reason: 扣除原因
*/

CREATE OR REPLACE FUNCTION deduct_user_points(
    p_user_id uuid,
    p_amount integer,
    p_reason text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- 检查用户积分是否足够
    IF (SELECT points FROM profiles WHERE id = p_user_id) < p_amount THEN
        RAISE EXCEPTION '积分不足';
    END IF;

    -- 扣除积分
    UPDATE profiles
    SET points = points - p_amount
    WHERE id = p_user_id;

    -- 记录积分变动
    INSERT INTO points_records (user_id, change_type, amount, reason)
    VALUES (p_user_id, 'spend', p_amount, p_reason);
END;
$$;
