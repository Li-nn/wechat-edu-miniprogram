/*
# 创建图片搜题专用存储桶

1. 创建存储桶
    - 名称：app-915zdc1c3y81_search_images
    - 公开访问：是
    - 文件大小限制：5MB

2. 安全策略
    - 所有认证用户可以上传图片
    - 所有人可以读取图片
*/

-- 创建存储桶
INSERT INTO storage.buckets (id, name, public, file_size_limit)
VALUES ('app-915zdc1c3y81_search_images', 'app-915zdc1c3y81_search_images', true, 5242880)
ON CONFLICT (id) DO NOTHING;

-- 允许认证用户上传
CREATE POLICY "Authenticated users can upload search images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'app-915zdc1c3y81_search_images');

-- 允许所有人读取
CREATE POLICY "Anyone can read search images"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'app-915zdc1c3y81_search_images');

-- 允许用户删除自己上传的图片
CREATE POLICY "Users can delete own search images"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'app-915zdc1c3y81_search_images' AND owner = auth.uid());
