/*
# 创建用户表和认证系统

1. 新建表
   - `profiles` - 用户信息表
     - `id` (uuid, 主键, 关联auth.users)
     - `username` (text, 唯一)
     - `phone` (text, 唯一)
     - `openid` (text) - 微信openid，不设置唯一约束
     - `nickname` (text) - 昵称
     - `avatar` (text) - 头像URL
     - `role` (user_role, 默认'user') - 用户角色
     - `created_at` (timestamptz, 默认now())

2. 安全策略
   - 不启用RLS，允许所有用户访问
   - 创建管理员辅助函数
   - 创建自动同步触发器

3. 说明
   - 第一个注册用户自动成为管理员
   - 支持微信登录和用户名密码登录
   - openid字段不设置唯一约束，允许同一微信用户拥有多个账号
*/

CREATE TYPE user_role AS ENUM ('user', 'admin');

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  phone text UNIQUE,
  openid text,
  nickname text,
  avatar text,
  role user_role DEFAULT 'user'::user_role NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- 不启用RLS，允许所有用户访问
-- ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- 创建管理员检查函数
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- 创建自动同步用户触发器
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
  extracted_username text;
BEGIN
  SELECT COUNT(*) INTO user_count FROM profiles;
  
  -- 从email中提取用户名（去掉@miaoda.com或@wechat.login后缀）
  extracted_username := CASE
    WHEN NEW.email LIKE '%@miaoda.com' THEN REPLACE(NEW.email, '@miaoda.com', '')
    WHEN NEW.email LIKE '%@wechat.login' THEN NULL
    ELSE NEW.email
  END;
  
  -- 插入用户信息
  INSERT INTO public.profiles (id, username, phone, openid, nickname, role)
  VALUES (
    NEW.id,
    extracted_username,
    NEW.phone,
    COALESCE((NEW.raw_user_meta_data->>'openid')::text, NULL),
    COALESCE((NEW.raw_user_meta_data->>'nickname')::text, extracted_username),
    CASE WHEN user_count = 0 THEN 'admin'::public.user_role ELSE 'user'::public.user_role END
  );
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION handle_new_user();