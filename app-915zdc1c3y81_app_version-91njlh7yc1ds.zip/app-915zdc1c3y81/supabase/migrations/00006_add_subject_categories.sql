/*
# 添加学科分类功能

1. 新增表
   - subject_categories: 学科分类表
     - id (uuid, primary key)
     - name (text, not null) - 学科名称
     - sort_order (int) - 排序
     - created_at (timestamptz)

2. 修改表
   - materials: 添加subject_id字段关联学科

3. 初始数据
   - 插入9个学科：数学、物理、化学、英语、语文、生物、地理、政治、历史

4. 说明
   - 学科分类独立于年级分类，支持双维度筛选
   - 资料可以同时关联年级和学科
*/

-- 创建学科分类表
CREATE TABLE IF NOT EXISTS subject_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- 为materials表添加学科字段
ALTER TABLE materials ADD COLUMN IF NOT EXISTS subject_id uuid REFERENCES subject_categories(id) ON DELETE SET NULL;

-- 插入学科分类数据
INSERT INTO subject_categories (id, name, sort_order) VALUES
  ('44444444-4444-4444-4444-444444444441', '数学', 1),
  ('44444444-4444-4444-4444-444444444442', '物理', 2),
  ('44444444-4444-4444-4444-444444444443', '化学', 3),
  ('44444444-4444-4444-4444-444444444444', '英语', 4),
  ('44444444-4444-4444-4444-444444444445', '语文', 5),
  ('44444444-4444-4444-4444-444444444446', '生物', 6),
  ('44444444-4444-4444-4444-444444444447', '地理', 7),
  ('44444444-4444-4444-4444-444444444448', '政治', 8),
  ('44444444-4444-4444-4444-444444444449', '历史', 9)
ON CONFLICT (id) DO NOTHING;
