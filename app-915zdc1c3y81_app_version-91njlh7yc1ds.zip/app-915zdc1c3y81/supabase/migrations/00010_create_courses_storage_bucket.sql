/*
# 创建课程存储桶

## 说明
为课程视频和封面图片创建Supabase Storage存储桶。

## 变更内容
1. 创建courses存储桶（app-915zdc1c3y81_courses）
2. 设置为公开访问
3. 配置文件大小限制：100MB
4. 支持的文件类型：视频（mp4, mov, avi等）和图片（jpg, png, webp）

## 注意
- 存储桶名称包含应用ID前缀
- 公开访问便于前端直接播放视频
- 文件大小限制100MB，超过建议使用第三方平台链接
*/

-- 创建课程存储桶
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'app-915zdc1c3y81_courses',
  'app-915zdc1c3y81_courses',
  true,
  104857600, -- 100MB in bytes
  ARRAY[
    'video/mp4',
    'video/quicktime',
    'video/x-msvideo',
    'video/x-matroska',
    'image/jpeg',
    'image/png',
    'image/webp'
  ]
)
ON CONFLICT (id) DO NOTHING;