/*
# 创建图片搜题相关表

1. 新增表
    - `image_search_records`
        - `id` (uuid, primary key, default: gen_random_uuid())
        - `user_id` (uuid, references auth.users, not null) - 用户ID
        - `image_url` (text, not null) - 搜题图片URL
        - `answer` (text) - AI解答内容
        - `created_at` (timestamptz, default: now())
    
    - `daily_image_search_limits`
        - `id` (uuid, primary key, default: gen_random_uuid())
        - `user_id` (uuid, references auth.users, not null) - 用户ID
        - `date` (date, not null) - 日期
        - `count` (integer, default: 0) - 当天使用次数
        - `created_at` (timestamptz, default: now())
        - UNIQUE(user_id, date)

2. 安全策略
    - image_search_records表：用户可查看自己的记录，管理员可查看所有记录
    - daily_image_search_limits表：用户可查看和更新自己的记录

3. 索引
    - 为user_id和date创建索引以提高查询性能
*/

-- 创建图片搜题记录表
CREATE TABLE IF NOT EXISTS image_search_records (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id) NOT NULL,
    image_url text NOT NULL,
    answer text,
    created_at timestamptz DEFAULT now()
);

-- 创建每日使用次数限制表
CREATE TABLE IF NOT EXISTS daily_image_search_limits (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id) NOT NULL,
    date date NOT NULL,
    count integer DEFAULT 0,
    created_at timestamptz DEFAULT now(),
    UNIQUE(user_id, date)
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_image_search_records_user_id ON image_search_records(user_id);
CREATE INDEX IF NOT EXISTS idx_image_search_records_created_at ON image_search_records(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_daily_image_search_limits_user_date ON daily_image_search_limits(user_id, date);

-- 启用RLS
ALTER TABLE image_search_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_image_search_limits ENABLE ROW LEVEL SECURITY;

-- image_search_records策略：用户可查看自己的记录
CREATE POLICY "Users can view own image search records" ON image_search_records
    FOR SELECT USING (auth.uid() = user_id);

-- image_search_records策略：用户可创建自己的记录
CREATE POLICY "Users can create own image search records" ON image_search_records
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- image_search_records策略：管理员可查看所有记录
CREATE POLICY "Admins can view all image search records" ON image_search_records
    FOR SELECT TO authenticated USING (is_admin(auth.uid()));

-- daily_image_search_limits策略：用户可查看自己的限制
CREATE POLICY "Users can view own daily limits" ON daily_image_search_limits
    FOR SELECT USING (auth.uid() = user_id);

-- daily_image_search_limits策略：用户可创建和更新自己的限制
CREATE POLICY "Users can manage own daily limits" ON daily_image_search_limits
    FOR ALL USING (auth.uid() = user_id);
