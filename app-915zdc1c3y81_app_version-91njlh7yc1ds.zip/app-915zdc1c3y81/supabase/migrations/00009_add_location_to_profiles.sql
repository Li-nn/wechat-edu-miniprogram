/*
# 为用户表添加定位信息字段

## 说明
为profiles表添加城市定位相关字段，用于记录用户的位置信息和登录历史。

## 变更内容
1. 添加city字段：存储用户当前城市
2. 添加last_login_city字段：记录最后登录城市
3. 添加last_login_time字段：记录最后登录时间
4. 添加ip_address字段：记录IP地址（可选）

## 注意
- 所有字段都是可选的（nullable）
- 不影响现有数据
*/

-- 添加城市定位相关字段
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS city text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS last_login_city text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS last_login_time timestamptz;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS ip_address text;