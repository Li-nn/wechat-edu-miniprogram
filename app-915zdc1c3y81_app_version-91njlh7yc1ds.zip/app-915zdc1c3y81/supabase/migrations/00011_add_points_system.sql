/*
# 积分系统

1. 修改表
   - `profiles` 表添加 `points` 字段

2. 新建表
   - `points_records` 积分变动记录表
     - `id` (uuid, primary key)
     - `user_id` (uuid, references profiles.id)
     - `change_type` (text, 'earn' 或 'spend')
     - `amount` (integer, 积分数量)
     - `reason` (text, 变动原因: 'daily_login', 'share', 'download')
     - `created_at` (timestamptz)
   
   - `daily_points_summary` 每日积分汇总表
     - `id` (uuid, primary key)
     - `user_id` (uuid, references profiles.id)
     - `date` (date, 日期)
     - `earned_today` (integer, 今日已获得积分)
     - `has_daily_login` (boolean, 是否已领取每日登录奖励)
     - `created_at` (timestamptz)
     - unique(user_id, date)

3. 业务规则
   - 下载资料消耗5积分
   - 每日首次登录获得10积分
   - 每次分享获得10积分
   - 每日获得积分上限20积分

4. RPC函数
   - check_and_grant_daily_login: 检查并发放每日登录奖励
   - grant_share_points: 发放分享积分（检查每日上限）
   - deduct_download_points: 扣除下载积分
*/

-- 1. 为profiles表添加积分字段
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS points integer DEFAULT 0 NOT NULL;

-- 2. 创建积分变动记录表
CREATE TABLE IF NOT EXISTS points_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  change_type text NOT NULL CHECK (change_type IN ('earn', 'spend')),
  amount integer NOT NULL,
  reason text NOT NULL CHECK (reason IN ('daily_login', 'share', 'download')),
  created_at timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_points_records_user_id ON points_records(user_id);
CREATE INDEX IF NOT EXISTS idx_points_records_created_at ON points_records(created_at);

-- 3. 创建每日积分汇总表
CREATE TABLE IF NOT EXISTS daily_points_summary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  date date NOT NULL,
  earned_today integer DEFAULT 0 NOT NULL,
  has_daily_login boolean DEFAULT false NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(user_id, date)
);

CREATE INDEX IF NOT EXISTS idx_daily_points_summary_user_date ON daily_points_summary(user_id, date);

-- 4. RPC: 检查并发放每日登录奖励
CREATE OR REPLACE FUNCTION check_and_grant_daily_login(uid uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  today_date date := CURRENT_DATE;
  summary_record RECORD;
  new_points integer;
  result json;
BEGIN
  -- 获取或创建今日汇总记录
  SELECT * INTO summary_record
  FROM daily_points_summary
  WHERE user_id = uid AND date = today_date;
  
  -- 如果今日记录不存在，创建新记录
  IF NOT FOUND THEN
    INSERT INTO daily_points_summary (user_id, date, earned_today, has_daily_login)
    VALUES (uid, today_date, 0, false)
    RETURNING * INTO summary_record;
  END IF;
  
  -- 检查是否已领取每日登录奖励
  IF summary_record.has_daily_login THEN
    RETURN json_build_object(
      'success', false,
      'message', '今日已领取登录奖励',
      'points', 0
    );
  END IF;
  
  -- 检查今日积分是否已达上限
  IF summary_record.earned_today >= 20 THEN
    RETURN json_build_object(
      'success', false,
      'message', '今日积分已达上限',
      'points', 0
    );
  END IF;
  
  -- 计算可获得的积分（不超过每日上限）
  new_points := LEAST(10, 20 - summary_record.earned_today);
  
  -- 更新用户积分
  UPDATE profiles
  SET points = points + new_points
  WHERE id = uid;
  
  -- 记录积分变动
  INSERT INTO points_records (user_id, change_type, amount, reason)
  VALUES (uid, 'earn', new_points, 'daily_login');
  
  -- 更新每日汇总
  UPDATE daily_points_summary
  SET earned_today = earned_today + new_points,
      has_daily_login = true
  WHERE user_id = uid AND date = today_date;
  
  RETURN json_build_object(
    'success', true,
    'message', '登录奖励领取成功',
    'points', new_points
  );
END;
$$;

-- 5. RPC: 发放分享积分
CREATE OR REPLACE FUNCTION grant_share_points(uid uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  today_date date := CURRENT_DATE;
  summary_record RECORD;
  new_points integer;
BEGIN
  -- 获取或创建今日汇总记录
  SELECT * INTO summary_record
  FROM daily_points_summary
  WHERE user_id = uid AND date = today_date;
  
  IF NOT FOUND THEN
    INSERT INTO daily_points_summary (user_id, date, earned_today, has_daily_login)
    VALUES (uid, today_date, 0, false)
    RETURNING * INTO summary_record;
  END IF;
  
  -- 检查今日积分是否已达上限
  IF summary_record.earned_today >= 20 THEN
    RETURN json_build_object(
      'success', false,
      'message', '今日积分已达上限',
      'points', 0
    );
  END IF;
  
  -- 计算可获得的积分（不超过每日上限）
  new_points := LEAST(10, 20 - summary_record.earned_today);
  
  -- 更新用户积分
  UPDATE profiles
  SET points = points + new_points
  WHERE id = uid;
  
  -- 记录积分变动
  INSERT INTO points_records (user_id, change_type, amount, reason)
  VALUES (uid, 'earn', new_points, 'share');
  
  -- 更新每日汇总
  UPDATE daily_points_summary
  SET earned_today = earned_today + new_points
  WHERE user_id = uid AND date = today_date;
  
  RETURN json_build_object(
    'success', true,
    'message', '分享奖励领取成功',
    'points', new_points
  );
END;
$$;

-- 6. RPC: 扣除下载积分
CREATE OR REPLACE FUNCTION deduct_download_points(uid uuid, material_id_param uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  user_points integer;
  cost integer := 5;
BEGIN
  -- 获取用户当前积分
  SELECT points INTO user_points
  FROM profiles
  WHERE id = uid;
  
  -- 检查积分是否足够
  IF user_points < cost THEN
    RETURN json_build_object(
      'success', false,
      'message', '积分不足，需要' || cost || '积分',
      'current_points', user_points,
      'required_points', cost
    );
  END IF;
  
  -- 扣除积分
  UPDATE profiles
  SET points = points - cost
  WHERE id = uid;
  
  -- 记录积分变动
  INSERT INTO points_records (user_id, change_type, amount, reason)
  VALUES (uid, 'spend', cost, 'download');
  
  RETURN json_build_object(
    'success', true,
    'message', '下载成功，消耗' || cost || '积分',
    'points_spent', cost,
    'remaining_points', user_points - cost
  );
END;
$$;

-- 7. 设置RLS策略
ALTER TABLE points_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_points_summary ENABLE ROW LEVEL SECURITY;

-- 用户可以查看自己的积分记录
CREATE POLICY "Users can view own points records" ON points_records
  FOR SELECT USING (auth.uid() = user_id);

-- 用户可以查看自己的每日汇总
CREATE POLICY "Users can view own daily summary" ON daily_points_summary
  FOR SELECT USING (auth.uid() = user_id);

-- 管理员可以查看所有记录
CREATE POLICY "Admins can view all points records" ON points_records
  FOR SELECT USING (is_admin(auth.uid()));

CREATE POLICY "Admins can view all daily summaries" ON daily_points_summary
  FOR SELECT USING (is_admin(auth.uid()));