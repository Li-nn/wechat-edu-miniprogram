/*
# 创建业务表

1. 新建表
   - `banners` - 轮播图表
     - `id` (uuid, 主键)
     - `title` (text) - 标题
     - `image_url` (text) - 图片URL
     - `link_type` (text) - 链接类型：material/course/external
     - `link_id` (uuid) - 关联ID
     - `sort_order` (int) - 排序
     - `is_active` (boolean) - 是否启用
     - `created_at` (timestamptz)
   
   - `material_categories` - 资料分类表
     - `id` (uuid, 主键)
     - `name` (text) - 分类名称
     - `parent_id` (uuid) - 父分类ID
     - `sort_order` (int)
     - `created_at` (timestamptz)
   
   - `materials` - 资料表
     - `id` (uuid, 主键)
     - `title` (text) - 标题
     - `description` (text) - 描述
     - `cover_image` (text) - 封面图
     - `file_url` (text) - 文件URL
     - `file_type` (text) - 文件类型：pdf/doc/ppt
     - `category_id` (uuid) - 分类ID
     - `download_count` (int) - 下载次数
     - `view_count` (int) - 查看次数
     - `is_active` (boolean)
     - `created_at` (timestamptz)
   
   - `course_categories` - 课程分类表
     - `id` (uuid, 主键)
     - `name` (text) - 分类名称
     - `type` (text) - 类型：live/recorded
     - `sort_order` (int)
     - `created_at` (timestamptz)
   
   - `courses` - 课程表
     - `id` (uuid, 主键)
     - `title` (text) - 标题
     - `description` (text) - 描述
     - `cover_image` (text) - 封面图
     - `video_url` (text) - 视频URL
     - `preview_duration` (int) - 试看时长（秒）
     - `total_duration` (int) - 总时长（秒）
     - `category_id` (uuid) - 分类ID
     - `price` (decimal) - 价格
     - `view_count` (int) - 观看次数
     - `is_active` (boolean)
     - `created_at` (timestamptz)
   
   - `user_materials` - 用户资料领取记录
     - `id` (uuid, 主键)
     - `user_id` (uuid) - 用户ID
     - `material_id` (uuid) - 资料ID
     - `action_type` (text) - 操作类型：view/download/share
     - `created_at` (timestamptz)
   
   - `user_courses` - 用户课程观看记录
     - `id` (uuid, 主键)
     - `user_id` (uuid) - 用户ID
     - `course_id` (uuid) - 课程ID
     - `watch_duration` (int) - 观看时长（秒）
     - `is_purchased` (boolean) - 是否购买
     - `created_at` (timestamptz)
     - `updated_at` (timestamptz)
   
   - `consultations` - 咨询记录
     - `id` (uuid, 主键)
     - `user_id` (uuid) - 用户ID
     - `type` (text) - 咨询类型：wechat/phone
     - `created_at` (timestamptz)

2. 安全策略
   - 所有表不启用RLS，允许公开访问
*/

-- 轮播图表
CREATE TABLE IF NOT EXISTS banners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  image_url text NOT NULL,
  link_type text,
  link_id uuid,
  sort_order int DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- 资料分类表
CREATE TABLE IF NOT EXISTS material_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  parent_id uuid REFERENCES material_categories(id) ON DELETE CASCADE,
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- 资料表
CREATE TABLE IF NOT EXISTS materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  cover_image text,
  file_url text NOT NULL,
  file_type text NOT NULL,
  category_id uuid REFERENCES material_categories(id) ON DELETE SET NULL,
  download_count int DEFAULT 0,
  view_count int DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- 课程分类表
CREATE TABLE IF NOT EXISTS course_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL,
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- 课程表
CREATE TABLE IF NOT EXISTS courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  cover_image text,
  video_url text NOT NULL,
  preview_duration int DEFAULT 180,
  total_duration int DEFAULT 0,
  category_id uuid REFERENCES course_categories(id) ON DELETE SET NULL,
  price decimal(10,2) DEFAULT 0,
  view_count int DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- 用户资料领取记录
CREATE TABLE IF NOT EXISTS user_materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  material_id uuid REFERENCES materials(id) ON DELETE CASCADE,
  action_type text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- 用户课程观看记录
CREATE TABLE IF NOT EXISTS user_courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE,
  watch_duration int DEFAULT 0,
  is_purchased boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 咨询记录
CREATE TABLE IF NOT EXISTS consultations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  type text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- 创建索引提升查询性能
CREATE INDEX IF NOT EXISTS idx_materials_category ON materials(category_id);
CREATE INDEX IF NOT EXISTS idx_courses_category ON courses(category_id);
CREATE INDEX IF NOT EXISTS idx_user_materials_user ON user_materials(user_id);
CREATE INDEX IF NOT EXISTS idx_user_courses_user ON user_courses(user_id);