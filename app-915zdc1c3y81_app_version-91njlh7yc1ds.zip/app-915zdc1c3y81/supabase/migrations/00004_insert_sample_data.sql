/*
# 插入示例数据

1. 轮播图数据
2. 资料数据
3. 课程数据
*/

-- 插入轮播图数据
INSERT INTO banners (id, title, image_url, link_type, link_id, sort_order, is_active) VALUES
  ('44444444-4444-4444-4444-444444444441', '优质教育资源', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_431471b3-75bc-4bc9-b27e-55c66ae161a7.jpg', NULL, NULL, 1, true),
  ('44444444-4444-4444-4444-444444444442', '在线网课学习', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_89ddb541-fc80-4ff3-8eda-94539b516364.jpg', NULL, NULL, 2, true),
  ('44444444-4444-4444-4444-444444444443', '学习资料下载', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_6691a57d-199a-47a3-8b97-b3814584c3a2.jpg', NULL, NULL, 3, true);

-- 插入资料数据
INSERT INTO materials (id, title, description, cover_image, file_url, file_type, category_id, is_active) VALUES
  ('55555555-5555-5555-5555-555555555551', '小学数学上学期重点习题集', '涵盖小学数学上学期所有重点知识点，包含基础练习和拓展题目，适合课后巩固和考前复习。', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_0b9d3143-2acc-4dfa-95e8-e92996292c3e.jpg', 'https://example.com/math-primary.pdf', 'pdf', '22222222-2222-2222-2222-222222222221', true),
  ('55555555-5555-5555-5555-555555555552', '初中语文阅读理解专项训练', '精选初中语文阅读理解题目，配有详细解析，帮助学生提升阅读理解能力和答题技巧。', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_5baf69dd-bfc5-46ad-98f5-1aa84a981f02.jpg', 'https://example.com/chinese-reading.pdf', 'pdf', '22222222-2222-2222-2222-222222222223', true),
  ('55555555-5555-5555-5555-555555555553', '高中英语语法大全', '系统梳理高中英语语法知识点，包含大量例句和练习题，是英语学习的必备资料。', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_6444bb96-8273-410d-bec5-71dd46f4a930.jpg', 'https://example.com/english-grammar.pdf', 'pdf', '22222222-2222-2222-2222-222222222225', true);

-- 插入课程数据
INSERT INTO courses (id, title, description, cover_image, video_url, preview_duration, total_duration, category_id, price, is_active) VALUES
  ('66666666-6666-6666-6666-666666666661', '小学数学第一单元精讲', '名师讲解小学数学第一单元重点知识，通过生动的例题帮助学生理解和掌握核心概念。', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_6546562a-77c4-48f6-9d3b-60496c677dba.jpg', 'https://example.com/math-unit1.mp4', 180, 1800, '33333333-3333-3333-3333-333333333331', 99.00, true),
  ('66666666-6666-6666-6666-666666666662', '初中语文写作技巧提升', '资深语文老师传授写作技巧，从审题立意到结构布局，全面提升写作水平。', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_5c2a5238-9c7f-47a8-be80-c1568116fe34.jpg', 'https://example.com/chinese-writing.mp4', 180, 2400, '33333333-3333-3333-3333-333333333332', 129.00, true),
  ('66666666-6666-6666-6666-666666666663', '高中英语听力突破课程', '专业外教授课，通过大量听力练习和技巧讲解，快速提升英语听力水平。', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_6c47d3af-1677-48e8-90be-dfc8250c4e8a.jpg', 'https://example.com/english-listening.mp4', 180, 3000, '33333333-3333-3333-3333-333333333333', 149.00, true);