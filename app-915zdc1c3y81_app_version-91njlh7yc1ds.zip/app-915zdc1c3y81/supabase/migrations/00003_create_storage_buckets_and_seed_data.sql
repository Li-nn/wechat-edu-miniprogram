/*
# 创建存储桶和初始数据

1. 存储桶
   - `app-915zdc1c3y81_images` - 图片存储（Banner、封面等）
   - `app-915zdc1c3y81_files` - 文件存储（资料文件）

2. 初始数据
   - 资料分类（年级+学期+题型）
   - 课程分类（单元+类型）
   - 示例轮播图
   - 示例资料
   - 示例课程

3. 安全策略
   - 所有用户可以读取
   - 管理员可以上传和删除
*/

-- 创建图片存储桶
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'app-915zdc1c3y81_images',
  'app-915zdc1c3y81_images',
  true,
  1048576,
  ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp']
) ON CONFLICT (id) DO NOTHING;

-- 创建文件存储桶
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'app-915zdc1c3y81_files',
  'app-915zdc1c3y81_files',
  true,
  10485760,
  ARRAY['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation']
) ON CONFLICT (id) DO NOTHING;

-- 存储桶策略：所有人可读
CREATE POLICY "Public read access" ON storage.objects
  FOR SELECT USING (bucket_id IN ('app-915zdc1c3y81_images', 'app-915zdc1c3y81_files'));

-- 存储桶策略：所有人可上传
CREATE POLICY "Public upload access" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id IN ('app-915zdc1c3y81_images', 'app-915zdc1c3y81_files'));

-- 存储桶策略：所有人可删除
CREATE POLICY "Public delete access" ON storage.objects
  FOR DELETE USING (bucket_id IN ('app-915zdc1c3y81_images', 'app-915zdc1c3y81_files'));

-- 插入资料分类数据
INSERT INTO material_categories (id, name, parent_id, sort_order) VALUES
  ('11111111-1111-1111-1111-111111111111', '小学', NULL, 1),
  ('11111111-1111-1111-1111-111111111112', '初中', NULL, 2),
  ('11111111-1111-1111-1111-111111111113', '高中', NULL, 3),
  ('22222222-2222-2222-2222-222222222221', '上学期', '11111111-1111-1111-1111-111111111111', 1),
  ('22222222-2222-2222-2222-222222222222', '下学期', '11111111-1111-1111-1111-111111111111', 2),
  ('22222222-2222-2222-2222-222222222223', '上学期', '11111111-1111-1111-1111-111111111112', 1),
  ('22222222-2222-2222-2222-222222222224', '下学期', '11111111-1111-1111-1111-111111111112', 2),
  ('22222222-2222-2222-2222-222222222225', '上学期', '11111111-1111-1111-1111-111111111113', 1),
  ('22222222-2222-2222-2222-222222222226', '下学期', '11111111-1111-1111-1111-111111111113', 2);

-- 插入课程分类数据
INSERT INTO course_categories (id, name, type, sort_order) VALUES
  ('33333333-3333-3333-3333-333333333331', '第一单元', 'recorded', 1),
  ('33333333-3333-3333-3333-333333333332', '第二单元', 'recorded', 2),
  ('33333333-3333-3333-3333-333333333333', '第三单元', 'recorded', 3),
  ('33333333-3333-3333-3333-333333333334', '直播课程', 'live', 4);