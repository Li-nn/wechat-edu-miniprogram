/*
# 为课程表添加学科分类

1. 修改表
   - courses: 添加subject_id字段关联学科

2. 说明
   - 课程可以关联学科分类，支持按学科筛选
   - 与资料模块保持一致的分类体系
*/

-- 为courses表添加学科字段
ALTER TABLE courses ADD COLUMN IF NOT EXISTS subject_id uuid REFERENCES subject_categories(id) ON DELETE SET NULL;
