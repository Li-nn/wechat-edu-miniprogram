# 教育资源小程序 API 文档

## 概述

本文档说明如何从阿里云服务器或其他外部服务器连接到小程序后台，实现资料管理等功能。

## 认证方式

使用 Supabase 提供的 Service Role Key 进行服务端认证。

### 获取认证信息

在项目的 `.env` 文件中可以找到：
```
TARO_APP_SUPABASE_URL=你的Supabase项目URL
TARO_APP_SUPABASE_ANON_KEY=匿名密钥
TARO_APP_SUPABASE_SERVICE_ROLE_KEY=服务端密钥（管理员权限）
```

**重要提示：** Service Role Key 拥有完全权限，请妥善保管，不要泄露到客户端代码中。

## API 基础信息

- **Base URL**: `你的Supabase项目URL/rest/v1`
- **认证方式**: Bearer Token (使用 Service Role Key)
- **Content-Type**: `application/json`

## 常用 API 接口

### 1. 上传资料

#### 1.1 上传文件到存储桶

**接口**: `POST /storage/v1/object/{bucket_name}/{file_path}`

**Headers**:
```
Authorization: Bearer {SERVICE_ROLE_KEY}
Content-Type: multipart/form-data
```

**示例 - 上传封面图片**:
```bash
curl -X POST \
  'https://你的项目.supabase.co/storage/v1/object/app-915zdc1c3y81_images/material_cover_123.jpg' \
  -H 'Authorization: Bearer 你的SERVICE_ROLE_KEY' \
  -F 'file=@/path/to/image.jpg'
```

**示例 - 上传资料文件**:
```bash
curl -X POST \
  'https://你的项目.supabase.co/storage/v1/object/app-915zdc1c3y81_files/material_file_123.pdf' \
  -H 'Authorization: Bearer 你的SERVICE_ROLE_KEY' \
  -F 'file=@/path/to/document.pdf'
```

#### 1.2 创建资料记录

**接口**: `POST /rest/v1/materials`

**Headers**:
```
Authorization: Bearer {SERVICE_ROLE_KEY}
Content-Type: application/json
apikey: {SERVICE_ROLE_KEY}
Prefer: return=minimal
```

**请求体**:
```json
{
  "title": "小学数学上学期习题集",
  "description": "涵盖小学数学上学期所有重点知识点",
  "cover_image": "https://你的项目.supabase.co/storage/v1/object/public/app-915zdc1c3y81_images/material_cover_123.jpg",
  "file_url": "https://你的项目.supabase.co/storage/v1/object/public/app-915zdc1c3y81_files/material_file_123.pdf",
  "file_type": "pdf",
  "category_id": "分类ID",
  "is_active": true
}
```

**示例**:
```bash
curl -X POST \
  'https://你的项目.supabase.co/rest/v1/materials' \
  -H 'Authorization: Bearer 你的SERVICE_ROLE_KEY' \
  -H 'apikey: 你的SERVICE_ROLE_KEY' \
  -H 'Content-Type: application/json' \
  -H 'Prefer: return=minimal' \
  -d '{
    "title": "小学数学上学期习题集",
    "description": "涵盖小学数学上学期所有重点知识点",
    "cover_image": "https://example.com/cover.jpg",
    "file_url": "https://example.com/file.pdf",
    "file_type": "pdf",
    "category_id": "22222222-2222-2222-2222-222222222221",
    "is_active": true
  }'
```

### 2. 更新资料

**接口**: `PATCH /rest/v1/materials?id=eq.{资料ID}`

**Headers**:
```
Authorization: Bearer {SERVICE_ROLE_KEY}
Content-Type: application/json
apikey: {SERVICE_ROLE_KEY}
Prefer: return=minimal
```

**请求体**:
```json
{
  "title": "更新后的标题",
  "description": "更新后的描述",
  "is_active": true
}
```

**示例**:
```bash
curl -X PATCH \
  'https://你的项目.supabase.co/rest/v1/materials?id=eq.资料ID' \
  -H 'Authorization: Bearer 你的SERVICE_ROLE_KEY' \
  -H 'apikey: 你的SERVICE_ROLE_KEY' \
  -H 'Content-Type: application/json' \
  -H 'Prefer: return=minimal' \
  -d '{
    "title": "更新后的标题",
    "is_active": true
  }'
```

### 3. 删除资料

**接口**: `DELETE /rest/v1/materials?id=eq.{资料ID}`

**Headers**:
```
Authorization: Bearer {SERVICE_ROLE_KEY}
apikey: {SERVICE_ROLE_KEY}
```

**示例**:
```bash
curl -X DELETE \
  'https://你的项目.supabase.co/rest/v1/materials?id=eq.资料ID' \
  -H 'Authorization: Bearer 你的SERVICE_ROLE_KEY' \
  -H 'apikey: 你的SERVICE_ROLE_KEY'
```

### 4. 查询资料列表

**接口**: `GET /rest/v1/materials?select=*&is_active=eq.true`

**Headers**:
```
Authorization: Bearer {SERVICE_ROLE_KEY}
apikey: {SERVICE_ROLE_KEY}
```

**示例**:
```bash
curl -X GET \
  'https://你的项目.supabase.co/rest/v1/materials?select=*&is_active=eq.true' \
  -H 'Authorization: Bearer 你的SERVICE_ROLE_KEY' \
  -H 'apikey: 你的SERVICE_ROLE_KEY'
```

### 5. 获取分类列表

**接口**: `GET /rest/v1/material_categories?select=*`

**Headers**:
```
Authorization: Bearer {SERVICE_ROLE_KEY}
apikey: {SERVICE_ROLE_KEY}
```

**示例**:
```bash
curl -X GET \
  'https://你的项目.supabase.co/rest/v1/material_categories?select=*' \
  -H 'Authorization: Bearer 你的SERVICE_ROLE_KEY' \
  -H 'apikey: 你的SERVICE_ROLE_KEY'
```

## Node.js 示例代码

### 安装依赖

```bash
npm install @supabase/supabase-js form-data
```

### 完整示例：从阿里云服务器上传资料

```javascript
const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const FormData = require('form-data');

// 初始化 Supabase 客户端
const supabaseUrl = '你的Supabase项目URL';
const serviceRoleKey = '你的SERVICE_ROLE_KEY';
const supabase = createClient(supabaseUrl, serviceRoleKey);

// 上传资料的完整流程
async function uploadMaterial(options) {
  const {
    title,
    description,
    coverImagePath,  // 本地封面图片路径
    filePath,        // 本地资料文件路径
    categoryId
  } = options;

  try {
    // 1. 上传封面图片
    console.log('正在上传封面图片...');
    const coverFileName = `material_cover_${Date.now()}.jpg`;
    const coverFile = fs.readFileSync(coverImagePath);
    
    const { data: coverData, error: coverError } = await supabase.storage
      .from('app-915zdc1c3y81_images')
      .upload(coverFileName, coverFile, {
        contentType: 'image/jpeg'
      });

    if (coverError) {
      throw new Error(`封面上传失败: ${coverError.message}`);
    }

    // 获取封面公开URL
    const { data: coverUrlData } = supabase.storage
      .from('app-915zdc1c3y81_images')
      .getPublicUrl(coverFileName);

    console.log('封面上传成功:', coverUrlData.publicUrl);

    // 2. 上传资料文件
    console.log('正在上传资料文件...');
    const fileExt = filePath.split('.').pop();
    const fileName = `material_${Date.now()}.${fileExt}`;
    const file = fs.readFileSync(filePath);
    
    const { data: fileData, error: fileError } = await supabase.storage
      .from('app-915zdc1c3y81_files')
      .upload(fileName, file, {
        contentType: 'application/pdf'
      });

    if (fileError) {
      throw new Error(`文件上传失败: ${fileError.message}`);
    }

    // 获取文件公开URL
    const { data: fileUrlData } = supabase.storage
      .from('app-915zdc1c3y81_files')
      .getPublicUrl(fileName);

    console.log('文件上传成功:', fileUrlData.publicUrl);

    // 3. 创建资料记录
    console.log('正在创建资料记录...');
    const { data: materialData, error: materialError } = await supabase
      .from('materials')
      .insert({
        title,
        description,
        cover_image: coverUrlData.publicUrl,
        file_url: fileUrlData.publicUrl,
        file_type: fileExt,
        category_id: categoryId,
        is_active: true
      })
      .select()
      .single();

    if (materialError) {
      throw new Error(`创建资料记录失败: ${materialError.message}`);
    }

    console.log('资料上传完成！', materialData);
    return materialData;

  } catch (error) {
    console.error('上传失败:', error.message);
    throw error;
  }
}

// 使用示例
uploadMaterial({
  title: '小学数学上学期习题集',
  description: '涵盖小学数学上学期所有重点知识点，包含基础练习和拓展题目',
  coverImagePath: '/path/to/cover.jpg',
  filePath: '/path/to/document.pdf',
  categoryId: '22222222-2222-2222-2222-222222222221'  // 从分类列表中获取
}).then(() => {
  console.log('上传成功！');
}).catch((error) => {
  console.error('上传失败:', error);
});
```

### 批量上传示例

```javascript
// 批量上传多个资料
async function batchUploadMaterials(materials) {
  const results = [];
  
  for (const material of materials) {
    try {
      const result = await uploadMaterial(material);
      results.push({ success: true, data: result });
      console.log(`✓ ${material.title} 上传成功`);
    } catch (error) {
      results.push({ success: false, error: error.message, title: material.title });
      console.error(`✗ ${material.title} 上传失败:`, error.message);
    }
  }
  
  return results;
}

// 使用示例
const materialsToUpload = [
  {
    title: '小学数学第一单元',
    description: '第一单元习题集',
    coverImagePath: '/path/to/cover1.jpg',
    filePath: '/path/to/file1.pdf',
    categoryId: '22222222-2222-2222-2222-222222222221'
  },
  {
    title: '小学数学第二单元',
    description: '第二单元习题集',
    coverImagePath: '/path/to/cover2.jpg',
    filePath: '/path/to/file2.pdf',
    categoryId: '22222222-2222-2222-2222-222222222221'
  }
];

batchUploadMaterials(materialsToUpload).then((results) => {
  const successCount = results.filter(r => r.success).length;
  console.log(`\n批量上传完成: ${successCount}/${results.length} 成功`);
});
```

## Python 示例代码

```python
import os
from supabase import create_client, Client

# 初始化 Supabase 客户端
supabase_url = "你的Supabase项目URL"
service_role_key = "你的SERVICE_ROLE_KEY"
supabase: Client = create_client(supabase_url, service_role_key)

def upload_material(title, description, cover_image_path, file_path, category_id):
    """上传资料到小程序后台"""
    
    try:
        # 1. 上传封面图片
        print("正在上传封面图片...")
        cover_file_name = f"material_cover_{int(time.time())}.jpg"
        with open(cover_image_path, 'rb') as f:
            cover_result = supabase.storage.from_('app-915zdc1c3y81_images').upload(
                cover_file_name,
                f.read()
            )
        
        cover_url = supabase.storage.from_('app-915zdc1c3y81_images').get_public_url(cover_file_name)
        print(f"封面上传成功: {cover_url}")
        
        # 2. 上传资料文件
        print("正在上传资料文件...")
        file_ext = os.path.splitext(file_path)[1][1:]
        file_name = f"material_{int(time.time())}.{file_ext}"
        with open(file_path, 'rb') as f:
            file_result = supabase.storage.from_('app-915zdc1c3y81_files').upload(
                file_name,
                f.read()
            )
        
        file_url = supabase.storage.from_('app-915zdc1c3y81_files').get_public_url(file_name)
        print(f"文件上传成功: {file_url}")
        
        # 3. 创建资料记录
        print("正在创建资料记录...")
        material_data = {
            "title": title,
            "description": description,
            "cover_image": cover_url,
            "file_url": file_url,
            "file_type": file_ext,
            "category_id": category_id,
            "is_active": True
        }
        
        result = supabase.table('materials').insert(material_data).execute()
        print("资料上传完成！", result.data)
        return result.data
        
    except Exception as e:
        print(f"上传失败: {str(e)}")
        raise

# 使用示例
upload_material(
    title="小学数学上学期习题集",
    description="涵盖小学数学上学期所有重点知识点",
    cover_image_path="/path/to/cover.jpg",
    file_path="/path/to/document.pdf",
    category_id="22222222-2222-2222-2222-222222222221"
)
```

## 常见问题

### 1. 如何获取分类ID？

运行以下命令查看所有分类：
```bash
curl -X GET \
  'https://你的项目.supabase.co/rest/v1/material_categories?select=*' \
  -H 'Authorization: Bearer 你的SERVICE_ROLE_KEY' \
  -H 'apikey: 你的SERVICE_ROLE_KEY'
```

### 2. 文件大小限制

- 默认单个文件限制：50MB
- 可在 Supabase 控制台的 Storage 设置中调整

### 3. 支持的文件格式

- 图片：JPG, PNG, GIF, WEBP
- 文档：PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX

### 4. 错误处理

常见错误码：
- `401`: 认证失败，检查 Service Role Key
- `403`: 权限不足
- `413`: 文件过大
- `500`: 服务器错误

## 安全建议

1. **不要在客户端使用 Service Role Key**
2. **定期轮换密钥**
3. **使用环境变量存储敏感信息**
4. **限制服务器IP白名单**（在 Supabase 控制台设置）
5. **记录所有API调用日志**

## 联系支持

如有问题，请查看：
- Supabase 官方文档: https://supabase.com/docs
- 项目 GitHub Issues
