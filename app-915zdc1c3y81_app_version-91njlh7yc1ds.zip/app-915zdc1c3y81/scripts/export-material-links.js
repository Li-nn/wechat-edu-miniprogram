/**
 * 导出所有资料的小程序链接
 * 用于配置微信公众号自动回复
 */

import {createClient} from '@supabase/supabase-js'
import * as fs from 'fs'

// 从环境变量读取Supabase配置
const supabaseUrl = process.env.VITE_SUPABASE_URL
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseKey) {
  console.error('错误：请确保.env文件中配置了VITE_SUPABASE_URL和VITE_SUPABASE_ANON_KEY')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseKey)

async function exportMaterialLinks() {
  console.log('正在查询资料数据...\n')

  // 查询所有活跃的资料
  const {data: materials, error: materialsError} = await supabase
    .from('materials')
    .select('id, title, description, category_id, subject_id')
    .eq('is_active', true)
    .order('created_at', {ascending: false})

  if (materialsError) {
    console.error('查询资料失败:', materialsError)
    return
  }

  // 查询年级分类
  const {data: categories, error: categoriesError} = await supabase
    .from('material_categories')
    .select('id, name')
    .order('sort_order', {ascending: true})

  if (categoriesError) {
    console.error('查询年级分类失败:', categoriesError)
    return
  }

  // 查询学科分类
  const {data: subjects, error: subjectsError} = await supabase
    .from('subject_categories')
    .select('id, name')
    .order('sort_order', {ascending: true})

  if (subjectsError) {
    console.error('查询学科分类失败:', subjectsError)
    return
  }

  // 创建分类映射
  const categoryMap = {}
  categories.forEach((cat) => {
    categoryMap[cat.id] = cat.name
  })

  const subjectMap = {}
  subjects.forEach((sub) => {
    subjectMap[sub.id] = sub.name
  })

  // 生成链接列表
  const links = materials.map((material) => {
    const category = categoryMap[material.category_id] || '未分类'
    const subject = subjectMap[material.subject_id] || '未分类'
    const path = `pages/material-detail/index?id=${material.id}`

    return {
      年级: category,
      学科: subject,
      资料标题: material.title,
      资料描述: material.description || '',
      资料ID: material.id,
      小程序路径: path
    }
  })

  // 输出到控制台
  console.log('='.repeat(80))
  console.log('资料链接列表')
  console.log('='.repeat(80))
  console.log(`共找到 ${links.length} 个资料\n`)

  links.forEach((link, index) => {
    console.log(`${index + 1}. ${link.资料标题}`)
    console.log(`   年级：${link.年级}`)
    console.log(`   学科：${link.学科}`)
    console.log(`   小程序路径：${link.小程序路径}`)
    console.log(`   资料ID：${link.资料ID}`)
    if (link.资料描述) {
      console.log(`   描述：${link.资料描述}`)
    }
    console.log('')
  })

  // 导出为CSV文件
  const csvHeader = '序号,年级,学科,资料标题,资料描述,资料ID,小程序路径\n'
  const csvRows = links
    .map((link, index) => {
      return `${index + 1},"${link.年级}","${link.学科}","${link.资料标题}","${link.资料描述}","${link.资料ID}","${link.小程序路径}"`
    })
    .join('\n')

  const csvContent = csvHeader + csvRows
  fs.writeFileSync('资料链接列表.csv', '\ufeff' + csvContent) // 添加BOM以支持中文

  console.log('='.repeat(80))
  console.log('✅ 已导出到文件：资料链接列表.csv')
  console.log('='.repeat(80))

  // 导出为JSON文件
  fs.writeFileSync('资料链接列表.json', JSON.stringify(links, null, 2))
  console.log('✅ 已导出到文件：资料链接列表.json')
  console.log('='.repeat(80))

  // 按年级和学科分组
  const grouped = {}
  links.forEach((link) => {
    const key = `${link.年级}-${link.学科}`
    if (!grouped[key]) {
      grouped[key] = []
    }
    grouped[key].push(link)
  })

  console.log('\n按年级和学科分组：\n')
  Object.keys(grouped)
    .sort()
    .forEach((key) => {
      console.log(`【${key}】`)
      grouped[key].forEach((link) => {
        console.log(`  - ${link.资料标题}`)
        console.log(`    路径：${link.小程序路径}`)
      })
      console.log('')
    })

  console.log('\n使用说明：')
  console.log('1. 在微信公众号后台配置自动回复')
  console.log('2. 选择"小程序卡片"作为回复类型')
  console.log('3. 复制对应资料的"小程序路径"')
  console.log('4. 注意：路径前面不要加 /')
  console.log('\n示例：')
  console.log('关键词：小五数学')
  console.log(`路径：${links[0]?.小程序路径 || 'pages/material-detail/index?id=资料ID'}`)
}

// 执行导出
exportMaterialLinks().catch((error) => {
  console.error('导出失败:', error)
  process.exit(1)
})
