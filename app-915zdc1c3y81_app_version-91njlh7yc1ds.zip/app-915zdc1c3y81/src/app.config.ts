export default defineAppConfig({
  pages: [
    'pages/home/index',
    'pages/materials/index',
    'pages/courses/index',
    'pages/profile/index',
    'pages/login/index',
    'pages/material-detail/index',
    'pages/course-detail/index',
    'pages/points/index',
    'pages/admin/index',
    'pages/admin/users/index',
    'pages/admin/content/index',
    'pages/admin/statistics/index',
    'pages/admin/upload-material/index',
    'pages/admin/upload-course/index',
    'pages/admin/manage-banner/index',
    'pages/admin/settings/index',
    'pages/admin-wechat/index',
    'pages/parent-contact/index',
    'pages/image-search/index'
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#0080ff',
    navigationBarTitleText: '教育资源',
    navigationBarTextStyle: 'white',
    backgroundColor: '#e6f3ff'
  },
  tabBar: {
    color: '#666666',
    selectedColor: '#0080ff',
    backgroundColor: '#ffffff',
    borderStyle: 'black',
    list: [
      {
        pagePath: 'pages/home/index',
        text: '首页',
        iconPath: './assets/images/unselected/home.png',
        selectedIconPath: './assets/images/selected/home.png'
      },
      {
        pagePath: 'pages/materials/index',
        text: '资料',
        iconPath: './assets/images/unselected/materials.png',
        selectedIconPath: './assets/images/selected/materials.png'
      },
      {
        pagePath: 'pages/courses/index',
        text: '课程',
        iconPath: './assets/images/unselected/courses.png',
        selectedIconPath: './assets/images/selected/courses.png'
      },
      {
        pagePath: 'pages/profile/index',
        text: '我的',
        iconPath: './assets/images/unselected/profile.png',
        selectedIconPath: './assets/images/selected/profile.png'
      }
    ]
  }
})
