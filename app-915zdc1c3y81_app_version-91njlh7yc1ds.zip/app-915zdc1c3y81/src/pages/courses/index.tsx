import {Image, Input, ScrollView, Text, View} from '@tarojs/components'
import Taro, {showToast, useDidShow} from '@tarojs/taro'
import {useCallback, useMemo, useState} from 'react'
import {getActiveCourses, getCourseCategories, getSubjectCategories, searchCourses} from '@/db/api'
import type {Course, CourseCategory, SubjectCategory} from '@/db/types'

export default function Courses() {
  const [courses, setCourses] = useState<Course[]>([])
  const [categories, setCategories] = useState<CourseCategory[]>([])
  const [subjects, setSubjects] = useState<SubjectCategory[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string>('')
  const [selectedSubject, setSelectedSubject] = useState<string>('')
  const [searchKeyword, setSearchKeyword] = useState<string>('')
  const [isSearching, setIsSearching] = useState<boolean>(false)

  useDidShow(() => {
    loadData()
  })

  const loadData = useCallback(async () => {
    const [coursesData, categoriesData, subjectsData] = await Promise.all([
      getActiveCourses(),
      getCourseCategories(),
      getSubjectCategories()
    ])
    setCourses(coursesData)
    setCategories(categoriesData)
    setSubjects(subjectsData)
  }, [])

  // 搜索课程
  const handleSearch = useCallback(
    async (keyword: string) => {
      setSearchKeyword(keyword)
      if (!keyword.trim()) {
        setIsSearching(false)
        setSelectedCategory('')
        setSelectedSubject('')
        await loadData()
        return
      }

      setIsSearching(true)
      const results = await searchCourses(keyword)
      setCourses(results)

      if (results.length === 0) {
        showToast({title: '未找到相关课程', icon: 'none'})
      }
    },
    [loadData]
  )

  // 清除搜索
  const handleClearSearch = useCallback(async () => {
    setSearchKeyword('')
    setIsSearching(false)
    setSelectedCategory('')
    setSelectedSubject('')
    await loadData()
  }, [loadData])

  // 过滤课程
  const filteredCourses = useMemo(() => {
    if (isSearching) return courses

    let result = courses

    // 按年级筛选
    if (selectedCategory) {
      result = result.filter((c) => c.category_id === selectedCategory)
    }

    // 按学科筛选
    if (selectedSubject) {
      result = result.filter((c) => c.subject_id === selectedSubject)
    }

    return result
  }, [courses, selectedCategory, selectedSubject, isSearching])

  // 处理课程点击
  const handleCourseClick = useCallback((id: string) => {
    Taro.navigateTo({url: `/pages/course-detail/index?id=${id}`})
  }, [])

  // 格式化时长
  const formatDuration = useCallback((seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    return `${minutes}分钟`
  }, [])

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        {/* 顶部标题 */}
        <View className="px-6 pt-8 pb-6">
          <Text className="text-foreground text-2xl font-bold mb-2">课程视频</Text>
          <Text className="text-muted-foreground text-sm">名师精讲，在线学习更高效</Text>
        </View>

        {/* 搜索框 */}
        <View className="px-6 mb-4">
          <View className="bg-card rounded-xl border border-border px-4 py-3 flex items-center">
            <View className="i-mdi-magnify text-xl text-muted-foreground mr-2" />
            <Input
              className="flex-1 text-foreground"
              style={{padding: 0, border: 'none', background: 'transparent'}}
              placeholder="搜索课程标题或描述"
              value={searchKeyword}
              onInput={(e) => handleSearch(e.detail.value)}
            />
            {searchKeyword && (
              <View className="i-mdi-close-circle text-xl text-muted-foreground" onClick={handleClearSearch} />
            )}
          </View>
        </View>

        {/* 学科标签 */}
        {!isSearching && (
          <View className="px-6 mb-4">
            <Text className="text-sm font-bold text-foreground mb-3">学科分类</Text>
            <View className="flex flex-wrap gap-3">
              <View
                className={`px-5 py-2 rounded-full ${!selectedSubject ? 'bg-primary text-white' : 'bg-card text-foreground'}`}
                onClick={() => setSelectedSubject('')}>
                <Text className={`text-sm font-medium ${!selectedSubject ? 'text-white' : 'text-foreground'}`}>
                  全部
                </Text>
              </View>
              {subjects.map((subject) => (
                <View
                  key={subject.id}
                  className={`px-5 py-2 rounded-full ${selectedSubject === subject.id ? 'bg-primary text-white' : 'bg-card text-foreground'}`}
                  onClick={() => setSelectedSubject(subject.id)}>
                  <Text
                    className={`text-sm font-medium ${selectedSubject === subject.id ? 'text-white' : 'text-foreground'}`}>
                    {subject.name}
                  </Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* 年级标签 */}
        {!isSearching && (
          <View className="px-6 mb-6">
            <Text className="text-sm font-bold text-foreground mb-3">年级分类</Text>
            <View className="flex flex-wrap gap-3">
              <View
                className={`px-5 py-2 rounded-full ${!selectedCategory ? 'bg-accent text-white' : 'bg-card text-foreground'}`}
                onClick={() => setSelectedCategory('')}>
                <Text className={`text-sm font-medium ${!selectedCategory ? 'text-white' : 'text-foreground'}`}>
                  全部
                </Text>
              </View>
              {categories.map((cat) => (
                <View
                  key={cat.id}
                  className={`px-5 py-2 rounded-full ${selectedCategory === cat.id ? 'bg-accent text-white' : 'bg-card text-foreground'}`}
                  onClick={() => setSelectedCategory(cat.id)}>
                  <Text
                    className={`text-sm font-medium ${selectedCategory === cat.id ? 'text-white' : 'text-foreground'}`}>
                    {cat.name}
                    {cat.type === 'live' && ' (直播)'}
                  </Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* 搜索结果提示 */}
        {isSearching && (
          <View className="px-6 mb-4">
            <Text className="text-sm text-muted-foreground">找到 {filteredCourses.length} 个相关课程</Text>
          </View>
        )}

        {/* 课程列表 */}
        <View className="px-6 pb-6">
          {filteredCourses.length === 0 ? (
            <View className="flex flex-col items-center justify-center py-20">
              <View className="i-mdi-video-off text-6xl text-muted-foreground mb-4" />
              <Text className="text-muted-foreground">暂无课程</Text>
            </View>
          ) : (
            <View className="flex flex-col gap-4">
              {filteredCourses.map((course) => (
                <View
                  key={course.id}
                  className="bg-card rounded-2xl overflow-hidden border border-border"
                  onClick={() => handleCourseClick(course.id)}>
                  {course.cover_image && (
                    <View className="relative">
                      <Image src={course.cover_image} mode="aspectFill" className="w-full h-48" />
                      <View className="absolute top-0 left-0 right-0 bottom-0 bg-black bg-opacity-20 flex items-center justify-center">
                        <View className="w-16 h-16 bg-white bg-opacity-90 rounded-full flex items-center justify-center">
                          <View className="i-mdi-play text-4xl text-primary" />
                        </View>
                      </View>
                      {course.price > 0 && (
                        <View className="absolute top-3 right-3 bg-destructive px-3 py-1 rounded-full">
                          <Text className="text-white text-xs font-bold">¥{course.price}</Text>
                        </View>
                      )}
                    </View>
                  )}
                  <View className="p-4">
                    <Text className="text-base font-bold text-foreground mb-2 break-keep">{course.title}</Text>
                    {course.description && (
                      <Text className="text-sm text-muted-foreground mb-3 line-clamp-2">{course.description}</Text>
                    )}
                    <View className="flex items-center justify-between">
                      <View className="flex items-center gap-4">
                        <View className="flex items-center gap-1">
                          <View className="i-mdi-clock-outline text-sm text-muted-foreground" />
                          <Text className="text-xs text-muted-foreground">{formatDuration(course.total_duration)}</Text>
                        </View>
                        <View className="flex items-center gap-1">
                          <View className="i-mdi-eye text-sm text-muted-foreground" />
                          <Text className="text-xs text-muted-foreground">{course.view_count}</Text>
                        </View>
                      </View>
                      <View className="bg-secondary px-3 py-1 rounded-full">
                        <Text className="text-xs text-secondary-foreground">
                          试看{formatDuration(course.preview_duration)}
                        </Text>
                      </View>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  )
}
