export default {
  navigationBarTitleText: '课程视频'
}
