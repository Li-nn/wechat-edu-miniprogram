export default {
  navigationBarTitleText: '资料详情'
}
