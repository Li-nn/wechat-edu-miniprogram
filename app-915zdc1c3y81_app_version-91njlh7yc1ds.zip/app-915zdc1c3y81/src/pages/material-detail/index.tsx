import {Button, Image, ScrollView, Text, View} from '@tarojs/components'
import Taro, {
  downloadFile,
  getEnv,
  openDocument,
  showModal,
  showToast,
  useDidShow,
  useLoad,
  useShareAppMessage,
  useShareTimeline
} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {
  deductDownloadPoints,
  getMaterialById,
  grantSharePoints,
  incrementMaterialDownload,
  incrementMaterialView,
  recordUserMaterial
} from '@/db/api'
import type {Material} from '@/db/types'
import {useUserStore} from '@/store/userStore'

export default function MaterialDetail() {
  const [material, setMaterial] = useState<Material | null>(null)
  const [downloading, setDownloading] = useState(false)
  const [previewed, setPreviewed] = useState(false)
  const {user, loadUser} = useUserStore()

  useLoad(async (options) => {
    const {id} = options
    if (id) {
      await loadUser()
      await loadMaterial(id)
    }
  })

  // 页面显示时自动预览
  useDidShow(() => {
    if (material && !previewed) {
      // 延迟一点时间，让页面先渲染
      setTimeout(() => {
        handlePreview()
      }, 500)
    }
  })

  // 加载资料详情
  const loadMaterial = useCallback(
    async (id: string) => {
      const data = await getMaterialById(id)
      if (data) {
        setMaterial(data)
        await incrementMaterialView(id)
        if (user) {
          await recordUserMaterial(user.id, id, 'view')
        }
      } else {
        showToast({title: '资料不存在', icon: 'none'})
        Taro.navigateBack()
      }
    },
    [user]
  )

  // 分享配置
  useShareAppMessage(() => ({
    title: material?.title || '学习资料',
    path: `/pages/material-detail/index?id=${material?.id}`,
    success: async () => {
      // 分享成功后发放积分
      if (user) {
        const result = await grantSharePoints(user.id)
        if (result.success && result.points > 0) {
          await loadUser()
          showToast({title: `分享成功！获得${result.points}积分`, icon: 'success', duration: 2000})
        } else if (!result.success && result.message.includes('上限')) {
          showToast({title: '分享成功！今日积分已达上限', icon: 'none', duration: 2000})
        }
      }
    }
  }))

  useShareTimeline(() => ({
    title: material?.title || '学习资料',
    success: async () => {
      // 分享成功后发放积分
      if (user) {
        const result = await grantSharePoints(user.id)
        if (result.success && result.points > 0) {
          await loadUser()
          showToast({title: `分享成功！获得${result.points}积分`, icon: 'success', duration: 2000})
        } else if (!result.success && result.message.includes('上限')) {
          showToast({title: '分享成功！今日积分已达上限', icon: 'none', duration: 2000})
        }
      }
    }
  }))

  // 处理分享
  const handleShare = useCallback(() => {
    if (getEnv() !== Taro.ENV_TYPE.WEAPP) {
      showToast({title: '分享功能仅在微信小程序中可用', icon: 'none'})
    } else {
      showToast({title: '请点击右上角分享', icon: 'none'})
    }
    if (user && material) {
      recordUserMaterial(user.id, material.id, 'share')
    }
  }, [user, material])

  // 预览资料
  const handlePreview = useCallback(async () => {
    if (!material || !material.file_url) {
      showToast({title: '资料文件不存在', icon: 'none'})
      return
    }

    setPreviewed(true)
    try {
      showToast({title: '正在打开预览...', icon: 'loading', duration: 2000})

      const res = await downloadFile({
        url: material.file_url
      })

      if (res.statusCode === 200) {
        await openDocument({
          filePath: res.tempFilePath,
          showMenu: true
        })
      } else {
        showToast({title: '预览失败', icon: 'none'})
      }
    } catch (error) {
      console.error('预览失败:', error)
      showToast({title: '预览失败，请重试', icon: 'none'})
    }
  }, [material])

  // 下载资料
  const handleDownload = useCallback(async () => {
    if (!user) {
      Taro.setStorageSync('loginRedirectPath', `/pages/material-detail/index?id=${material?.id}`)
      Taro.navigateTo({url: '/pages/login/index'})
      return
    }

    if (!material || !material.file_url) {
      showToast({title: '资料文件不存在', icon: 'none'})
      return
    }

    // 检查积分是否足够
    const pointsResult = await deductDownloadPoints(user.id, material.id)
    if (!pointsResult.success) {
      const _res = await showModal({
        title: '积分不足',
        content: `下载需要5积分，当前积分：${pointsResult.current_points || 0}。每日登录和分享可获得积分。`,
        showCancel: true,
        confirmText: '知道了'
      })
      return
    }

    setDownloading(true)
    try {
      const res = await downloadFile({
        url: material.file_url
      })

      if (res.statusCode === 200) {
        await openDocument({
          filePath: res.tempFilePath,
          showMenu: true
        })

        await incrementMaterialDownload(material.id)
        await recordUserMaterial(user.id, material.id, 'download')

        // 重新加载用户信息以更新积分显示
        await loadUser()

        showToast({
          title: `下载成功！消耗5积分，剩余${pointsResult.remaining_points || 0}积分`,
          icon: 'success',
          duration: 2000
        })
      } else {
        showToast({title: '下载失败', icon: 'none'})
      }
    } catch (error) {
      console.error('下载失败:', error)
      showToast({title: '下载失败，请重试', icon: 'none'})
    } finally {
      setDownloading(false)
    }
  }, [user, material, loadUser])

  if (!material) {
    return (
      <View className="min-h-screen bg-background flex items-center justify-center">
        <Text className="text-muted-foreground">加载中...</Text>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        {/* 封面图 */}
        {material.cover_image && <Image src={material.cover_image} mode="aspectFill" className="w-full h-64" />}

        {/* 资料信息 */}
        <View className="px-6 py-6">
          <View className="bg-card rounded-2xl p-6 border border-border mb-6">
            <Text className="text-2xl font-bold text-foreground mb-4 break-keep">{material.title}</Text>

            <View className="flex items-center gap-4 mb-4">
              <View className="flex items-center gap-1">
                <View className="i-mdi-eye text-base text-muted-foreground" />
                <Text className="text-sm text-muted-foreground">{material.view_count} 次查看</Text>
              </View>
              <View className="flex items-center gap-1">
                <View className="i-mdi-download text-base text-muted-foreground" />
                <Text className="text-sm text-muted-foreground">{material.download_count} 次下载</Text>
              </View>
              <View className="flex items-center gap-1">
                <View
                  className={`i-mdi-file-${material.file_type === 'pdf' ? 'pdf' : 'document'} text-base text-primary`}
                />
                <Text className="text-sm text-primary">{material.file_type.toUpperCase()}</Text>
              </View>
            </View>

            {material.description && (
              <View className="border-t border-border pt-4">
                <Text className="text-sm font-bold text-foreground mb-2">资料简介</Text>
                <Text className="text-sm text-muted-foreground leading-relaxed">{material.description}</Text>
              </View>
            )}
          </View>

          {/* 操作按钮 */}
          <View className="mb-6">
            {/* 预览按钮 - 主要操作 */}
            <Button
              className="w-full bg-primary text-white py-4 rounded-xl break-keep text-base mb-4"
              size="default"
              onClick={handlePreview}>
              <View className="flex items-center justify-center gap-2">
                <View className="i-mdi-file-eye text-xl" />
                <Text>预览资料</Text>
              </View>
            </Button>

            {/* 下载和分享按钮 */}
            <View className="flex gap-4">
              <Button
                className="flex-1 bg-accent text-white py-4 rounded-xl break-keep text-base"
                size="default"
                onClick={downloading ? undefined : handleDownload}>
                <View className="flex items-center justify-center gap-2">
                  <View className="i-mdi-download text-xl" />
                  <Text>{downloading ? '下载中...' : '下载资料'}</Text>
                </View>
              </Button>
              <Button
                className="flex-1 bg-card text-foreground py-4 rounded-xl break-keep text-base border border-border"
                size="default"
                {...(getEnv() === Taro.ENV_TYPE.WEAPP ? {openType: 'share'} : {onClick: handleShare})}>
                <View className="flex items-center justify-center gap-2">
                  <View className="i-mdi-share-variant text-xl" />
                  <Text>分享资料</Text>
                </View>
              </Button>
            </View>
          </View>

          {/* 温馨提示 */}
          <View className="bg-secondary rounded-2xl p-5">
            <View className="flex items-center mb-3">
              <View className="i-mdi-information text-xl text-primary mr-2" />
              <Text className="text-base font-bold text-foreground">温馨提示</Text>
            </View>
            <Text className="text-sm text-muted-foreground leading-relaxed">
              1. 点击"预览资料"可直接查看文件内容{'\n'}
              2. 下载的资料仅供个人学习使用{'\n'}
              3. 请勿用于商业用途或传播{'\n'}
              4. 如有疑问请联系客服咨询
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* 底部导航栏 */}
      <View className="fixed bottom-0 left-0 right-0 bg-card border-t border-border safe-area-bottom">
        <View className="flex items-center justify-around py-3 px-6">
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.switchTab({url: '/pages/home/index'})}>
            <View className="i-mdi-home text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">首页</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/materials/index'})}>
            <View className="i-mdi-file-document text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">资料</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/courses/index'})}>
            <View className="i-mdi-video text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">课程</Text>
          </View>
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.navigateBack()}>
            <View className="i-mdi-arrow-left-circle text-2xl text-primary" />
            <Text className="text-xs text-primary">返回</Text>
          </View>
        </View>
      </View>
    </View>
  )
}
