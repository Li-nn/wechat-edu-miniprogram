import {Image, ScrollView, Swiper, SwiperItem, Text, View} from '@tarojs/components'
import Taro, {useDidShow} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {getActiveBanners, getLatestCourses, getLatestMaterials, recordConsultation} from '@/db/api'
import type {Banner, Course, Material} from '@/db/types'
import {useUserStore} from '@/store/userStore'

export default function Home() {
  const [banners, setBanners] = useState<Banner[]>([])
  const [latestMaterials, setLatestMaterials] = useState<Material[]>([])
  const [latestCourses, setLatestCourses] = useState<Course[]>([])
  const {user, loadUser} = useUserStore()

  // 检查登录状态
  const checkAuth = useCallback(async () => {
    await loadUser()
  }, [loadUser])

  useDidShow(() => {
    checkAuth()
    loadBanners()
    loadLatestContent()
  })

  // 加载轮播图
  const loadBanners = useCallback(async () => {
    const data = await getActiveBanners()
    setBanners(data)
  }, [])

  // 加载最新内容
  const loadLatestContent = useCallback(async () => {
    const [materials, courses] = await Promise.all([getLatestMaterials(2), getLatestCourses(2)])
    setLatestMaterials(materials)
    setLatestCourses(courses)
  }, [])

  // 格式化时间显示
  const formatTime = useCallback((dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))

    if (days === 0) {
      const hours = Math.floor(diff / (1000 * 60 * 60))
      if (hours === 0) {
        const minutes = Math.floor(diff / (1000 * 60))
        return minutes <= 0 ? '刚刚' : `${minutes}分钟前`
      }
      return `${hours}小时前`
    } else if (days === 1) {
      return '昨天'
    } else if (days < 7) {
      return `${days}天前`
    } else {
      return `${date.getMonth() + 1}月${date.getDate()}日`
    }
  }, [])

  // 处理轮播图点击
  const handleBannerClick = useCallback((banner: Banner) => {
    if (banner.link_type === 'material' && banner.link_id) {
      Taro.navigateTo({url: `/pages/material-detail/index?id=${banner.link_id}`})
    } else if (banner.link_type === 'course' && banner.link_id) {
      Taro.navigateTo({url: `/pages/course-detail/index?id=${banner.link_id}`})
    }
  }, [])

  // 咨询微信
  const handleWechatConsult = useCallback(async () => {
    if (!user) {
      Taro.setStorageSync('loginRedirectPath', '/pages/home/index')
      Taro.navigateTo({url: '/pages/login/index'})
      return
    }

    await recordConsultation(user.id, 'wechat')
    // 跳转到系统设置页面查看管理员微信
    Taro.navigateTo({url: '/pages/admin-wechat/index'})
  }, [user])

  // 家长留资
  const handleParentContact = useCallback(() => {
    Taro.navigateTo({url: '/pages/parent-contact/index'})
  }, [])

  return (
    <View className="min-h-screen bg-background">
      <ScrollView
        scrollY
        style={{height: '100vh', background: 'transparent'}}
        className="border-solid border-[#356cd7] bg-[#ffffff00] bg-none border-[0px] border-[#35599f]">
        {/* 顶部欢迎区域 */}
        <View className="bg-primary px-6 pt-8 pb-6 rounded-b-3xl border-dashed border-[#517fdc] rounded-tl-[12px] rounded-tr-[12px] ml-[11px] mr-[11px] border-[0px] border-[#6d98ef]">
          <View className="flex items-center justify-between mb-4">
            <View>
              <Text className="text-white text-2xl font-bold mb-1">欢迎来到</Text>
              <Text className="font-bold border-solid border-[#7298e5] text-[24px] text-[#e041b1] bg-[#d2353500] bg-none border-[0px] border-[#88a3db]">
                {'数社'}
              </Text>
            </View>
            {user?.avatar ? (
              <View className="w-16 h-16 rounded-full overflow-hidden border-2 border-white border-opacity-30">
                <Image src={user.avatar} mode="aspectFill" className="w-full h-full" />
              </View>
            ) : (
              <View className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                <View className="i-mdi-school text-4xl text-white" />
              </View>
            )}
          </View>
          <View className="flex items-center justify-between">
            <Text className="text-white text-opacity-90 text-sm">
              {user ? `你好，${user.nickname || user.username || '学员'}` : '请先登录以获取更多资源'}
            </Text>
            {user && (
              <View
                className="flex items-center gap-1 bg-white bg-opacity-20 px-3 py-1 rounded-full"
                onClick={() => Taro.navigateTo({url: '/pages/points/index'})}>
                <View className="i-mdi-coin text-base text-yellow-300" />
                <Text className="text-white text-sm font-bold">{user.points || 0}</Text>
                <View className="i-mdi-chevron-right text-base text-white text-opacity-70" />
              </View>
            )}
          </View>
        </View>

        {/* 轮播图 */}
        {banners.length > 0 && (
          <View className="px-6 mt-6 mb-6">
            <Swiper
              className="rounded-2xl border border-border overflow-hidden"
              style={{height: '180px'}}
              indicatorColor="rgba(255,255,255,0.5)"
              indicatorActiveColor="#fff"
              circular
              autoplay
              interval={3000}>
              {banners.map((banner) => (
                <SwiperItem key={banner.id} onClick={() => handleBannerClick(banner)}>
                  <Image src={banner.image_url} mode="aspectFill" className="w-full h-full" />
                </SwiperItem>
              ))}
            </Swiper>
          </View>
        )}

        {/* 特色服务 */}
        <View className="px-6 mb-6">
          <Text className="text-lg font-bold text-foreground mb-4">特色服务</Text>
          <View className="flex gap-3">
            {/* 学习资料 */}
            <View
              className="flex-1 from-blue-500 to-blue-600 rounded-2xl p-4 shadow-lg border-solid rounded-tl-[12px] rounded-tr-[12px] border-[0px] border-[#ffffff] mr-[1px] ml-[1px] bg-[#ffffff00] bg-none"
              style={{background: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)'}}
              onClick={() => Taro.switchTab({url: '/pages/materials/index'})}>
              <View className="flex flex-col items-center gap-2">
                <View className="w-16 h-16 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                  <Image
                    src="https://miaoda-image.cdn.bcebos.com/img/corpus/a7a093302d1446939d36456c32f44044.jpg"
                    mode="aspectFit"
                    className="w-12 h-12"
                  />
                </View>
                <Text className="text-sm font-bold text-[#000000]">学习资料</Text>
              </View>
            </View>

            {/* 视频课程 */}
            <View
              className="flex-1 from-purple-500 to-purple-600 rounded-2xl p-4 shadow-lg bg-[#fdfdfd00] bg-none"
              style={{background: 'linear-gradient(135deg, #a855f7 0%, #9333ea 100%)'}}
              onClick={() => Taro.switchTab({url: '/pages/courses/index'})}>
              <View className="flex flex-col items-center gap-2">
                <View className="w-16 h-16 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                  <Image
                    src="https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_17c44af9-6d89-433b-ad0e-6717fa5f4b43.jpg"
                    mode="aspectFit"
                    className="w-12 h-12"
                  />
                </View>
                <Text className="text-sm font-bold text-[#000000]">视频课程</Text>
              </View>
            </View>

            {/* 图片搜题 */}
            <View
              className="flex-1 from-green-500 to-green-600 rounded-2xl p-4 shadow-lg bg-[#ffffff00] bg-none"
              style={{background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)'}}
              onClick={() => Taro.navigateTo({url: '/pages/image-search/index'})}>
              <View className="flex flex-col items-center gap-2">
                <View className="w-16 h-16 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                  <Image
                    src="https://miaoda-image.cdn.bcebos.com/img/corpus/56fe9c05f08d4da29ab7b934306cbe6d.jpg"
                    mode="aspectFit"
                    className="w-12 h-12"
                  />
                </View>
                <Text className="text-sm font-bold text-[#000000]">图片搜题</Text>
              </View>
            </View>
          </View>
        </View>

        {/* 最新资料 */}
        {latestMaterials.length > 0 && (
          <View className="px-6 mb-6">
            <View className="flex items-center justify-between mb-4">
              <Text className="text-lg font-bold text-foreground">最新资料</Text>
              <Text className="text-sm text-primary" onClick={() => Taro.switchTab({url: '/pages/materials/index'})}>
                查看更多 →
              </Text>
            </View>
            <View className="flex flex-col gap-3">
              {latestMaterials.map((material) => (
                <View
                  key={material.id}
                  className="bg-card rounded-2xl p-4 border border-border"
                  onClick={() => Taro.navigateTo({url: `/pages/material-detail/index?id=${material.id}`})}>
                  <View className="flex items-start justify-between mb-2">
                    <Text className="text-base font-bold text-foreground flex-1 break-keep">{material.title}</Text>
                    <Text className="text-xs text-muted-foreground ml-2 whitespace-nowrap">
                      {formatTime(material.created_at)}
                    </Text>
                  </View>
                  {material.description && (
                    <Text className="text-sm text-muted-foreground line-clamp-2">{material.description}</Text>
                  )}
                  <View className="flex items-center gap-4 mt-3">
                    <View className="flex items-center gap-1">
                      <View className="i-mdi-eye text-base text-muted-foreground" />
                      <Text className="text-xs text-muted-foreground">{material.view_count}</Text>
                    </View>
                    <View className="flex items-center gap-1">
                      <View className="i-mdi-download text-base text-muted-foreground" />
                      <Text className="text-xs text-muted-foreground">{material.download_count}</Text>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* 最新课程 */}
        {latestCourses.length > 0 && (
          <View className="px-6 mb-6">
            <View className="flex items-center justify-between mb-4">
              <Text className="text-lg font-bold text-foreground">最新课程</Text>
              <Text className="text-sm text-primary" onClick={() => Taro.switchTab({url: '/pages/courses/index'})}>
                查看更多 →
              </Text>
            </View>
            <View className="flex flex-col gap-3">
              {latestCourses.map((course) => (
                <View
                  key={course.id}
                  className="bg-card rounded-2xl p-4 border border-border"
                  onClick={() => Taro.navigateTo({url: `/pages/course-detail/index?id=${course.id}`})}>
                  <View className="flex items-start justify-between mb-2">
                    <Text className="text-base font-bold text-foreground flex-1 break-keep">{course.title}</Text>
                    <Text className="text-xs text-muted-foreground ml-2 whitespace-nowrap">
                      {formatTime(course.created_at)}
                    </Text>
                  </View>
                  {course.description && (
                    <Text className="text-sm text-muted-foreground line-clamp-2">{course.description}</Text>
                  )}
                  <View className="flex items-center gap-4 mt-3">
                    <View className="flex items-center gap-1">
                      <View className="i-mdi-eye text-base text-muted-foreground" />
                      <Text className="text-xs text-muted-foreground">{course.view_count}</Text>
                    </View>
                    {course.price > 0 && (
                      <View className="flex items-center gap-1">
                        <View className="i-mdi-currency-cny text-base text-accent" />
                        <Text className="text-xs text-accent font-bold">{course.price}</Text>
                      </View>
                    )}
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* 咨询模块 */}
        <View className="px-6 pb-20">
          <View className="bg-card rounded-2xl p-6 border border-border">
            <View className="flex gap-4">
              <View
                className="flex-1 bg-accent rounded-xl py-4 flex items-center justify-center"
                onClick={handleWechatConsult}>
                <View className="i-mdi-wechat text-2xl text-white mr-2" />
                <Text className="text-white font-bold">微信咨询</Text>
              </View>
              <View
                className="flex-1 bg-primary rounded-xl py-4 flex items-center justify-center"
                onClick={handleParentContact}>
                <View className="i-mdi-phone-in-talk text-2xl text-white mr-2" />
                <Text className="text-white font-bold">家长留资</Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
