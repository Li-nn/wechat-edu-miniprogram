import {Button, Input, Text, View} from '@tarojs/components'
import Taro, {getEnv, showToast, useLoad} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {supabase} from '@/client/supabase'
import {checkAndGrantDailyLogin, updateUserPhone} from '@/db/api'
import {useUserStore} from '@/store/userStore'

// 错误信息翻译函数
const translateErrorMessage = (errorMsg: string): string => {
  const errorMap: Record<string, string> = {
    'Invalid login credentials': '用户名或密码错误',
    'Email not confirmed': '邮箱未确认',
    'User already registered': '用户已注册',
    'Password should be at least 6 characters': '密码至少需要6个字符',
    'Unable to validate email address: invalid format': '邮箱格式无效',
    'Signup requires a valid password': '注册需要有效的密码',
    'Database error saving new user': '保存用户信息失败',
    'User not found': '用户不存在',
    'Invalid email or password': '邮箱或密码无效',
    'Email rate limit exceeded': '邮件发送频率超限，请稍后再试',
    'Invalid token': '无效的令牌',
    'Token has expired': '令牌已过期',
    'Network request failed': '网络请求失败，请检查网络连接',
    'Failed to fetch': '网络连接失败',
    'Unexpected error': '发生未知错误'
  }

  // 检查是否包含已知的错误信息
  for (const [key, value] of Object.entries(errorMap)) {
    if (errorMsg.includes(key)) {
      return value
    }
  }

  // 如果没有匹配的翻译，返回原始信息
  return errorMsg
}

export default function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)
  const [agreed, setAgreed] = useState(false)
  const [showPasswordLogin, setShowPasswordLogin] = useState(false)
  const {loadUser} = useUserStore()

  useLoad(() => {
    console.log('登录页面加载')
  })

  // 微信授权登录
  const handleWechatLogin = useCallback(async () => {
    if (!agreed) {
      showToast({title: '请先同意用户协议和隐私政策', icon: 'none'})
      return
    }

    if (getEnv() !== Taro.ENV_TYPE.WEAPP) {
      showToast({title: '微信授权登录请在小程序体验，网页端请使用用户名密码登录', icon: 'none'})
      return
    }

    setLoading(true)
    try {
      const loginResult = await Taro.login()
      const {data, error} = await supabase.functions.invoke('wechat-miniprogram-login', {
        body: {code: loginResult?.code}
      })

      if (error) {
        const errorMsg = (await error?.context?.text?.()) || error.message
        showToast({title: translateErrorMessage(errorMsg), icon: 'none'})
        setLoading(false)
        return
      }

      const {error: verifyError} = await supabase.auth.verifyOtp({
        token_hash: data.token,
        type: 'email'
      })

      if (verifyError) {
        showToast({title: translateErrorMessage(verifyError.message), icon: 'none'})
        setLoading(false)
        return
      }

      await loadUser()

      // 检查并发放每日登录奖励
      const {
        data: {user: authUser}
      } = await supabase.auth.getUser()
      if (authUser) {
        // 如果用户填写了手机号，则更新到数据库
        if (phone.trim()) {
          const phoneRegex = /^1[3-9]\d{9}$/
          if (phoneRegex.test(phone.trim())) {
            await updateUserPhone(authUser.id, phone.trim())
          }
        }

        const dailyResult = await checkAndGrantDailyLogin(authUser.id)
        if (dailyResult.success && dailyResult.points > 0) {
          showToast({title: `登录成功！获得${dailyResult.points}积分`, icon: 'success', duration: 2000})
        } else {
          showToast({title: '登录成功', icon: 'success'})
        }
      } else {
        showToast({title: '登录成功', icon: 'success'})
      }

      // 处理登录后跳转
      const redirectPath = Taro.getStorageSync('loginRedirectPath')
      if (redirectPath) {
        Taro.removeStorageSync('loginRedirectPath')
        const tabBarPages = [
          '/pages/home/index',
          '/pages/materials/index',
          '/pages/courses/index',
          '/pages/profile/index'
        ]
        if (tabBarPages.includes(redirectPath)) {
          Taro.switchTab({url: redirectPath})
        } else {
          Taro.navigateTo({url: redirectPath})
        }
      } else {
        Taro.switchTab({url: '/pages/home/index'})
      }
    } catch (err) {
      console.error('微信登录失败:', err)
      showToast({title: '登录失败，请重试', icon: 'none'})
    } finally {
      setLoading(false)
    }
  }, [agreed, phone, loadUser])

  // 用户名密码登录
  const handleUsernameLogin = useCallback(async () => {
    if (!agreed) {
      showToast({title: '请先同意用户协议和隐私政策', icon: 'none'})
      return
    }

    if (!username || !password) {
      showToast({title: '请输入用户名和密码', icon: 'none'})
      return
    }

    // 验证用户名格式
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      showToast({title: '用户名只能包含字母、数字和下划线', icon: 'none'})
      return
    }

    setLoading(true)
    try {
      const email = `${username}@miaoda.com`

      // 尝试登录
      const {error: signInError} = await supabase.auth.signInWithPassword({
        email,
        password
      })

      if (signInError) {
        // 如果登录失败，尝试注册
        if (signInError.message.includes('Invalid login credentials')) {
          const {error: signUpError} = await supabase.auth.signUp({
            email,
            password
          })

          if (signUpError) {
            showToast({title: translateErrorMessage(signUpError.message), icon: 'none'})
            setLoading(false)
            return
          }

          showToast({title: '注册成功，已自动登录', icon: 'success'})
        } else {
          showToast({title: translateErrorMessage(signInError.message), icon: 'none'})
          setLoading(false)
          return
        }
      }

      await loadUser()

      // 检查并发放每日登录奖励
      const {
        data: {user: authUser2}
      } = await supabase.auth.getUser()
      if (authUser2) {
        // 如果用户填写了手机号，则更新到数据库
        if (phone.trim()) {
          const phoneRegex = /^1[3-9]\d{9}$/
          if (phoneRegex.test(phone.trim())) {
            await updateUserPhone(authUser2.id, phone.trim())
          }
        }

        const dailyResult = await checkAndGrantDailyLogin(authUser2.id)
        if (dailyResult.success && dailyResult.points > 0) {
          showToast({title: `登录成功！获得${dailyResult.points}积分`, icon: 'success', duration: 2000})
        } else {
          showToast({title: '登录成功', icon: 'success'})
        }
      } else {
        showToast({title: '登录成功', icon: 'success'})
      }

      // 处理登录后跳转
      const redirectPath = Taro.getStorageSync('loginRedirectPath')
      if (redirectPath) {
        Taro.removeStorageSync('loginRedirectPath')
        const tabBarPages = [
          '/pages/home/index',
          '/pages/materials/index',
          '/pages/courses/index',
          '/pages/profile/index'
        ]
        if (tabBarPages.includes(redirectPath)) {
          Taro.switchTab({url: redirectPath})
        } else {
          Taro.navigateTo({url: redirectPath})
        }
      } else {
        Taro.switchTab({url: '/pages/home/index'})
      }
    } catch (err) {
      console.error('登录失败:', err)
      showToast({title: '登录失败，请重试', icon: 'none'})
    } finally {
      setLoading(false)
    }
  }, [username, password, phone, agreed, loadUser])

  return (
    <View className="min-h-screen bg-background flex flex-col items-center justify-center p-6">
      <View className="w-full max-w-md">
        {/* Logo区域 */}
        <View className="flex flex-col items-center mb-12">
          <View className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mb-4">
            <View className="i-mdi-school text-5xl text-white" />
          </View>
          <Text className="text-3xl font-bold gradient-text mb-2">{'数社'}</Text>
          <Text className="text-muted-foreground text-sm">优质教育资源分享平台</Text>
        </View>

        {/* 登录表单 */}
        <View className="bg-card rounded-2xl p-6 border border-border mb-6">
          {!showPasswordLogin ? (
            /* 默认显示：微信授权和账号密码登录按钮 */
            <View>
              <Text className="text-xl font-bold text-foreground mb-6 text-center">欢迎登录</Text>

              {/* 手机号输入（选填） */}
              <View className="mb-4">
                <Text className="text-sm text-muted-foreground mb-2">手机号（选填）</Text>
                <View className="bg-input rounded-xl border border-border px-4 py-3">
                  <Input
                    className="w-full text-foreground"
                    style={{padding: 0, border: 'none', background: 'transparent'}}
                    type="number"
                    maxlength={11}
                    placeholder="请输入手机号"
                    value={phone}
                    onInput={(e) => setPhone(e.detail.value)}
                  />
                </View>
              </View>

              {/* 微信授权登录按钮 */}
              <Button
                className="w-full bg-accent text-white py-4 rounded-xl break-keep text-base mb-4"
                size="default"
                onClick={loading ? undefined : handleWechatLogin}>
                <View className="flex items-center justify-center gap-2">
                  <View className="i-mdi-wechat text-xl" />
                  <Text>微信授权登录</Text>
                </View>
              </Button>

              {/* 账号密码登录按钮 */}
              <Button
                className="w-full bg-primary text-white py-4 rounded-xl break-keep text-base"
                size="default"
                onClick={() => setShowPasswordLogin(true)}>
                账号密码登录
              </Button>

              {/* 协议勾选 */}
              <View className="flex items-center gap-2 mt-6" onClick={() => setAgreed(!agreed)}>
                <View
                  className={`w-5 h-5 rounded border-2 flex items-center justify-center ${agreed ? 'bg-primary border-primary' : 'border-border'}`}>
                  {agreed && <View className="i-mdi-check text-white text-sm" />}
                </View>
                <Text className="text-xs text-muted-foreground">我已阅读并同意《用户协议》和《隐私政策》</Text>
              </View>
            </View>
          ) : (
            /* 点击账号密码登录后显示：输入框和登录按钮 */
            <View>
              <Text className="text-xl font-bold text-foreground mb-6">账号密码登录</Text>

              {/* 用户名输入 */}
              <View className="mb-4">
                <Text className="text-sm text-muted-foreground mb-2">用户名</Text>
                <View className="bg-input rounded-xl border border-border px-4 py-3">
                  <Input
                    className="w-full text-foreground"
                    style={{padding: 0, border: 'none', background: 'transparent'}}
                    placeholder="请输入用户名"
                    value={username}
                    onInput={(e) => setUsername(e.detail.value)}
                  />
                </View>
              </View>

              {/* 密码输入 */}
              <View className="mb-4">
                <Text className="text-sm text-muted-foreground mb-2">密码</Text>
                <View className="bg-input rounded-xl border border-border px-4 py-3">
                  <Input
                    className="w-full text-foreground"
                    style={{padding: 0, border: 'none', background: 'transparent'}}
                    password
                    placeholder="请输入密码"
                    value={password}
                    onInput={(e) => setPassword(e.detail.value)}
                  />
                </View>
              </View>

              {/* 手机号输入（选填） */}
              <View className="mb-6">
                <Text className="text-sm text-muted-foreground mb-2">手机号（选填）</Text>
                <View className="bg-input rounded-xl border border-border px-4 py-3">
                  <Input
                    className="w-full text-foreground"
                    style={{padding: 0, border: 'none', background: 'transparent'}}
                    type="number"
                    maxlength={11}
                    placeholder="请输入手机号"
                    value={phone}
                    onInput={(e) => setPhone(e.detail.value)}
                  />
                </View>
              </View>

              {/* 协议勾选 */}
              <View className="flex items-center gap-2 mb-6" onClick={() => setAgreed(!agreed)}>
                <View
                  className={`w-5 h-5 rounded border-2 flex items-center justify-center ${agreed ? 'bg-primary border-primary' : 'border-border'}`}>
                  {agreed && <View className="i-mdi-check text-white text-sm" />}
                </View>
                <Text className="text-xs text-muted-foreground">我已阅读并同意《用户协议》和《隐私政策》</Text>
              </View>

              {/* 登录按钮 */}
              <Button
                className="w-full bg-primary text-white py-4 rounded-xl break-keep text-base mb-3"
                size="default"
                onClick={loading ? undefined : handleUsernameLogin}>
                {loading ? '登录中...' : '登录 / 注册'}
              </Button>

              {/* 返回按钮 */}
              <Button
                className="w-full bg-secondary text-foreground py-4 rounded-xl break-keep text-base"
                size="default"
                onClick={() => setShowPasswordLogin(false)}>
                返回
              </Button>
            </View>
          )}
        </View>

        {/* 提示文字 */}
        <Text className="text-center text-xs text-muted-foreground">首次登录将自动注册账号</Text>
      </View>
    </View>
  )
}
