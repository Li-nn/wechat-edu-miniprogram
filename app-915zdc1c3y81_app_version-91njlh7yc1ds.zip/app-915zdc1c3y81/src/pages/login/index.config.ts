export default {
  navigationBarTitleText: '登录'
}
