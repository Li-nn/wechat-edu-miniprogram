export default definePageConfig({
  navigationBarTitleText: '我的积分'
})
