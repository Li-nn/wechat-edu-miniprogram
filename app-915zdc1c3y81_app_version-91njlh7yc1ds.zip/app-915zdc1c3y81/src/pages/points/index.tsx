import {ScrollView, Text, View} from '@tarojs/components'
import Taro, {showToast, useDidShow} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {getTodayPointsSummary, getUserPointsRecords} from '@/db/api'
import type {DailyPointsSummary, PointsRecord} from '@/db/types'
import {useUserStore} from '@/store/userStore'

export default function Points() {
  const [records, setRecords] = useState<PointsRecord[]>([])
  const [todaySummary, setTodaySummary] = useState<DailyPointsSummary | null>(null)
  const {user, loadUser} = useUserStore()

  useDidShow(() => {
    checkAuth()
  })

  const loadData = useCallback(async () => {
    if (!user) return

    const [recordsData, summaryData] = await Promise.all([
      getUserPointsRecords(user.id),
      getTodayPointsSummary(user.id)
    ])

    setRecords(recordsData)
    setTodaySummary(summaryData)
  }, [user])

  const checkAuth = useCallback(async () => {
    await loadUser()
    if (!user) {
      showToast({title: '请先登录', icon: 'none'})
      Taro.navigateBack()
      return
    }
    loadData()
  }, [user, loadUser, loadData])

  // 格式化原因
  const formatReason = (reason: string) => {
    const reasonMap: Record<string, string> = {
      daily_login: '每日登录',
      share: '分享资料',
      download: '下载资料'
    }
    return reasonMap[reason] || reason
  }

  // 格式化时间
  const formatTime = (time: string) => {
    const date = new Date(time)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(diff / 3600000)
    const days = Math.floor(diff / 86400000)

    if (minutes < 1) return '刚刚'
    if (minutes < 60) return `${minutes}分钟前`
    if (hours < 24) return `${hours}小时前`
    if (days < 7) return `${days}天前`
    return date.toLocaleDateString()
  }

  if (!user) {
    return (
      <View className="min-h-screen bg-background flex items-center justify-center">
        <Text className="text-muted-foreground">加载中...</Text>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        {/* 积分卡片 */}
        <View className="px-6 py-6">
          <View className="bg-primary rounded-3xl p-8 border border-border mb-6">
            <View className="flex items-center justify-center mb-4">
              <View className="i-mdi-coin text-6xl text-yellow-300" />
            </View>
            <Text className="text-white text-center text-sm mb-2">当前积分</Text>
            <Text className="text-white text-center text-5xl font-bold mb-6">{user.points || 0}</Text>
            <View className="flex items-center justify-around border-t border-white border-opacity-20 pt-4">
              <View className="flex flex-col items-center">
                <Text className="text-white text-opacity-70 text-xs mb-1">今日已获得</Text>
                <Text className="text-white text-lg font-bold">{todaySummary?.earned_today || 0}</Text>
              </View>
              <View className="w-px h-8 bg-white bg-opacity-20" />
              <View className="flex flex-col items-center">
                <Text className="text-white text-opacity-70 text-xs mb-1">今日剩余</Text>
                <Text className="text-white text-lg font-bold">{20 - (todaySummary?.earned_today || 0)}</Text>
              </View>
            </View>
          </View>

          {/* 积分规则 */}
          <View className="bg-card rounded-2xl p-5 border border-border mb-6">
            <Text className="text-base font-bold text-foreground mb-4">积分规则</Text>
            <View className="flex flex-col gap-3">
              <View className="flex items-start gap-3">
                <View className="w-8 h-8 bg-primary bg-opacity-20 rounded-full flex items-center justify-center flex-shrink-0">
                  <View className="i-mdi-login text-lg text-primary" />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-bold text-foreground mb-1">每日登录</Text>
                  <Text className="text-xs text-muted-foreground">首次登录获得10积分</Text>
                </View>
              </View>
              <View className="flex items-start gap-3">
                <View className="w-8 h-8 bg-accent bg-opacity-20 rounded-full flex items-center justify-center flex-shrink-0">
                  <View className="i-mdi-share text-lg text-accent" />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-bold text-foreground mb-1">分享资料</Text>
                  <Text className="text-xs text-muted-foreground">每次分享获得10积分</Text>
                </View>
              </View>
              <View className="flex items-start gap-3">
                <View className="w-8 h-8 bg-destructive bg-opacity-20 rounded-full flex items-center justify-center flex-shrink-0">
                  <View className="i-mdi-download text-lg text-destructive" />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-bold text-foreground mb-1">下载资料</Text>
                  <Text className="text-xs text-muted-foreground">每次下载消耗5积分</Text>
                </View>
              </View>
            </View>
            <View className="mt-4 pt-4 border-t border-border">
              <Text className="text-xs text-muted-foreground text-center">每日获得积分上限为20积分</Text>
            </View>
          </View>

          {/* 积分记录 */}
          <View className="bg-card rounded-2xl p-5 border border-border">
            <Text className="text-base font-bold text-foreground mb-4">积分记录</Text>
            {records.length === 0 ? (
              <View className="flex flex-col items-center justify-center py-10">
                <View className="i-mdi-history text-6xl text-muted-foreground mb-4" />
                <Text className="text-muted-foreground">暂无积分记录</Text>
              </View>
            ) : (
              <View className="flex flex-col gap-3">
                {records.map((record) => (
                  <View key={record.id} className="flex items-center justify-between py-3 border-b border-border">
                    <View className="flex items-center gap-3 flex-1">
                      <View
                        className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          record.change_type === 'earn' ? 'bg-accent bg-opacity-20' : 'bg-destructive bg-opacity-20'
                        }`}>
                        <View
                          className={`text-xl ${
                            record.change_type === 'earn'
                              ? record.reason === 'daily_login'
                                ? 'i-mdi-login text-primary'
                                : 'i-mdi-share text-accent'
                              : 'i-mdi-download text-destructive'
                          }`}
                        />
                      </View>
                      <View className="flex-1">
                        <Text className="text-sm font-bold text-foreground mb-1">{formatReason(record.reason)}</Text>
                        <Text className="text-xs text-muted-foreground">{formatTime(record.created_at)}</Text>
                      </View>
                    </View>
                    <Text
                      className={`text-lg font-bold ${
                        record.change_type === 'earn' ? 'text-accent' : 'text-destructive'
                      }`}>
                      {record.change_type === 'earn' ? '+' : '-'}
                      {record.amount}
                    </Text>
                  </View>
                ))}
              </View>
            )}
          </View>
        </View>
      </ScrollView>

      {/* 底部导航栏 */}
      <View className="fixed bottom-0 left-0 right-0 bg-card border-t border-border safe-area-bottom">
        <View className="flex items-center justify-around py-3 px-6">
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.switchTab({url: '/pages/home/index'})}>
            <View className="i-mdi-home text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">首页</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/materials/index'})}>
            <View className="i-mdi-file-document text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">资料</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/courses/index'})}>
            <View className="i-mdi-video text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">课程</Text>
          </View>
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.navigateBack()}>
            <View className="i-mdi-arrow-left-circle text-2xl text-primary" />
            <Text className="text-xs text-primary">返回</Text>
          </View>
        </View>
      </View>
    </View>
  )
}
