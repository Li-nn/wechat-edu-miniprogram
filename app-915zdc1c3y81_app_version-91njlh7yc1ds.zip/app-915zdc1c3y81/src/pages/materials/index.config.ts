export default {
  navigationBarTitleText: '学习资料'
}
