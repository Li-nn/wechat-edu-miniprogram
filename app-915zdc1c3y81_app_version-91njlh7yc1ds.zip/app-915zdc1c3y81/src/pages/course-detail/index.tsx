import {Button, ScrollView, Text, Video, View} from '@tarojs/components'
import Taro, {showToast, useLoad} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {getCourseById, incrementCourseView, recordUserCourse} from '@/db/api'
import type {Course} from '@/db/types'
import {useUserStore} from '@/store/userStore'

export default function CourseDetail() {
  const [course, setCourse] = useState<Course | null>(null)
  const [_watchDuration, setWatchDuration] = useState(0)
  const {user, loadUser} = useUserStore()

  useLoad(async (options) => {
    const {id} = options
    if (id) {
      await loadUser()
      await loadCourse(id)
    }
  })

  // 加载课程详情
  const loadCourse = useCallback(async (id: string) => {
    const data = await getCourseById(id)
    if (data) {
      setCourse(data)
      await incrementCourseView(id)
    } else {
      showToast({title: '课程不存在', icon: 'none'})
      Taro.navigateBack()
    }
  }, [])

  // 视频播放进度更新
  const handleTimeUpdate = useCallback(
    (e) => {
      const currentTime = Math.floor(e.detail.currentTime)
      setWatchDuration(currentTime)

      if (user && course) {
        recordUserCourse(user.id, course.id, currentTime)
      }
    },
    [user, course]
  )

  // 购买课程
  const handlePurchase = useCallback(() => {
    if (!user) {
      Taro.setStorageSync('loginRedirectPath', `/pages/course-detail/index?id=${course?.id}`)
      Taro.navigateTo({url: '/pages/login/index'})
      return
    }

    showToast({title: '购买功能开发中', icon: 'none'})
  }, [user, course])

  // 格式化时长
  const formatDuration = useCallback((seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${minutes}:${secs.toString().padStart(2, '0')}`
  }, [])

  if (!course) {
    return (
      <View className="min-h-screen bg-background flex items-center justify-center">
        <Text className="text-muted-foreground">加载中...</Text>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        {/* 视频播放器 */}
        <View className="bg-black">
          {course.video_url.includes('bilibili.com') || course.video_url.includes('b23.tv') ? (
            <View className="w-full flex flex-col items-center justify-center bg-black" style={{height: '240px'}}>
              <View className="i-mdi-alert-circle text-6xl text-white mb-4" />
              <Text className="text-white text-sm mb-2">B站视频暂不支持直接播放</Text>
              <Text className="text-white text-xs text-opacity-70">请使用其他视频平台的直接播放链接</Text>
            </View>
          ) : (
            <Video
              src={course.video_url}
              className="w-full"
              style={{height: '240px'}}
              controls
              showCenterPlayBtn
              onTimeUpdate={handleTimeUpdate}
            />
          )}
        </View>

        {/* 课程信息 */}
        <View className="px-6 py-6">
          <View className="bg-card rounded-2xl p-6 border border-border mb-6">
            <View className="flex items-center justify-between mb-4">
              <Text className="text-2xl font-bold text-foreground break-keep flex-1">{course.title}</Text>
              {course.price > 0 && (
                <View className="bg-destructive px-4 py-2 rounded-full ml-4">
                  <Text className="text-white text-lg font-bold">¥{course.price}</Text>
                </View>
              )}
            </View>

            <View className="flex items-center gap-4 mb-4">
              <View className="flex items-center gap-1">
                <View className="i-mdi-clock-outline text-base text-muted-foreground" />
                <Text className="text-sm text-muted-foreground">总时长 {formatDuration(course.total_duration)}</Text>
              </View>
              <View className="flex items-center gap-1">
                <View className="i-mdi-eye text-base text-muted-foreground" />
                <Text className="text-sm text-muted-foreground">{course.view_count} 次观看</Text>
              </View>
            </View>

            {course.description && (
              <View className="border-t border-border pt-4">
                <Text className="text-sm font-bold text-foreground mb-2">课程介绍</Text>
                <Text className="text-sm text-muted-foreground leading-relaxed">{course.description}</Text>
              </View>
            )}
          </View>

          {/* 试看提示 */}
          <View className="bg-secondary rounded-2xl p-5 mb-6">
            <View className="flex items-center mb-3">
              <View className="i-mdi-information text-xl text-primary mr-2" />
              <Text className="text-base font-bold text-foreground">试看说明</Text>
            </View>
            <Text className="text-sm text-muted-foreground leading-relaxed">
              当前可免费试看前 {formatDuration(course.preview_duration)}，完整课程需要购买后观看。
            </Text>
          </View>

          {/* 学员案例 */}
          <View className="bg-card rounded-2xl p-6 border border-border mb-6">
            <Text className="text-base font-bold text-foreground mb-4">学员案例</Text>
            <View className="flex flex-col gap-4">
              <View className="flex items-start">
                <View className="w-10 h-10 bg-primary rounded-full flex items-center justify-center mr-3">
                  <View className="i-mdi-account text-xl text-white" />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-bold text-foreground mb-1">张同学</Text>
                  <Text className="text-xs text-muted-foreground">
                    通过学习本课程，成绩提升显著，从班级中游进步到前十名。
                  </Text>
                </View>
              </View>
              <View className="flex items-start">
                <View className="w-10 h-10 bg-accent rounded-full flex items-center justify-center mr-3">
                  <View className="i-mdi-account text-xl text-white" />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-bold text-foreground mb-1">李同学</Text>
                  <Text className="text-xs text-muted-foreground">
                    老师讲解清晰易懂，课程内容丰富，对考试帮助很大。
                  </Text>
                </View>
              </View>
            </View>
          </View>

          {/* 购买按钮 */}
          {course.price > 0 && (
            <Button
              className="w-full bg-primary text-white py-4 rounded-xl break-keep text-base"
              size="default"
              onClick={handlePurchase}>
              <View className="flex items-center justify-center gap-2">
                <View className="i-mdi-cart text-xl" />
                <Text>立即购买 ¥{course.price}</Text>
              </View>
            </Button>
          )}
        </View>
      </ScrollView>

      {/* 底部导航栏 */}
      <View className="fixed bottom-0 left-0 right-0 bg-card border-t border-border safe-area-bottom">
        <View className="flex items-center justify-around py-3 px-6">
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.switchTab({url: '/pages/home/index'})}>
            <View className="i-mdi-home text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">首页</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/materials/index'})}>
            <View className="i-mdi-file-document text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">资料</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/courses/index'})}>
            <View className="i-mdi-video text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">课程</Text>
          </View>
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.navigateBack()}>
            <View className="i-mdi-arrow-left-circle text-2xl text-primary" />
            <Text className="text-xs text-primary">返回</Text>
          </View>
        </View>
      </View>
    </View>
  )
}
