export default {
  navigationBarTitleText: '课程详情'
}
