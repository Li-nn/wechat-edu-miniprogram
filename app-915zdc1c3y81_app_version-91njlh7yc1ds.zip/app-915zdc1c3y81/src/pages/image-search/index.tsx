import {Image, ScrollView, Text, View} from '@tarojs/components'
import Taro, {chooseImage, showModal, showToast, useDidShow} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {supabase} from '@/client/supabase'
import {checkDailyImageSearchLimit, createImageSearchRecord, deductPoints} from '@/db/api'
import {useUserStore} from '@/store/userStore'

export default function ImageSearch() {
  const [imageUrl, setImageUrl] = useState('')
  const [answer, setAnswer] = useState('')
  const [uploading, setUploading] = useState(false)
  const [searching, setSearching] = useState(false)
  const [remainingCount, setRemainingCount] = useState(5)
  const {user, loadUser} = useUserStore()

  useDidShow(() => {
    checkAuth()
  })

  const checkLimit = useCallback(async () => {
    if (!user) return

    const {canUse, remaining} = await checkDailyImageSearchLimit(user.id)
    setRemainingCount(remaining)

    if (!canUse) {
      showModal({
        title: '使用次数已用完',
        content: '您今天的图片搜题次数已用完，明天再来吧！',
        showCancel: false
      })
    }
  }, [user])

  const checkAuth = useCallback(async () => {
    await loadUser()
    if (!user) {
      showToast({title: '请先登录', icon: 'none'})
      Taro.setStorageSync('loginRedirectPath', '/pages/image-search/index')
      setTimeout(() => {
        Taro.navigateTo({url: '/pages/login/index'})
      }, 1500)
      return
    }
    checkLimit()
  }, [user, loadUser, checkLimit])

  const handleSearch = useCallback(
    async (imgUrl: string) => {
      if (!user) return

      setSearching(true)
      setAnswer('')

      try {
        // 扣除积分
        const pointsDeducted = await deductPoints(user.id, 5, 'image_search')
        if (!pointsDeducted) {
          showToast({title: '积分扣除失败', icon: 'none'})
          return
        }

        // 记录搜题历史
        await createImageSearchRecord({
          user_id: user.id,
          image_url: imgUrl,
          answer:
            '这是一道数学题的解答示例...\n\n解题步骤：\n1. 首先分析题目条件\n2. 列出已知条件和未知量\n3. 选择合适的解题方法\n4. 逐步求解\n5. 验证答案\n\n答案：...'
        })

        // 模拟AI解答（实际应该调用AI接口）
        setTimeout(() => {
          setAnswer(
            '这是一道数学题的解答示例...\n\n解题步骤：\n1. 首先分析题目条件\n2. 列出已知条件和未知量\n3. 选择合适的解题方法\n4. 逐步求解\n5. 验证答案\n\n答案：...'
          )
          setSearching(false)

          // 更新剩余次数
          checkLimit()

          // 刷新用户信息（更新积分）
          loadUser()

          showToast({title: '搜题成功，已扣除5积分', icon: 'success'})
        }, 2000)
      } catch (error) {
        console.error('搜题失败:', error)
        showToast({title: '搜题失败，请重试', icon: 'none'})
        setSearching(false)
      }
    },
    [user, checkLimit, loadUser]
  )

  const handleChooseImage = useCallback(async () => {
    if (!user) {
      showToast({title: '请先登录', icon: 'none'})
      return
    }

    // 检查使用次数
    const {canUse} = await checkDailyImageSearchLimit(user.id)
    if (!canUse) {
      showModal({
        title: '使用次数已用完',
        content: '您今天的图片搜题次数已用完，明天再来吧！',
        showCancel: false
      })
      return
    }

    // 检查积分
    if (user.points < 5) {
      showModal({
        title: '积分不足',
        content: '图片搜题需要消耗5积分，您的积分不足，请先获取积分。',
        showCancel: false
      })
      return
    }

    try {
      const res = await chooseImage({
        count: 1,
        sizeType: ['compressed'],
        sourceType: ['album', 'camera']
      })

      if (res.tempFilePaths.length === 0) return

      const filePath = res.tempFilePaths[0]
      const fileSystemManager = Taro.getFileSystemManager()

      setUploading(true)
      const fileName = `search_${Date.now()}.jpg`

      // 读取文件并上传到Supabase
      const fileData = fileSystemManager.readFileSync(filePath, 'base64') as string
      const buffer = Taro.base64ToArrayBuffer(fileData)
      const blob = new Blob([buffer], {type: 'image/jpeg'})

      const {error} = await supabase.storage.from('app-915zdc1c3y81_search_images').upload(fileName, blob, {
        contentType: 'image/jpeg',
        upsert: false
      })

      if (error) {
        console.error('上传图片失败:', error)
        showToast({title: `上传失败: ${error.message}`, icon: 'none'})
        return
      }

      // 获取公开URL
      const {data: urlData} = supabase.storage.from('app-915zdc1c3y81_search_images').getPublicUrl(fileName)

      setImageUrl(urlData.publicUrl)
      showToast({title: '图片上传成功', icon: 'success'})

      // 自动开始搜题
      handleSearch(urlData.publicUrl)
    } catch (err) {
      console.error('选择图片异常:', err)
      showToast({title: '上传失败，请重试', icon: 'none'})
    } finally {
      setUploading(false)
    }
  }, [user, handleSearch])

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        <View className="px-6 py-8 pb-24">
          {/* 使用提示 */}
          <View className="bg-card rounded-2xl p-4 mb-6 border border-border">
            <View className="flex items-center justify-between mb-2">
              <View className="flex items-center">
                <View className="i-mdi-information text-xl text-primary mr-2" />
                <Text className="text-sm font-bold text-foreground">使用说明</Text>
              </View>
              <View className="flex items-center">
                <Text className="text-xs text-muted-foreground mr-2">今日剩余</Text>
                <Text className="text-lg font-bold text-primary">{remainingCount}</Text>
                <Text className="text-xs text-muted-foreground ml-1">次</Text>
              </View>
            </View>
            <Text className="text-xs text-muted-foreground leading-relaxed">
              • 每次搜题消耗5积分{'\n'}• 每天限制使用5次{'\n'}• 图片大小不超过5MB
            </Text>
          </View>

          {/* 上传图片区域 */}
          <View className="bg-card rounded-2xl p-6 mb-6 border border-border">
            <Text className="text-base font-bold text-foreground mb-4">上传图片</Text>
            {imageUrl ? (
              <View className="relative">
                <Image src={imageUrl} mode="aspectFit" className="w-full h-64 rounded-xl bg-secondary" />
                <View
                  className="absolute top-2 right-2 bg-destructive px-3 py-1 rounded-lg"
                  onClick={() => {
                    setImageUrl('')
                    setAnswer('')
                  }}>
                  <Text className="text-white text-xs">重新上传</Text>
                </View>
              </View>
            ) : (
              <View
                className="bg-secondary border-2 border-dashed border-primary rounded-xl h-48 flex flex-col items-center justify-center"
                onClick={handleChooseImage}>
                <View className="i-mdi-camera-plus text-6xl text-primary mb-3" />
                <Text className="text-primary text-base font-bold">{uploading ? '上传中...' : '点击上传图片'}</Text>
                <Text className="text-muted-foreground text-xs mt-2">支持拍照或从相册选择</Text>
              </View>
            )}
          </View>

          {/* 解答区域 */}
          <View className="bg-card rounded-2xl p-6 border border-border">
            <Text className="text-base font-bold text-foreground mb-4">解答区域</Text>
            {searching ? (
              <View className="flex flex-col items-center justify-center py-20">
                <View className="i-mdi-loading text-5xl text-primary animate-spin mb-4" />
                <Text className="text-muted-foreground">AI正在分析题目...</Text>
              </View>
            ) : answer ? (
              <View className="bg-secondary rounded-xl p-4">
                <Text className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">{answer}</Text>
              </View>
            ) : (
              <View className="flex flex-col items-center justify-center py-20">
                <View className="i-mdi-text-box-search text-5xl text-muted-foreground mb-4" />
                <Text className="text-muted-foreground">上传图片后将显示解答</Text>
              </View>
            )}
          </View>
        </View>
      </ScrollView>

      {/* 底部导航栏 */}
      <View className="fixed bottom-0 left-0 right-0 bg-card border-t border-border safe-area-bottom">
        <View className="flex items-center justify-around py-3">
          <View className="flex flex-col items-center" onClick={() => Taro.switchTab({url: '/pages/home/index'})}>
            <View className="i-mdi-home text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground mt-1">首页</Text>
          </View>
          <View className="flex flex-col items-center" onClick={() => Taro.switchTab({url: '/pages/materials/index'})}>
            <View className="i-mdi-file-document text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground mt-1">资料</Text>
          </View>
          <View className="flex flex-col items-center" onClick={() => Taro.switchTab({url: '/pages/courses/index'})}>
            <View className="i-mdi-video text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground mt-1">课程</Text>
          </View>
          <View className="flex flex-col items-center" onClick={() => Taro.switchTab({url: '/pages/profile/index'})}>
            <View className="i-mdi-account text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground mt-1">我的</Text>
          </View>
        </View>
      </View>
    </View>
  )
}
