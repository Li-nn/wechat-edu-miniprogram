export default {
  navigationBarTitleText: '图片搜题'
}
