export default {
  navigationBarTitleText: '微信咨询'
}
