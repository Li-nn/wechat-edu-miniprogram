import {Image, ScrollView, Text, View} from '@tarojs/components'
import {setClipboardData, showToast, useDidShow} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {getSystemSettings} from '@/db/api'

export default function AdminWechat() {
  const [adminWechat, setAdminWechat] = useState('')
  const [qrCodeUrl, setQrCodeUrl] = useState('')
  const [loading, setLoading] = useState(true)

  useDidShow(() => {
    loadSettings()
  })

  const loadSettings = useCallback(async () => {
    setLoading(true)
    try {
      const settings = await getSystemSettings()
      if (settings) {
        setAdminWechat(settings.admin_wechat || '')
        setQrCodeUrl(settings.wechat_qr_code || '')
      }
    } catch (error) {
      console.error('加载设置失败:', error)
    } finally {
      setLoading(false)
    }
  }, [])

  const handleCopyWechat = useCallback(() => {
    if (!adminWechat) {
      showToast({title: '暂未设置微信号', icon: 'none'})
      return
    }
    setClipboardData({
      data: adminWechat,
      success: () => {
        showToast({title: '微信号已复制', icon: 'success'})
      }
    })
  }, [adminWechat])

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        <View className="px-6 py-8">
          {loading ? (
            <View className="flex flex-col items-center justify-center py-20">
              <Text className="text-muted-foreground">加载中...</Text>
            </View>
          ) : (
            <View className="bg-card rounded-2xl p-6 border border-border">
              <View className="flex items-center mb-6">
                <View className="i-mdi-wechat text-4xl text-accent mr-3" />
                <Text className="text-2xl font-bold text-foreground">添加客服微信</Text>
              </View>

              {adminWechat ? (
                <View>
                  {/* 微信号 */}
                  <View className="bg-secondary rounded-xl p-4 mb-6">
                    <Text className="text-sm text-muted-foreground mb-2">客服微信号</Text>
                    <View className="flex items-center justify-between">
                      <Text className="text-xl font-bold text-foreground">{adminWechat}</Text>
                      <View className="bg-primary px-4 py-2 rounded-lg" onClick={handleCopyWechat}>
                        <Text className="text-white text-sm">复制</Text>
                      </View>
                    </View>
                  </View>

                  {/* 二维码 */}
                  {qrCodeUrl && (
                    <View className="flex flex-col items-center">
                      <Text className="text-sm text-muted-foreground mb-4">扫描二维码添加</Text>
                      <View className="bg-white p-4 rounded-2xl border border-border">
                        <Image src={qrCodeUrl} mode="aspectFit" className="w-64 h-64" />
                      </View>
                    </View>
                  )}

                  {/* 提示信息 */}
                  <View className="bg-secondary rounded-xl p-4 mt-6">
                    <View className="flex items-start">
                      <View className="i-mdi-information text-xl text-primary mr-2 mt-0.5" />
                      <View className="flex-1">
                        <Text className="text-sm text-muted-foreground leading-relaxed">
                          请复制微信号或扫描二维码添加客服微信，我们将为您提供专业的咨询服务。
                        </Text>
                      </View>
                    </View>
                  </View>
                </View>
              ) : (
                <View className="flex flex-col items-center justify-center py-10">
                  <View className="i-mdi-alert-circle text-6xl text-muted-foreground mb-4" />
                  <Text className="text-muted-foreground text-center">
                    管理员暂未设置客服微信{'\n'}请联系管理员进行设置
                  </Text>
                </View>
              )}
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  )
}
