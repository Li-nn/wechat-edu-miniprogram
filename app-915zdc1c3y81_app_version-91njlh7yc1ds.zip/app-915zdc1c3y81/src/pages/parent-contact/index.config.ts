export default {
  navigationBarTitleText: '家长留资'
}
