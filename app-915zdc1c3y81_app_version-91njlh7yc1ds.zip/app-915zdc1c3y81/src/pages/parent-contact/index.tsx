import {Button, Input, ScrollView, Text, Textarea, View} from '@tarojs/components'
import Taro, {showToast} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {createParentContact, updateUserPhone} from '@/db/api'
import {useUserStore} from '@/store/userStore'

export default function ParentContact() {
  const [parentName, setParentName] = useState('')
  const [phone, setPhone] = useState('')
  const [studentName, setStudentName] = useState('')
  const [grade, setGrade] = useState('')
  const [notes, setNotes] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const {user, loadUser} = useUserStore()

  const handleSubmit = useCallback(async () => {
    // 验证必填项
    if (!parentName.trim()) {
      showToast({title: '请输入家长姓名', icon: 'none'})
      return
    }

    if (!phone.trim()) {
      showToast({title: '请输入联系电话', icon: 'none'})
      return
    }

    // 验证手机号格式
    const phoneRegex = /^1[3-9]\d{9}$/
    if (!phoneRegex.test(phone)) {
      showToast({title: '请输入正确的手机号', icon: 'none'})
      return
    }

    setSubmitting(true)
    try {
      await createParentContact({
        user_id: user?.id,
        parent_name: parentName,
        phone,
        student_name: studentName || null,
        grade: grade || null,
        notes: notes || null
      })

      // 如果用户已登录且未绑定手机号，同步手机号到用户信息
      if (user && !user.phone) {
        await updateUserPhone(user.id, phone)
        await loadUser()
      }

      showToast({title: '提交成功，我们会尽快联系您', icon: 'success', duration: 2000})

      // 延迟返回
      setTimeout(() => {
        Taro.navigateBack()
      }, 2000)
    } catch (error) {
      console.error('提交失败:', error)
      showToast({title: '提交失败，请重试', icon: 'none'})
    } finally {
      setSubmitting(false)
    }
  }, [parentName, phone, studentName, grade, notes, user, loadUser])

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        <View className="px-6 py-8">
          <View className="bg-card rounded-2xl p-6 border border-border">
            {/* 标题 */}
            <View className="flex items-center mb-6">
              <View className="i-mdi-account-edit text-4xl text-primary mr-3" />
              <Text className="text-2xl font-bold text-foreground">家长信息登记</Text>
            </View>

            {/* 表单 */}
            <View className="flex flex-col gap-4">
              {/* 家长姓名 */}
              <View>
                <Text className="text-sm font-bold text-foreground mb-2">
                  家长姓名 <Text className="text-destructive">*</Text>
                </Text>
                <View className="bg-input rounded-xl border border-border px-4 py-3">
                  <Input
                    className="w-full text-foreground"
                    style={{padding: 0, border: 'none', background: 'transparent'}}
                    placeholder="请输入家长姓名"
                    value={parentName}
                    onInput={(e) => setParentName(e.detail.value)}
                  />
                </View>
              </View>

              {/* 联系电话 */}
              <View>
                <Text className="text-sm font-bold text-foreground mb-2">
                  联系电话 <Text className="text-destructive">*</Text>
                </Text>
                <View className="bg-input rounded-xl border border-border px-4 py-3">
                  <Input
                    className="w-full text-foreground"
                    style={{padding: 0, border: 'none', background: 'transparent'}}
                    type="number"
                    placeholder="请输入手机号"
                    value={phone}
                    maxlength={11}
                    onInput={(e) => setPhone(e.detail.value)}
                  />
                </View>
              </View>

              {/* 学生姓名 */}
              <View>
                <Text className="text-sm font-bold text-foreground mb-2">学生姓名（选填）</Text>
                <View className="bg-input rounded-xl border border-border px-4 py-3">
                  <Input
                    className="w-full text-foreground"
                    style={{padding: 0, border: 'none', background: 'transparent'}}
                    placeholder="请输入学生姓名"
                    value={studentName}
                    onInput={(e) => setStudentName(e.detail.value)}
                  />
                </View>
              </View>

              {/* 年级 */}
              <View>
                <Text className="text-sm font-bold text-foreground mb-2">年级（选填）</Text>
                <View className="bg-input rounded-xl border border-border px-4 py-3">
                  <Input
                    className="w-full text-foreground"
                    style={{padding: 0, border: 'none', background: 'transparent'}}
                    placeholder="例如：三年级、初一、高二"
                    value={grade}
                    onInput={(e) => setGrade(e.detail.value)}
                  />
                </View>
              </View>

              {/* 备注 */}
              <View>
                <Text className="text-sm font-bold text-foreground mb-2">备注（选填）</Text>
                <View className="bg-input rounded-xl border border-border px-4 py-3">
                  <Textarea
                    className="w-full text-foreground"
                    style={{padding: 0, border: 'none', background: 'transparent', minHeight: '80px'}}
                    placeholder="请输入您的需求或问题"
                    value={notes}
                    onInput={(e) => setNotes(e.detail.value)}
                  />
                </View>
              </View>
            </View>

            {/* 提交按钮 */}
            <Button
              className="w-full bg-primary text-white py-4 rounded-xl break-keep text-base mt-6"
              size="default"
              onClick={submitting ? undefined : handleSubmit}>
              {submitting ? '提交中...' : '提交信息'}
            </Button>

            {/* 提示信息 */}
            <View className="bg-secondary rounded-xl p-4 mt-6">
              <View className="flex items-start">
                <View className="i-mdi-information text-xl text-primary mr-2 mt-0.5" />
                <View className="flex-1">
                  <Text className="text-sm text-muted-foreground leading-relaxed">
                    提交后，我们的客服人员会在24小时内与您联系，为您提供专业的教育咨询服务。
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  )
}
