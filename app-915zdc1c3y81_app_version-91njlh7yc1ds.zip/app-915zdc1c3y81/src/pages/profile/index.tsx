import {Button, Input, ScrollView, Text, View} from '@tarojs/components'
import Taro, {showModal, showToast, useDidShow} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {getTodayPointsSummary, getUserPointsRecords, updateUserPhone} from '@/db/api'
import type {DailyPointsSummary, PointsRecord} from '@/db/types'
import {useUserStore} from '@/store/userStore'

export default function Profile() {
  const {user, loadUser, logout, isAdmin} = useUserStore()
  const [_bindingPhone, setBindingPhone] = useState(false)
  const [records, setRecords] = useState<PointsRecord[]>([])
  const [todaySummary, setTodaySummary] = useState<DailyPointsSummary | null>(null)
  const [showPhoneInput, setShowPhoneInput] = useState(false)
  const [phoneInput, setPhoneInput] = useState('')

  useDidShow(() => {
    loadUser()
    loadPointsData()
  })

  // 加载积分数据
  const loadPointsData = useCallback(async () => {
    if (!user) return

    const [recordsData, summaryData] = await Promise.all([
      getUserPointsRecords(user.id),
      getTodayPointsSummary(user.id)
    ])

    setRecords(recordsData)
    setTodaySummary(summaryData)
  }, [user])

  // 处理绑定手机号
  const handleBindPhone = useCallback(async () => {
    if (!user) return

    if (user.phone) {
      showToast({title: '手机号已绑定，不支持修改', icon: 'none'})
      return
    }

    // 显示自定义输入弹窗
    setPhoneInput('')
    setShowPhoneInput(true)
  }, [user])

  // 确认绑定手机号
  const handleConfirmBindPhone = useCallback(async () => {
    if (!user) return

    const phone = phoneInput.trim()

    // 验证手机号格式
    const phoneRegex = /^1[3-9]\d{9}$/
    if (!phoneRegex.test(phone)) {
      showToast({title: '请输入正确的手机号', icon: 'none'})
      return
    }

    setBindingPhone(true)
    try {
      const success = await updateUserPhone(user.id, phone)
      if (success) {
        showToast({title: '绑定成功', icon: 'success'})
        await loadUser()
        setShowPhoneInput(false)
      } else {
        showToast({title: '绑定失败，请重试', icon: 'none'})
      }
    } catch (error) {
      console.error('绑定手机号失败:', error)
      showToast({title: '绑定失败，请重试', icon: 'none'})
    } finally {
      setBindingPhone(false)
    }
  }, [user, phoneInput, loadUser])

  // 处理退出登录
  const handleLogout = useCallback(async () => {
    const res = await showModal({
      title: '提示',
      content: '确定要退出登录吗？'
    })

    if (res.confirm) {
      await logout()
      Taro.navigateTo({url: '/pages/login/index'})
    }
  }, [logout])

  // 格式化原因
  const formatReason = (reason: string) => {
    const reasonMap: Record<string, string> = {
      daily_login: '每日登录',
      share: '分享资料',
      download: '下载资料',
      image_search: '图片搜题'
    }
    return reasonMap[reason] || reason
  }

  // 格式化时间
  const formatTime = (time: string) => {
    const date = new Date(time)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(diff / 3600000)
    const days = Math.floor(diff / 86400000)

    if (minutes < 1) return '刚刚'
    if (minutes < 60) return `${minutes}分钟前`
    if (hours < 24) return `${hours}小时前`
    if (days < 7) return `${days}天前`
    return date.toLocaleDateString()
  }

  // 跳转到管理后台
  const handleGoAdmin = useCallback(() => {
    Taro.navigateTo({url: '/pages/admin/index'})
  }, [])

  // 如果未登录，显示登录提示
  if (!user) {
    return (
      <View className="min-h-screen bg-background flex flex-col items-center justify-center p-6">
        <View className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mb-6">
          <View className="i-mdi-account text-6xl text-muted-foreground" />
        </View>
        <Text className="text-xl font-bold text-foreground mb-2">未登录</Text>
        <Text className="text-sm text-muted-foreground mb-6">登录后可查看更多内容</Text>
        <Button
          className="bg-primary text-white px-12 py-3 rounded-xl break-keep text-base"
          size="default"
          onClick={() => Taro.navigateTo({url: '/pages/login/index'})}>
          立即登录
        </Button>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        {/* 用户信息卡片 */}
        <View className="px-6 pt-8 pb-6 mb-6">
          <View className="bg-card border border-border rounded-2xl p-6">
            <View className="flex items-center">
              <View className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mr-4">
                <View className="i-mdi-account text-5xl text-muted-foreground" />
              </View>
              <View className="flex-1">
                <Text className="text-foreground text-xl font-bold mb-1">
                  {user.nickname || user.username || '用户'}
                </Text>
                <View className="flex items-center gap-2">
                  <View className={`px-3 py-1 rounded-full ${isAdmin ? 'bg-destructive' : 'bg-muted'}`}>
                    <Text className={`text-xs ${isAdmin ? 'text-white' : 'text-muted-foreground'}`}>
                      {isAdmin ? '管理员' : '普通用户'}
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* 管理员入口 */}
        {isAdmin && (
          <View className="px-6 mb-6">
            <View
              className="bg-card border border-border rounded-2xl p-5 flex items-center justify-between"
              onClick={handleGoAdmin}>
              <View className="flex items-center">
                <View className="w-12 h-12 bg-primary bg-opacity-10 rounded-xl flex items-center justify-center mr-4">
                  <View className="i-mdi-shield-crown text-2xl text-primary" />
                </View>
                <View>
                  <Text className="text-foreground text-base font-bold mb-1">管理后台</Text>
                  <Text className="text-muted-foreground text-xs">内容管理、数据统计</Text>
                </View>
              </View>
              <View className="i-mdi-chevron-right text-2xl text-muted-foreground" />
            </View>
          </View>
        )}

        {/* 功能菜单 */}
        <View className="px-6 mb-6">
          <View className="bg-card rounded-2xl border border-border overflow-hidden">
            <View className="px-5 py-4 border-b border-border flex items-center justify-between">
              <View className="flex items-center">
                <View className="i-mdi-account-circle text-xl text-primary mr-3" />
                <Text className="text-foreground">用户名</Text>
              </View>
              <Text className="text-muted-foreground">{user.username || '未设置'}</Text>
            </View>
            <View
              className="px-5 py-4 border-b border-border flex items-center justify-between"
              onClick={handleBindPhone}>
              <View className="flex items-center">
                <View className="i-mdi-phone text-xl text-primary mr-3" />
                <Text className="text-foreground">手机号</Text>
              </View>
              <View className="flex items-center gap-2">
                <Text className={user.phone ? 'text-muted-foreground' : 'text-primary'}>
                  {user.phone || '请绑定手机号'}
                </Text>
                {!user.phone && <View className="i-mdi-chevron-right text-base text-muted-foreground" />}
              </View>
            </View>
            <View className="px-5 py-4 flex items-center justify-between">
              <View className="flex items-center">
                <View className="i-mdi-calendar text-xl text-primary mr-3" />
                <Text className="text-foreground">注册时间</Text>
              </View>
              <Text className="text-muted-foreground">{new Date(user.created_at).toLocaleDateString()}</Text>
            </View>
          </View>
        </View>

        {/* 积分信息 */}
        <View className="px-6 mb-6">
          <View className="bg-card border border-border rounded-3xl p-6 mb-6">
            <View className="flex items-center justify-center mb-3">
              <View className="i-mdi-coin text-5xl text-yellow-500" />
            </View>
            <Text className="text-muted-foreground text-center text-sm mb-2">当前积分</Text>
            <Text className="text-foreground text-center text-4xl font-bold mb-4">{user.points || 0}</Text>
            <View className="flex items-center justify-around border-t border-border pt-4">
              <View className="flex flex-col items-center">
                <Text className="text-muted-foreground text-xs mb-1">今日已获得</Text>
                <Text className="text-foreground text-lg font-bold">{todaySummary?.earned_today || 0}</Text>
              </View>
              <View className="w-px h-8 bg-border" />
              <View className="flex flex-col items-center">
                <Text className="text-muted-foreground text-xs mb-1">今日剩余</Text>
                <Text className="text-foreground text-lg font-bold">{20 - (todaySummary?.earned_today || 0)}</Text>
              </View>
            </View>
          </View>

          {/* 积分规则 */}
          <View className="bg-card rounded-2xl p-5 border border-border mb-6">
            <Text className="text-base font-bold text-foreground mb-4">积分规则</Text>
            <View className="flex flex-col gap-3">
              <View className="flex items-start gap-3">
                <View className="w-8 h-8 bg-primary bg-opacity-20 rounded-full flex items-center justify-center flex-shrink-0">
                  <View className="i-mdi-login text-lg text-primary" />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-bold text-foreground mb-1">每日登录</Text>
                  <Text className="text-xs text-muted-foreground">首次登录获得10积分</Text>
                </View>
              </View>
              <View className="flex items-start gap-3">
                <View className="w-8 h-8 bg-accent bg-opacity-20 rounded-full flex items-center justify-center flex-shrink-0">
                  <View className="i-mdi-share text-lg text-accent" />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-bold text-foreground mb-1">分享资料</Text>
                  <Text className="text-xs text-muted-foreground">每次分享获得10积分</Text>
                </View>
              </View>
              <View className="flex items-start gap-3">
                <View className="w-8 h-8 bg-destructive bg-opacity-20 rounded-full flex items-center justify-center flex-shrink-0">
                  <View className="i-mdi-download text-lg text-destructive" />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-bold text-foreground mb-1">下载资料</Text>
                  <Text className="text-xs text-muted-foreground">每次下载消耗5积分</Text>
                </View>
              </View>
              <View className="flex items-start gap-3">
                <View className="w-8 h-8 bg-primary bg-opacity-20 rounded-full flex items-center justify-center flex-shrink-0">
                  <View className="i-mdi-image-search text-lg text-primary" />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-bold text-foreground mb-1">图片搜题</Text>
                  <Text className="text-xs text-muted-foreground">每次搜题消耗5积分</Text>
                </View>
              </View>
            </View>
            <View className="mt-4 pt-4 border-t border-border">
              <Text className="text-xs text-muted-foreground text-center">每日获得积分上限为20积分</Text>
            </View>
          </View>

          {/* 积分记录 */}
          <View className="bg-card rounded-2xl p-5 border border-border">
            <Text className="text-base font-bold text-foreground mb-4">积分记录</Text>
            {records.length === 0 ? (
              <View className="flex flex-col items-center justify-center py-10">
                <View className="i-mdi-history text-6xl text-muted-foreground mb-4" />
                <Text className="text-muted-foreground">暂无积分记录</Text>
              </View>
            ) : (
              <View className="flex flex-col gap-3">
                {records.slice(0, 10).map((record) => (
                  <View key={record.id} className="flex items-center justify-between py-3 border-b border-border">
                    <View className="flex items-center gap-3 flex-1">
                      <View
                        className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          record.change_type === 'earn' ? 'bg-accent bg-opacity-20' : 'bg-destructive bg-opacity-20'
                        }`}>
                        <View
                          className={`text-xl ${
                            record.change_type === 'earn'
                              ? record.reason === 'daily_login'
                                ? 'i-mdi-login text-primary'
                                : 'i-mdi-share text-accent'
                              : (record.reason as string) === 'image_search'
                                ? 'i-mdi-image-search text-destructive'
                                : 'i-mdi-download text-destructive'
                          }`}
                        />
                      </View>
                      <View className="flex-1">
                        <Text className="text-sm font-bold text-foreground mb-1">{formatReason(record.reason)}</Text>
                        <Text className="text-xs text-muted-foreground">{formatTime(record.created_at)}</Text>
                      </View>
                    </View>
                    <Text
                      className={`text-lg font-bold ${
                        record.change_type === 'earn' ? 'text-accent' : 'text-destructive'
                      }`}>
                      {record.change_type === 'earn' ? '+' : '-'}
                      {record.amount}
                    </Text>
                  </View>
                ))}
              </View>
            )}
          </View>
        </View>

        {/* 关于信息 */}
        <View className="px-6 mb-6">
          <View className="bg-card rounded-2xl p-5 border border-border">
            <Text className="text-base font-bold text-foreground mb-3">关于我们</Text>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-3">
              教育资源平台致力于为学生和家长提供优质的教育资源和在线学习服务。我们汇聚了海量的学习资料和精品课程，助力每一位学员的学业进步。
            </Text>
            <View className="flex items-center gap-2">
              <View className="i-mdi-email text-sm text-primary" />
              <Text className="text-xs text-muted-foreground">联系邮箱：support@education.com</Text>
            </View>
          </View>
        </View>

        {/* 退出登录按钮 */}
        <View className="px-6 pb-8">
          <Button
            className="w-full bg-card text-destructive py-4 rounded-xl break-keep text-base border border-border"
            size="default"
            onClick={handleLogout}>
            退出登录
          </Button>
        </View>
      </ScrollView>

      {/* 手机号绑定弹窗 */}
      {showPhoneInput && (
        <View className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <View className="bg-card rounded-2xl p-6 mx-6 w-full max-w-sm">
            <Text className="text-xl font-bold text-foreground mb-4 text-center">绑定手机号</Text>
            <Text className="text-sm text-muted-foreground mb-4 text-center">请输入11位手机号</Text>
            <View className="bg-input rounded-xl border border-border px-4 py-3 mb-6">
              <Input
                className="w-full text-foreground"
                style={{padding: 0, border: 'none', background: 'transparent'}}
                type="number"
                maxlength={11}
                placeholder="请输入手机号"
                value={phoneInput}
                onInput={(e) => setPhoneInput(e.detail.value)}
              />
            </View>
            <View className="flex gap-3">
              <Button
                className="flex-1 bg-secondary text-foreground py-3 rounded-xl break-keep text-base"
                size="default"
                onClick={() => setShowPhoneInput(false)}>
                取消
              </Button>
              <Button
                className="flex-1 bg-primary text-white py-3 rounded-xl break-keep text-base"
                size="default"
                onClick={handleConfirmBindPhone}>
                确定
              </Button>
            </View>
          </View>
        </View>
      )}
    </View>
  )
}
