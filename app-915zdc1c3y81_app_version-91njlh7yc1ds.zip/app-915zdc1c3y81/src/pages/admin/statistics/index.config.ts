export default {
  navigationBarTitleText: '数据统计'
}
