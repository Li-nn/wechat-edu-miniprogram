import {ScrollView, Text, View} from '@tarojs/components'
import Taro, {showToast, useDidShow} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {getStatistics, getUserLeads} from '@/db/api'
import type {Profile, Statistics} from '@/db/types'
import {useUserStore} from '@/store/userStore'

export default function AdminStatistics() {
  const [stats, setStats] = useState<Statistics | null>(null)
  const [leads, setLeads] = useState<Profile[]>([])
  const {user, isAdmin, loadUser} = useUserStore()

  useDidShow(() => {
    checkAuth()
  })

  const loadData = useCallback(async () => {
    const [statsData, leadsData] = await Promise.all([getStatistics(), getUserLeads()])
    setStats(statsData)
    setLeads(leadsData)
  }, [])

  const checkAuth = useCallback(async () => {
    await loadUser()
    if (!user || !isAdmin) {
      showToast({title: '无权限访问', icon: 'none'})
      Taro.navigateBack()
      return
    }
    loadData()
  }, [user, isAdmin, loadUser, loadData])

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        <View className="px-6 py-6">
          <Text className="text-xl font-bold text-foreground mb-6">数据统计</Text>

          {/* 核心数据 */}
          {stats && (
            <View className="mb-6">
              <Text className="text-base font-bold text-foreground mb-4">核心数据</Text>
              <View className="grid grid-cols-2 gap-4">
                <View className="bg-gradient-card rounded-2xl p-5 border border-border">
                  <View className="i-mdi-account-group text-3xl text-primary mb-2" />
                  <Text className="text-2xl font-bold text-foreground mb-1">{stats.totalUsers}</Text>
                  <Text className="text-xs text-muted-foreground">总用户数</Text>
                </View>
                <View className="bg-gradient-card rounded-2xl p-5 border border-border">
                  <View className="i-mdi-file-document text-3xl text-accent mb-2" />
                  <Text className="text-2xl font-bold text-foreground mb-1">{stats.totalMaterials}</Text>
                  <Text className="text-xs text-muted-foreground">资料数量</Text>
                </View>
                <View className="bg-gradient-card rounded-2xl p-5 border border-border">
                  <View className="i-mdi-video text-3xl text-chart-3 mb-2" />
                  <Text className="text-2xl font-bold text-foreground mb-1">{stats.totalCourses}</Text>
                  <Text className="text-xs text-muted-foreground">课程数量</Text>
                </View>
                <View className="bg-gradient-card rounded-2xl p-5 border border-border">
                  <View className="i-mdi-download text-3xl text-chart-4 mb-2" />
                  <Text className="text-2xl font-bold text-foreground mb-1">{stats.totalDownloads}</Text>
                  <Text className="text-xs text-muted-foreground">总下载量</Text>
                </View>
                <View className="bg-gradient-card rounded-2xl p-5 border border-border">
                  <View className="i-mdi-eye text-3xl text-chart-5 mb-2" />
                  <Text className="text-2xl font-bold text-foreground mb-1">{stats.totalViews}</Text>
                  <Text className="text-xs text-muted-foreground">总浏览量</Text>
                </View>
                <View className="bg-gradient-card rounded-2xl p-5 border border-border">
                  <View className="i-mdi-phone text-3xl text-primary mb-2" />
                  <Text className="text-2xl font-bold text-foreground mb-1">{leads.length}</Text>
                  <Text className="text-xs text-muted-foreground">留资用户</Text>
                </View>
              </View>
            </View>
          )}

          {/* 转化率 */}
          {stats && stats.totalUsers > 0 && (
            <View className="mb-6">
              <Text className="text-base font-bold text-foreground mb-4">转化数据</Text>
              <View className="bg-card rounded-2xl p-5 border border-border">
                <View className="flex items-center justify-between mb-4">
                  <Text className="text-sm text-muted-foreground">留资转化率</Text>
                  <Text className="text-lg font-bold text-primary">
                    {((leads.length / stats.totalUsers) * 100).toFixed(1)}%
                  </Text>
                </View>
                <View className="flex items-center justify-between mb-4">
                  <Text className="text-sm text-muted-foreground">人均下载量</Text>
                  <Text className="text-lg font-bold text-accent">
                    {(stats.totalDownloads / stats.totalUsers).toFixed(1)}
                  </Text>
                </View>
                <View className="flex items-center justify-between">
                  <Text className="text-sm text-muted-foreground">人均浏览量</Text>
                  <Text className="text-lg font-bold text-chart-3">
                    {(stats.totalViews / stats.totalUsers).toFixed(1)}
                  </Text>
                </View>
              </View>
            </View>
          )}

          {/* 留资用户列表 */}
          <View className="mb-6">
            <View className="flex items-center justify-between mb-4">
              <Text className="text-base font-bold text-foreground">留资用户</Text>
              <Text className="text-sm text-muted-foreground">共 {leads.length} 位</Text>
            </View>
            {leads.length === 0 ? (
              <View className="flex flex-col items-center justify-center py-20">
                <View className="i-mdi-account-off text-6xl text-muted-foreground mb-4" />
                <Text className="text-muted-foreground">暂无留资用户</Text>
              </View>
            ) : (
              <View className="flex flex-col gap-4">
                {leads.map((lead) => (
                  <View key={lead.id} className="bg-card rounded-2xl p-5 border border-border">
                    <View className="flex items-center justify-between mb-3">
                      <View className="flex items-center flex-1">
                        <View className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center mr-3">
                          <View className="i-mdi-account text-xl text-primary" />
                        </View>
                        <View className="flex-1">
                          <Text className="text-base font-bold text-foreground mb-1">
                            {lead.nickname || lead.username || '未命名'}
                          </Text>
                          <Text className="text-xs text-muted-foreground">{lead.phone}</Text>
                        </View>
                      </View>
                    </View>
                    <View className="border-t border-border pt-3">
                      <Text className="text-xs text-muted-foreground">
                        注册时间：{new Date(lead.created_at).toLocaleString()}
                      </Text>
                    </View>
                  </View>
                ))}
              </View>
            )}
          </View>

          {/* 导出提示 */}
          <View className="bg-secondary rounded-2xl p-5">
            <View className="flex items-center mb-3">
              <View className="i-mdi-information text-xl text-primary mr-2" />
              <Text className="text-base font-bold text-foreground">数据导出</Text>
            </View>
            <Text className="text-sm text-muted-foreground leading-relaxed">
              如需导出用户留资数据，请联系技术人员通过数据库导出功能获取完整的CSV或Excel文件。
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* 底部导航栏 */}
      <View className="fixed bottom-0 left-0 right-0 bg-card border-t border-border safe-area-bottom">
        <View className="flex items-center justify-around py-3 px-6">
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.switchTab({url: '/pages/home/index'})}>
            <View className="i-mdi-home text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">首页</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/materials/index'})}>
            <View className="i-mdi-file-document text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">资料</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/courses/index'})}>
            <View className="i-mdi-video text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">课程</Text>
          </View>
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.navigateBack()}>
            <View className="i-mdi-arrow-left-circle text-2xl text-primary" />
            <Text className="text-xs text-primary">返回</Text>
          </View>
        </View>
      </View>
    </View>
  )
}
