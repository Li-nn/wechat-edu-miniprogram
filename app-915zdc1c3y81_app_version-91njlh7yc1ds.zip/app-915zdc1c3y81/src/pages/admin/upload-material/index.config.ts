export default {
  navigationBarTitleText: '上传资料'
}
