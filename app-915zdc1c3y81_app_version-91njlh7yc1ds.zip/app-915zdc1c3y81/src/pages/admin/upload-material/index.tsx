import {Button, Input, Picker, ScrollView, Text, Textarea, View} from '@tarojs/components'
import Taro, {chooseImage, chooseMessageFile, showToast, useDidShow} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {supabase} from '@/client/supabase'
import {createMaterial, getMaterialCategories, getSubjectCategories} from '@/db/api'
import type {MaterialCategory, SubjectCategory} from '@/db/types'
import {useUserStore} from '@/store/userStore'

export default function UploadMaterial() {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [categories, setCategories] = useState<MaterialCategory[]>([])
  const [subjects, setSubjects] = useState<SubjectCategory[]>([])
  const [selectedCategoryIndex, setSelectedCategoryIndex] = useState(-1)
  const [selectedSubjectIndex, setSelectedSubjectIndex] = useState(-1)
  const [coverImage, setCoverImage] = useState('')
  const [fileUrl, setFileUrl] = useState('')
  const [fileType, setFileType] = useState('pdf')
  const [uploading, setUploading] = useState(false)
  const {user, isAdmin, loadUser} = useUserStore()

  useDidShow(() => {
    checkAuth()
  })

  const loadCategories = useCallback(async () => {
    const [categoriesData, subjectsData] = await Promise.all([getMaterialCategories(), getSubjectCategories()])
    setCategories(categoriesData)
    setSubjects(subjectsData)
  }, [])

  const checkAuth = useCallback(async () => {
    await loadUser()
    if (!user || !isAdmin) {
      showToast({title: '无权限访问', icon: 'none'})
      Taro.navigateBack()
      return
    }
    loadCategories()
  }, [user, isAdmin, loadUser, loadCategories])

  // 上传封面图片
  const handleUploadCover = useCallback(async () => {
    try {
      const res = await chooseImage({
        count: 1,
        sizeType: ['compressed'],
        sourceType: ['album', 'camera']
      })

      if (res.tempFilePaths.length === 0) return

      setUploading(true)
      const filePath = res.tempFilePaths[0]
      const fileName = `material_cover_${Date.now()}.jpg`

      // 读取文件并上传到Supabase
      const fileSystemManager = Taro.getFileSystemManager()
      const fileData = fileSystemManager.readFileSync(filePath, 'base64') as string
      const buffer = Taro.base64ToArrayBuffer(fileData)
      const blob = new Blob([buffer], {type: 'image/jpeg'})

      const {error} = await supabase.storage.from('app-915zdc1c3y81_images').upload(fileName, blob, {
        contentType: 'image/jpeg',
        upsert: false
      })

      if (error) {
        console.error('上传封面失败:', error)
        showToast({title: `上传失败: ${error.message}`, icon: 'none'})
        return
      }

      // 获取公开URL
      const {data: urlData} = supabase.storage.from('app-915zdc1c3y81_images').getPublicUrl(fileName)

      setCoverImage(urlData.publicUrl)
      showToast({title: '封面上传成功', icon: 'success'})
    } catch (err) {
      console.error('上传封面异常:', err)
      showToast({title: '上传失败，请重试', icon: 'none'})
    } finally {
      setUploading(false)
    }
  }, [])

  // 上传文件
  const handleUploadFile = useCallback(async () => {
    try {
      const res = await chooseMessageFile({
        count: 1,
        type: 'file'
      })

      if (res.tempFiles.length === 0) return

      setUploading(true)
      const file = res.tempFiles[0]
      const ext = file.name.split('.').pop() || 'pdf'
      const fileName = `material_${Date.now()}.${ext}`

      // 读取文件并上传到Supabase
      const fileSystemManager = Taro.getFileSystemManager()
      const fileData = fileSystemManager.readFileSync(file.path, 'base64') as string
      const buffer = Taro.base64ToArrayBuffer(fileData)

      // 根据文件扩展名确定MIME类型
      const mimeTypes: Record<string, string> = {
        pdf: 'application/pdf',
        doc: 'application/msword',
        docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        xls: 'application/vnd.ms-excel',
        xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ppt: 'application/vnd.ms-powerpoint',
        pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        txt: 'text/plain'
      }
      const contentType = mimeTypes[ext.toLowerCase()] || 'application/octet-stream'
      const blob = new Blob([buffer], {type: contentType})

      const {error} = await supabase.storage.from('app-915zdc1c3y81_files').upload(fileName, blob, {
        contentType,
        upsert: false
      })

      if (error) {
        console.error('上传文件失败:', error)
        showToast({title: `上传失败: ${error.message}`, icon: 'none'})
        return
      }

      // 获取公开URL
      const {data: urlData} = supabase.storage.from('app-915zdc1c3y81_files').getPublicUrl(fileName)

      setFileUrl(urlData.publicUrl)
      setFileType(ext)
      showToast({title: '文件上传成功', icon: 'success'})
    } catch (err) {
      console.error('上传文件异常:', err)
      showToast({title: '上传失败，请重试', icon: 'none'})
    } finally {
      setUploading(false)
    }
  }, [])

  // 提交资料
  const handleSubmit = useCallback(async () => {
    // 只验证标题为必填项
    if (!title.trim()) {
      showToast({title: '请输入资料标题', icon: 'none'})
      return
    }

    setUploading(true)
    const success = await createMaterial({
      title: title.trim(),
      description: description.trim() || null,
      cover_image: coverImage || null,
      file_url: fileUrl || null,
      file_type: fileType,
      category_id: selectedCategoryIndex >= 0 ? categories[selectedCategoryIndex]?.id : null,
      subject_id: selectedSubjectIndex >= 0 ? subjects[selectedSubjectIndex]?.id : null,
      is_active: true
    })

    setUploading(false)

    if (success) {
      showToast({title: '资料上传成功', icon: 'success'})
      // 清空表单
      setTitle('')
      setDescription('')
      setCoverImage('')
      setFileUrl('')
      setSelectedCategoryIndex(-1)
      setSelectedSubjectIndex(-1)
    } else {
      showToast({title: '上传失败，请重试', icon: 'none'})
    }
  }, [
    title,
    description,
    coverImage,
    fileUrl,
    fileType,
    categories,
    subjects,
    selectedCategoryIndex,
    selectedSubjectIndex
  ])

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        <View className="px-6 py-6">
          <Text className="text-xl font-bold text-foreground mb-6">上传资料</Text>

          {/* 资料标题 - 必填 */}
          <View className="mb-6">
            <View className="flex items-center gap-2 mb-2">
              <Text className="text-sm font-bold text-foreground">资料标题</Text>
              <Text className="text-xs text-destructive">*必填</Text>
            </View>
            <View className="bg-input rounded-xl border border-border px-4 py-3">
              <Input
                className="w-full text-foreground"
                style={{padding: 0, border: 'none', background: 'transparent'}}
                placeholder="请输入资料标题"
                value={title}
                onInput={(e) => setTitle(e.detail.value)}
              />
            </View>
          </View>

          {/* 资料描述 - 选填 */}
          <View className="mb-6">
            <View className="flex items-center gap-2 mb-2">
              <Text className="text-sm font-bold text-foreground">资料描述</Text>
              <Text className="text-xs text-muted-foreground">选填</Text>
            </View>
            <View className="bg-input rounded-xl border border-border px-4 py-3">
              <Textarea
                className="w-full text-foreground"
                style={{padding: 0, border: 'none', background: 'transparent', minHeight: '80px'}}
                placeholder="请输入资料描述（选填）"
                value={description}
                onInput={(e) => setDescription(e.detail.value)}
              />
            </View>
          </View>

          {/* 年级分类 - 选填 */}
          <View className="mb-6">
            <View className="flex items-center gap-2 mb-2">
              <Text className="text-sm font-bold text-foreground">年级分类</Text>
              <Text className="text-xs text-muted-foreground">选填</Text>
            </View>
            <Picker
              mode="selector"
              range={categories.map((c) => c.name)}
              value={selectedCategoryIndex >= 0 ? selectedCategoryIndex : 0}
              onChange={(e) => setSelectedCategoryIndex(Number(e.detail.value))}>
              <View className="bg-input rounded-xl border border-border px-4 py-3 flex items-center justify-between">
                <Text className={selectedCategoryIndex >= 0 ? 'text-foreground' : 'text-muted-foreground'}>
                  {selectedCategoryIndex >= 0 ? categories[selectedCategoryIndex]?.name : '请选择年级（选填）'}
                </Text>
                <View className="i-mdi-chevron-down text-xl text-muted-foreground" />
              </View>
            </Picker>
          </View>

          {/* 学科分类 - 选填 */}
          <View className="mb-6">
            <View className="flex items-center gap-2 mb-2">
              <Text className="text-sm font-bold text-foreground">学科分类</Text>
              <Text className="text-xs text-muted-foreground">选填</Text>
            </View>
            <Picker
              mode="selector"
              range={subjects.map((s) => s.name)}
              value={selectedSubjectIndex >= 0 ? selectedSubjectIndex : 0}
              onChange={(e) => setSelectedSubjectIndex(Number(e.detail.value))}>
              <View className="bg-input rounded-xl border border-border px-4 py-3 flex items-center justify-between">
                <Text className={selectedSubjectIndex >= 0 ? 'text-foreground' : 'text-muted-foreground'}>
                  {selectedSubjectIndex >= 0 ? subjects[selectedSubjectIndex]?.name : '请选择学科（选填）'}
                </Text>
                <View className="i-mdi-chevron-down text-xl text-muted-foreground" />
              </View>
            </Picker>
          </View>

          {/* 上传封面 - 选填 */}
          <View className="mb-6">
            <View className="flex items-center gap-2 mb-2">
              <Text className="text-sm font-bold text-foreground">封面图片</Text>
              <Text className="text-xs text-muted-foreground">选填</Text>
            </View>
            <Button
              className="w-full bg-secondary text-foreground py-4 rounded-xl break-keep text-base"
              size="default"
              onClick={handleUploadCover}
              disabled={uploading}>
              <View className="flex items-center justify-center gap-2">
                <View className="i-mdi-image-plus text-xl" />
                <Text>{coverImage ? '重新上传封面' : '上传封面图片（选填）'}</Text>
              </View>
            </Button>
            {coverImage && (
              <View className="mt-3 bg-card rounded-xl p-3">
                <Text className="text-xs text-accent">✓ 封面已上传</Text>
              </View>
            )}
          </View>

          {/* 上传文件 - 选填 */}
          <View className="mb-6">
            <View className="flex items-center gap-2 mb-2">
              <Text className="text-sm font-bold text-foreground">资料文件</Text>
              <Text className="text-xs text-muted-foreground">选填</Text>
            </View>
            <Button
              className="w-full bg-secondary text-foreground py-4 rounded-xl break-keep text-base"
              size="default"
              onClick={handleUploadFile}
              disabled={uploading}>
              <View className="flex items-center justify-center gap-2">
                <View className="i-mdi-file-upload text-xl" />
                <Text>{fileUrl ? '重新上传文件' : '上传资料文件（选填）'}</Text>
              </View>
            </Button>
            {fileUrl && (
              <View className="mt-3 bg-card rounded-xl p-3">
                <Text className="text-xs text-accent">✓ 文件已上传 ({fileType})</Text>
              </View>
            )}
          </View>

          {/* 提交按钮 */}
          <Button
            className="w-full bg-primary text-white py-4 rounded-xl break-keep text-base"
            size="default"
            onClick={handleSubmit}
            disabled={uploading}>
            {uploading ? '上传中...' : '提交资料'}
          </Button>

          {/* 提示信息 */}
          <View className="bg-secondary rounded-2xl p-5 mt-6">
            <View className="flex items-center mb-3">
              <View className="i-mdi-information text-xl text-primary mr-2" />
              <Text className="text-base font-bold text-foreground">上传说明</Text>
            </View>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              1. 标题为必填项，其他字段均为选填
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              2. 年级分类：小五、小六、初一、初二、初三、高一、高二、高三
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              3. 学科分类：数学、物理、化学、英语、语文、生物、地理、政治、历史
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              4. 封面图片支持JPG、PNG格式，建议尺寸16:9
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed">
              5. 资料文件支持PDF、Word、Excel等格式，文件大小限制为10MB以内
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* 底部导航栏 */}
      <View className="fixed bottom-0 left-0 right-0 bg-card border-t border-border safe-area-bottom">
        <View className="flex items-center justify-around py-3 px-6">
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.switchTab({url: '/pages/home/index'})}>
            <View className="i-mdi-home text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">首页</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/materials/index'})}>
            <View className="i-mdi-file-document text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">资料</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/courses/index'})}>
            <View className="i-mdi-video text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">课程</Text>
          </View>
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.navigateBack()}>
            <View className="i-mdi-arrow-left-circle text-2xl text-primary" />
            <Text className="text-xs text-primary">返回</Text>
          </View>
        </View>
      </View>
    </View>
  )
}
