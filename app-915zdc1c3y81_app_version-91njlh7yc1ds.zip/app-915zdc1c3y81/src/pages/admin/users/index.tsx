import {ScrollView, Text, View} from '@tarojs/components'
import Taro, {showModal, showToast, useDidShow} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {getAllUsers, updateUserRole} from '@/db/api'
import type {Profile} from '@/db/types'
import {useUserStore} from '@/store/userStore'

export default function AdminUsers() {
  const [users, setUsers] = useState<Profile[]>([])
  const {user, isAdmin, loadUser} = useUserStore()

  useDidShow(() => {
    checkAuth()
  })

  const loadUsers = useCallback(async () => {
    const data = await getAllUsers()
    setUsers(data)
  }, [])

  const checkAuth = useCallback(async () => {
    await loadUser()
    if (!user || !isAdmin) {
      showToast({title: '无权限访问', icon: 'none'})
      Taro.navigateBack()
      return
    }
    loadUsers()
  }, [isAdmin, loadUser, user, loadUsers])

  // 切换用户角色
  const handleToggleRole = useCallback(
    async (userId: string, currentRole: string) => {
      if (userId === user?.id) {
        showToast({title: '不能修改自己的角色', icon: 'none'})
        return
      }

      const newRole = currentRole === 'admin' ? 'user' : 'admin'
      const res = await showModal({
        title: '确认操作',
        content: `确定要将该用户设置为${newRole === 'admin' ? '管理员' : '普通用户'}吗？`
      })

      if (res.confirm) {
        const success = await updateUserRole(userId, newRole)
        if (success) {
          showToast({title: '修改成功', icon: 'success'})
          loadUsers()
        } else {
          showToast({title: '修改失败', icon: 'none'})
        }
      }
    },
    [user, loadUsers]
  )

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        <View className="px-6 py-6">
          <View className="flex items-center justify-between mb-6">
            <Text className="text-xl font-bold text-foreground">用户管理</Text>
            <Text className="text-sm text-muted-foreground">共 {users.length} 位用户</Text>
          </View>

          {users.length === 0 ? (
            <View className="flex flex-col items-center justify-center py-20">
              <View className="i-mdi-account-off text-6xl text-muted-foreground mb-4" />
              <Text className="text-muted-foreground">暂无用户</Text>
            </View>
          ) : (
            <View className="flex flex-col gap-4">
              {users.map((u) => (
                <View key={u.id} className="bg-card rounded-2xl p-5 border border-border">
                  <View className="flex items-center justify-between mb-4">
                    <View className="flex items-center flex-1">
                      <View className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center mr-3">
                        <View className="i-mdi-account text-2xl text-primary" />
                      </View>
                      <View className="flex-1">
                        <Text className="text-base font-bold text-foreground mb-1">
                          {u.nickname || u.username || '未命名'}
                        </Text>
                        <Text className="text-xs text-muted-foreground">{u.username || '无用户名'}</Text>
                      </View>
                    </View>
                    <View
                      className={`px-3 py-1 rounded-full ${u.role === 'admin' ? 'bg-destructive' : 'bg-secondary'}`}
                      onClick={() => handleToggleRole(u.id, u.role)}>
                      <Text className={`text-xs ${u.role === 'admin' ? 'text-white' : 'text-secondary-foreground'}`}>
                        {u.role === 'admin' ? '管理员' : '普通用户'}
                      </Text>
                    </View>
                  </View>

                  <View className="border-t border-border pt-3 flex flex-col gap-2">
                    <View className="flex items-center justify-between">
                      <Text className="text-xs text-muted-foreground">手机号</Text>
                      <Text className="text-xs text-foreground">{u.phone || '未绑定'}</Text>
                    </View>
                    <View className="flex items-center justify-between">
                      <Text className="text-xs text-muted-foreground">注册时间</Text>
                      <Text className="text-xs text-foreground">{new Date(u.created_at).toLocaleDateString()}</Text>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          )}
        </View>
      </ScrollView>

      {/* 底部导航栏 */}
      <View className="fixed bottom-0 left-0 right-0 bg-card border-t border-border safe-area-bottom">
        <View className="flex items-center justify-around py-3 px-6">
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.switchTab({url: '/pages/home/index'})}>
            <View className="i-mdi-home text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">首页</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/materials/index'})}>
            <View className="i-mdi-file-document text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">资料</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/courses/index'})}>
            <View className="i-mdi-video text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">课程</Text>
          </View>
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.navigateBack()}>
            <View className="i-mdi-arrow-left-circle text-2xl text-primary" />
            <Text className="text-xs text-primary">返回</Text>
          </View>
        </View>
      </View>
    </View>
  )
}
