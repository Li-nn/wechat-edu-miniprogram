export default {
  navigationBarTitleText: '用户管理'
}
