export default {
  navigationBarTitleText: '上传课程'
}
