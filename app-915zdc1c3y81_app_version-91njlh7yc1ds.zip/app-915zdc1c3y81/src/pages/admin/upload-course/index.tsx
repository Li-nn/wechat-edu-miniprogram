import {Button, Input, Picker, ScrollView, Text, Textarea, View} from '@tarojs/components'
import Taro, {chooseImage, chooseMessageFile, showToast, uploadFile, useDidShow} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {createCourse, getCourseCategories, getSubjectCategories} from '@/db/api'
import type {CourseCategory, SubjectCategory} from '@/db/types'
import {useUserStore} from '@/store/userStore'

export default function UploadCourse() {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [coverImage, setCoverImage] = useState('')
  const [videoUrl, setVideoUrl] = useState('')
  const [videoType, setVideoType] = useState<'upload' | 'link'>('link')
  const [price, setPrice] = useState('')
  const [duration, setDuration] = useState('')
  const [trialDuration, setTrialDuration] = useState('')
  const [categories, setCategories] = useState<CourseCategory[]>([])
  const [subjects, setSubjects] = useState<SubjectCategory[]>([])
  const [selectedCategoryIndex, setSelectedCategoryIndex] = useState(0)
  const [selectedSubjectIndex, setSelectedSubjectIndex] = useState(0)
  const [uploading, setUploading] = useState(false)
  const {user, isAdmin, loadUser} = useUserStore()

  useDidShow(() => {
    checkAuth()
  })

  // 加载分类数据
  const loadCategories = useCallback(async () => {
    const [categoryData, subjectData] = await Promise.all([getCourseCategories(), getSubjectCategories()])
    setCategories(categoryData)
    setSubjects(subjectData)
  }, [])

  const checkAuth = useCallback(async () => {
    await loadUser()
    if (!user || !isAdmin) {
      showToast({title: '无权限访问', icon: 'none'})
      Taro.navigateBack()
      return
    }
    loadCategories()
  }, [isAdmin, loadUser, user, loadCategories])

  // 选择封面图片
  const handleChooseCover = useCallback(async () => {
    try {
      const res = await chooseImage({
        count: 1,
        sizeType: ['compressed'],
        sourceType: ['album', 'camera']
      })

      if (res.tempFilePaths.length > 0) {
        setCoverImage(res.tempFilePaths[0])
        showToast({title: '封面已选择', icon: 'success'})
      }
    } catch (err) {
      console.error('选择封面失败:', err)
    }
  }, [])

  // 选择视频文件
  const handleChooseVideo = useCallback(async () => {
    try {
      const res = await chooseMessageFile({
        count: 1,
        type: 'video'
      })

      if (res.tempFiles.length > 0) {
        const file = res.tempFiles[0]
        // 检查文件大小（限制100MB）
        if (file.size > 100 * 1024 * 1024) {
          showToast({title: '视频文件不能超过100MB，建议使用视频链接', icon: 'none', duration: 3000})
          return
        }
        setVideoUrl(file.path)
        showToast({title: '视频已选择', icon: 'success'})
      }
    } catch (err) {
      console.error('选择视频失败:', err)
    }
  }, [])

  // 上传文件到Supabase Storage
  const uploadToStorage = useCallback(async (filePath: string, bucket: string, folder: string): Promise<string> => {
    const fileName = `${folder}/${Date.now()}_${Math.random().toString(36).substring(7)}`

    // 使用Taro的uploadFile API上传
    const supabaseUrl = 'https://backend.appmiaoda.com/projects/supabase271462636267290624'
    const supabaseKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJhdXRoZW50aWNhdGVkIiwiZXhwIjoyMDg0MTQ4OTM2LCJpc3MiOiJzdXBhYmFzZSIsInJvbGUiOiJhbm9uIiwic3ViIjoiYW5vbiJ9.lnkjXzyQw7xF5tbMo3drC7krD7T03H3wYwzAC0LLFhs'

    const uploadRes = await uploadFile({
      url: `${supabaseUrl}/storage/v1/object/${bucket}/${fileName}`,
      filePath: filePath,
      name: 'file',
      header: {
        Authorization: `Bearer ${supabaseKey}`,
        'Content-Type': 'multipart/form-data'
      }
    })

    if (uploadRes.statusCode !== 200) {
      throw new Error('上传失败')
    }

    return `${supabaseUrl}/storage/v1/object/public/${bucket}/${fileName}`
  }, [])

  // 提交课程
  const handleSubmit = useCallback(async () => {
    // 只验证标题必填
    if (!title.trim()) {
      showToast({title: '请输入课程标题', icon: 'none'})
      return
    }

    setUploading(true)
    try {
      let finalCoverUrl: string | null = null
      let finalVideoUrl: string | null = null

      // 上传封面图片
      if (coverImage) {
        showToast({title: '正在上传封面...', icon: 'loading', duration: 10000})
        finalCoverUrl = await uploadToStorage(coverImage, 'app-915zdc1c3y81_courses', 'covers')
      }

      // 处理视频
      if (videoUrl) {
        if (videoType === 'upload') {
          // 上传视频文件
          showToast({title: '正在上传视频...', icon: 'loading', duration: 30000})
          finalVideoUrl = await uploadToStorage(videoUrl, 'app-915zdc1c3y81_courses', 'videos')
        } else {
          // 直接使用视频链接
          finalVideoUrl = videoUrl
        }
      }

      // 创建课程
      const course = await createCourse({
        title: title.trim(),
        description: description.trim() || null,
        cover_image: finalCoverUrl,
        video_url: finalVideoUrl || '',
        price: price ? parseFloat(price) : 0,
        preview_duration: trialDuration ? parseInt(trialDuration, 10) : 0,
        total_duration: duration ? parseInt(duration, 10) : 0,
        category_id: categories[selectedCategoryIndex]?.id || null,
        subject_id: subjects[selectedSubjectIndex]?.id || null,
        is_active: true
      })

      if (course) {
        showToast({title: '课程上传成功', icon: 'success'})
        // 清空表单
        setTitle('')
        setDescription('')
        setCoverImage('')
        setVideoUrl('')
        setPrice('')
        setDuration('')
        setTrialDuration('')
        setSelectedCategoryIndex(0)
        setSelectedSubjectIndex(0)
        // 返回上一页
        setTimeout(() => {
          Taro.navigateBack()
        }, 1500)
      } else {
        showToast({title: '课程上传失败', icon: 'none'})
      }
    } catch (error) {
      console.error('上传课程失败:', error)
      showToast({title: '上传失败，请重试', icon: 'none'})
    } finally {
      setUploading(false)
    }
  }, [
    title,
    description,
    coverImage,
    videoUrl,
    videoType,
    price,
    duration,
    trialDuration,
    categories,
    subjects,
    selectedCategoryIndex,
    selectedSubjectIndex,
    uploadToStorage
  ])

  return (
    <View className="min-h-screen bg-background pb-32">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        <View className="px-6 py-6">
          <Text className="text-xl font-bold text-foreground mb-6">上传新课程</Text>

          {/* 课程标题 */}
          <View className="mb-6">
            <Text className="text-sm font-bold text-foreground mb-2">课程标题 *必填</Text>
            <View className="bg-input rounded-xl border border-border px-4 py-3">
              <Input
                className="w-full text-foreground"
                placeholder="请输入课程标题"
                value={title}
                onInput={(e) => setTitle(e.detail.value)}
                maxlength={100}
              />
            </View>
          </View>

          {/* 课程描述 */}
          <View className="mb-6">
            <Text className="text-sm font-bold text-foreground mb-2">课程描述 选填</Text>
            <View className="bg-input rounded-xl border border-border px-4 py-3">
              <Textarea
                className="w-full text-foreground"
                style={{minHeight: '100px'}}
                placeholder="请输入课程描述"
                value={description}
                onInput={(e) => setDescription(e.detail.value)}
                maxlength={500}
              />
            </View>
          </View>

          {/* 年级分类 */}
          <View className="mb-6">
            <Text className="text-sm font-bold text-foreground mb-2">年级分类 选填</Text>
            <Picker
              mode="selector"
              range={categories.map((c) => c.name)}
              onChange={(e) => setSelectedCategoryIndex(Number(e.detail.value))}>
              <View className="bg-input rounded-xl border border-border px-4 py-3">
                <Text className="text-foreground">{categories[selectedCategoryIndex]?.name || '请选择年级分类'}</Text>
              </View>
            </Picker>
          </View>

          {/* 学科分类 */}
          <View className="mb-6">
            <Text className="text-sm font-bold text-foreground mb-2">学科分类 选填</Text>
            <Picker
              mode="selector"
              range={subjects.map((s) => s.name)}
              onChange={(e) => setSelectedSubjectIndex(Number(e.detail.value))}>
              <View className="bg-input rounded-xl border border-border px-4 py-3">
                <Text className="text-foreground">{subjects[selectedSubjectIndex]?.name || '请选择学科分类'}</Text>
              </View>
            </Picker>
          </View>

          {/* 封面图片 */}
          <View className="mb-6">
            <Text className="text-sm font-bold text-foreground mb-2">封面图片 选填</Text>
            <Button
              className="w-full bg-secondary text-foreground py-3 rounded-xl break-keep text-sm"
              size="default"
              onClick={handleChooseCover}>
              {coverImage ? '已选择封面' : '选择封面图片'}
            </Button>
          </View>

          {/* 视频类型选择 */}
          <View className="mb-6">
            <Text className="text-sm font-bold text-foreground mb-2">视频来源 选填</Text>
            <View className="flex gap-3">
              <View
                className={`flex-1 py-3 rounded-xl text-center ${videoType === 'link' ? 'bg-primary' : 'bg-secondary'}`}
                onClick={() => setVideoType('link')}>
                <Text className={videoType === 'link' ? 'text-white font-bold' : 'text-foreground'}>视频链接</Text>
              </View>
              <View
                className={`flex-1 py-3 rounded-xl text-center ${videoType === 'upload' ? 'bg-primary' : 'bg-secondary'}`}
                onClick={() => setVideoType('upload')}>
                <Text className={videoType === 'upload' ? 'text-white font-bold' : 'text-foreground'}>上传视频</Text>
              </View>
            </View>
          </View>

          {/* 视频链接或上传 */}
          {videoType === 'link' ? (
            <View className="mb-6">
              <Text className="text-sm font-bold text-foreground mb-2">视频链接 选填</Text>
              <View className="bg-input rounded-xl border border-border px-4 py-3">
                <Input
                  className="w-full text-foreground"
                  placeholder="请输入视频链接（支持B站、抖音、视频号等）"
                  value={videoUrl}
                  onInput={(e) => setVideoUrl(e.detail.value)}
                />
              </View>
              <Text className="text-xs text-muted-foreground mt-2">
                推荐使用第三方平台视频链接，可节省存储空间并获得更好的播放体验
              </Text>
            </View>
          ) : (
            <View className="mb-6">
              <Text className="text-sm font-bold text-foreground mb-2">上传视频 选填</Text>
              <Button
                className="w-full bg-secondary text-foreground py-3 rounded-xl break-keep text-sm"
                size="default"
                onClick={handleChooseVideo}>
                {videoUrl ? '已选择视频' : '选择视频文件'}
              </Button>
              <Text className="text-xs text-destructive mt-2">注意：视频文件限制100MB以内，建议使用视频链接</Text>
            </View>
          )}

          {/* 课程价格 */}
          <View className="mb-6">
            <Text className="text-sm font-bold text-foreground mb-2">课程价格（元） 选填</Text>
            <View className="bg-input rounded-xl border border-border px-4 py-3">
              <Input
                className="w-full text-foreground"
                type="digit"
                placeholder="请输入价格，0表示免费"
                value={price}
                onInput={(e) => setPrice(e.detail.value)}
              />
            </View>
          </View>

          {/* 课程时长 */}
          <View className="mb-6">
            <Text className="text-sm font-bold text-foreground mb-2">课程时长（分钟） 选填</Text>
            <View className="bg-input rounded-xl border border-border px-4 py-3">
              <Input
                className="w-full text-foreground"
                type="number"
                placeholder="请输入课程总时长"
                value={duration}
                onInput={(e) => setDuration(e.detail.value)}
              />
            </View>
          </View>

          {/* 试看时长 */}
          <View className="mb-6">
            <Text className="text-sm font-bold text-foreground mb-2">试看时长（分钟） 选填</Text>
            <View className="bg-input rounded-xl border border-border px-4 py-3">
              <Input
                className="w-full text-foreground"
                type="number"
                placeholder="请输入试看时长"
                value={trialDuration}
                onInput={(e) => setTrialDuration(e.detail.value)}
              />
            </View>
          </View>

          {/* 提交按钮 */}
          <Button
            className="w-full bg-primary text-white py-4 rounded-xl break-keep text-base mb-6"
            size="default"
            onClick={handleSubmit}
            disabled={uploading}>
            {uploading ? '上传中...' : '提交课程'}
          </Button>

          {/* 上传说明 */}
          <View className="bg-secondary rounded-2xl p-5">
            <View className="flex items-center mb-3">
              <View className="i-mdi-information text-xl text-primary mr-2" />
              <Text className="text-base font-bold text-foreground">上传说明</Text>
            </View>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              1. 标题为必填项，其他字段均为选填
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              2. 年级分类：小五、小六、初一、初二、初三、高一、高二、高三
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              3. 学科分类：数学、物理、化学、英语、语文、生物、地理、政治、历史
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              4. 视频来源：推荐使用视频链接（B站、抖音、视频号等），可节省存储空间
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              5. 如需上传视频文件，限制100MB以内，建议先压缩或使用第三方平台
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed">
              6. 封面图片支持JPG、PNG格式，建议尺寸16:9
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* 底部导航栏 */}
      <View className="fixed bottom-0 left-0 right-0 bg-card border-t border-border safe-area-bottom">
        <View className="flex items-center justify-around py-3 px-6">
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.switchTab({url: '/pages/home/index'})}>
            <View className="i-mdi-home text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">首页</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/materials/index'})}>
            <View className="i-mdi-file-document text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">资料</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/courses/index'})}>
            <View className="i-mdi-video text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">课程</Text>
          </View>
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.navigateBack()}>
            <View className="i-mdi-arrow-left-circle text-2xl text-primary" />
            <Text className="text-xs text-primary">返回</Text>
          </View>
        </View>
      </View>
    </View>
  )
}
