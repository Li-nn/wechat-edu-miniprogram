export default {
  navigationBarTitleText: '内容管理'
}
