import {Button, ScrollView, Text, View} from '@tarojs/components'
import Taro, {showModal, showToast, useDidShow} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {deleteBanner, deleteCourse, deleteMaterial, getActiveCourses, getActiveMaterials, getAllBanners} from '@/db/api'
import type {Banner, Course, Material} from '@/db/types'
import {useUserStore} from '@/store/userStore'

export default function AdminContent() {
  const [activeTab, setActiveTab] = useState<'banner' | 'material' | 'course'>('banner')
  const [banners, setBanners] = useState<Banner[]>([])
  const [materials, setMaterials] = useState<Material[]>([])
  const [courses, setCourses] = useState<Course[]>([])
  const {user, isAdmin, loadUser} = useUserStore()

  useDidShow(() => {
    checkAuth()
  })

  const loadData = useCallback(async () => {
    const [bannersData, materialsData, coursesData] = await Promise.all([
      getAllBanners(),
      getActiveMaterials(),
      getActiveCourses()
    ])
    setBanners(bannersData)
    setMaterials(materialsData)
    setCourses(coursesData)
  }, [])

  const checkAuth = useCallback(async () => {
    await loadUser()
    if (!user || !isAdmin) {
      showToast({title: '无权限访问', icon: 'none'})
      Taro.navigateBack()
      return
    }
    loadData()
  }, [user, isAdmin, loadUser, loadData])

  // 删除轮播图
  const handleDeleteBanner = useCallback(
    async (id: string) => {
      const res = await showModal({
        title: '确认删除',
        content: '删除后无法恢复，确定要删除这个轮播图吗？'
      })

      if (!res.confirm) return

      const success = await deleteBanner(id)
      if (success) {
        showToast({title: '删除成功', icon: 'success'})
        loadData()
      } else {
        showToast({title: '删除失败', icon: 'none'})
      }
    },
    [loadData]
  )

  // 删除资料
  const handleDeleteMaterial = useCallback(
    async (id: string) => {
      const res = await showModal({
        title: '确认删除',
        content: '删除后无法恢复，确定要删除这个资料吗？'
      })

      if (!res.confirm) return

      const success = await deleteMaterial(id)
      if (success) {
        showToast({title: '删除成功', icon: 'success'})
        loadData()
      } else {
        showToast({title: '删除失败', icon: 'none'})
      }
    },
    [loadData]
  )

  // 删除课程
  const handleDeleteCourse = useCallback(
    async (id: string) => {
      const res = await showModal({
        title: '确认删除',
        content: '删除后无法恢复，确定要删除这个课程吗？'
      })

      if (!res.confirm) return

      const success = await deleteCourse(id)
      if (success) {
        showToast({title: '删除成功', icon: 'success'})
        loadData()
      } else {
        showToast({title: '删除失败', icon: 'none'})
      }
    },
    [loadData]
  )

  const tabs = [
    {key: 'banner', label: '轮播图', icon: 'i-mdi-image-multiple'},
    {key: 'material', label: '资料', icon: 'i-mdi-file-document'},
    {key: 'course', label: '课程', icon: 'i-mdi-video'}
  ]

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        <View className="px-6 py-6">
          <Text className="text-xl font-bold text-foreground mb-6">内容管理</Text>

          {/* 标签切换 */}
          <View className="flex gap-3 mb-6">
            {tabs.map((tab) => (
              <View
                key={tab.key}
                className={`flex-1 py-3 rounded-xl flex items-center justify-center ${activeTab === tab.key ? 'bg-primary' : 'bg-card'}`}
                onClick={() => setActiveTab(tab.key as any)}>
                <View
                  className={`${tab.icon} text-xl mr-2 ${activeTab === tab.key ? 'text-white' : 'text-foreground'}`}
                />
                <Text className={`text-sm font-medium ${activeTab === tab.key ? 'text-white' : 'text-foreground'}`}>
                  {tab.label}
                </Text>
              </View>
            ))}
          </View>

          {/* 轮播图列表 */}
          {activeTab === 'banner' && (
            <View>
              {/* 快捷操作 */}
              <View className="bg-card rounded-2xl p-5 mb-6">
                <Text className="text-base font-bold text-foreground mb-4">快捷操作</Text>
                <Button
                  className="w-full bg-primary text-white py-4 rounded-xl break-keep text-base"
                  size="default"
                  onClick={() => Taro.navigateTo({url: '/pages/admin/manage-banner/index'})}>
                  <View className="flex items-center justify-center gap-2">
                    <View className="i-mdi-plus-circle text-xl" />
                    <Text>新增轮播图</Text>
                  </View>
                </Button>
              </View>

              <View className="flex items-center justify-between mb-4">
                <Text className="text-base font-bold text-foreground">轮播图列表</Text>
                <Text className="text-sm text-muted-foreground">共 {banners.length} 个</Text>
              </View>
              {banners.length === 0 ? (
                <View className="flex flex-col items-center justify-center py-20">
                  <View className="i-mdi-image-off text-6xl text-muted-foreground mb-4" />
                  <Text className="text-muted-foreground">暂无轮播图</Text>
                </View>
              ) : (
                <View className="flex flex-col gap-4">
                  {banners.map((banner) => (
                    <View key={banner.id} className="bg-card rounded-2xl p-4 border border-border">
                      <View className="flex items-start justify-between mb-3">
                        <View className="flex-1 mr-3">
                          <Text className="text-base font-bold text-foreground mb-2">{banner.title}</Text>
                          {banner.link_url && (
                            <Text className="text-sm text-muted-foreground line-clamp-1">{banner.link_url}</Text>
                          )}
                        </View>
                      </View>
                      <View className="flex items-center justify-between">
                        <View className="flex items-center gap-3">
                          <View className={`px-3 py-1 rounded-full ${banner.is_active ? 'bg-accent' : 'bg-muted'}`}>
                            <Text className={`text-xs ${banner.is_active ? 'text-white' : 'text-muted-foreground'}`}>
                              {banner.is_active ? '已启用' : '已禁用'}
                            </Text>
                          </View>
                          <Text className="text-xs text-muted-foreground">排序: {banner.sort_order}</Text>
                        </View>
                        <View className="flex items-center gap-2">
                          <View
                            className="bg-destructive px-3 py-1 rounded-lg"
                            onClick={() => handleDeleteBanner(banner.id)}>
                            <Text className="text-white text-xs">删除</Text>
                          </View>
                        </View>
                      </View>
                    </View>
                  ))}
                </View>
              )}
            </View>
          )}

          {/* 资料列表 */}
          {activeTab === 'material' && (
            <View>
              {/* 快捷操作 */}
              <View className="bg-card rounded-2xl p-5 mb-6">
                <Text className="text-base font-bold text-foreground mb-4">快捷操作</Text>
                <Button
                  className="w-full bg-primary text-white py-4 rounded-xl break-keep text-base"
                  size="default"
                  onClick={() => Taro.navigateTo({url: '/pages/admin/upload-material/index'})}>
                  <View className="flex items-center justify-center gap-2">
                    <View className="i-mdi-plus-circle text-xl" />
                    <Text>上传新资料</Text>
                  </View>
                </Button>
              </View>

              <View className="flex items-center justify-between mb-4">
                <Text className="text-base font-bold text-foreground">资料列表</Text>
                <Text className="text-sm text-muted-foreground">共 {materials.length} 个</Text>
              </View>
              {materials.length === 0 ? (
                <View className="flex flex-col items-center justify-center py-20">
                  <View className="i-mdi-folder-off text-6xl text-muted-foreground mb-4" />
                  <Text className="text-muted-foreground">暂无资料</Text>
                </View>
              ) : (
                <View className="flex flex-col gap-4">
                  {materials.map((material) => (
                    <View key={material.id} className="bg-card rounded-2xl p-4 border border-border">
                      <View className="flex items-start justify-between mb-3">
                        <View className="flex-1 mr-3">
                          <Text className="text-base font-bold text-foreground mb-2">{material.title}</Text>
                          {material.description && (
                            <Text className="text-sm text-muted-foreground line-clamp-2">{material.description}</Text>
                          )}
                        </View>
                      </View>
                      <View className="flex items-center justify-between">
                        <View className="flex items-center gap-3">
                          <View className="flex items-center gap-1">
                            <View className="i-mdi-eye text-sm text-muted-foreground" />
                            <Text className="text-xs text-muted-foreground">{material.view_count}</Text>
                          </View>
                          <View className="flex items-center gap-1">
                            <View className="i-mdi-download text-sm text-muted-foreground" />
                            <Text className="text-xs text-muted-foreground">{material.download_count}</Text>
                          </View>
                          <View className={`px-3 py-1 rounded-full ${material.is_active ? 'bg-accent' : 'bg-muted'}`}>
                            <Text className={`text-xs ${material.is_active ? 'text-white' : 'text-muted-foreground'}`}>
                              {material.is_active ? '已启用' : '已禁用'}
                            </Text>
                          </View>
                        </View>
                        <View className="flex items-center gap-2">
                          <View
                            className="bg-destructive px-3 py-1 rounded-lg"
                            onClick={() => handleDeleteMaterial(material.id)}>
                            <Text className="text-white text-xs">删除</Text>
                          </View>
                        </View>
                      </View>
                    </View>
                  ))}
                </View>
              )}
            </View>
          )}

          {/* 课程列表 */}
          {activeTab === 'course' && (
            <View>
              {/* 快捷操作 */}
              <View className="bg-card rounded-2xl p-5 mb-6">
                <Text className="text-base font-bold text-foreground mb-4">快捷操作</Text>
                <Button
                  className="w-full bg-accent text-white py-4 rounded-xl break-keep text-base"
                  size="default"
                  onClick={() => Taro.navigateTo({url: '/pages/admin/upload-course/index'})}>
                  <View className="flex items-center justify-center gap-2">
                    <View className="i-mdi-plus-circle text-xl" />
                    <Text>上传新课程</Text>
                  </View>
                </Button>
              </View>

              <View className="flex items-center justify-between mb-4">
                <Text className="text-base font-bold text-foreground">课程列表</Text>
                <Text className="text-sm text-muted-foreground">共 {courses.length} 个</Text>
              </View>
              {courses.length === 0 ? (
                <View className="flex flex-col items-center justify-center py-20">
                  <View className="i-mdi-video-off text-6xl text-muted-foreground mb-4" />
                  <Text className="text-muted-foreground">暂无课程</Text>
                </View>
              ) : (
                <View className="flex flex-col gap-4">
                  {courses.map((course) => (
                    <View key={course.id} className="bg-card rounded-2xl p-4 border border-border">
                      <View className="flex items-start justify-between mb-3">
                        <View className="flex-1 mr-3">
                          <Text className="text-base font-bold text-foreground mb-2">{course.title}</Text>
                          {course.description && (
                            <Text className="text-sm text-muted-foreground line-clamp-2">{course.description}</Text>
                          )}
                        </View>
                      </View>
                      <View className="flex items-center justify-between">
                        <View className="flex items-center gap-3">
                          <View className="flex items-center gap-1">
                            <View className="i-mdi-eye text-sm text-muted-foreground" />
                            <Text className="text-xs text-muted-foreground">{course.view_count}</Text>
                          </View>
                          {course.price > 0 && (
                            <View className="bg-destructive px-3 py-1 rounded-full">
                              <Text className="text-white text-xs">¥{course.price}</Text>
                            </View>
                          )}
                          <View className={`px-3 py-1 rounded-full ${course.is_active ? 'bg-accent' : 'bg-muted'}`}>
                            <Text className={`text-xs ${course.is_active ? 'text-white' : 'text-muted-foreground'}`}>
                              {course.is_active ? '已启用' : '已禁用'}
                            </Text>
                          </View>
                        </View>
                        <View className="flex items-center gap-2">
                          <View
                            className="bg-destructive px-3 py-1 rounded-lg"
                            onClick={() => handleDeleteCourse(course.id)}>
                            <Text className="text-white text-xs">删除</Text>
                          </View>
                        </View>
                      </View>
                    </View>
                  ))}
                </View>
              )}
            </View>
          )}

          {/* 提示信息 */}
          <View className="bg-secondary rounded-2xl p-5 mt-6">
            <View className="flex items-center mb-3">
              <View className="i-mdi-information text-xl text-primary mr-2" />
              <Text className="text-base font-bold text-foreground">功能说明</Text>
            </View>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              1. 点击上方"快捷操作"中的按钮可以直接在小程序中添加内容
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              2. 课程视频支持两种方式：上传视频文件（限100MB）或使用第三方平台链接
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed">
              3. 推荐使用B站、抖音、视频号等平台的视频链接，可节省存储空间并获得更好的播放体验
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* 底部导航栏 */}
      <View className="fixed bottom-0 left-0 right-0 bg-card border-t border-border safe-area-bottom">
        <View className="flex items-center justify-around py-3 px-6">
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.switchTab({url: '/pages/home/index'})}>
            <View className="i-mdi-home text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">首页</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/materials/index'})}>
            <View className="i-mdi-file-document text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">资料</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.switchTab({url: '/pages/courses/index'})}>
            <View className="i-mdi-video text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">课程</Text>
          </View>
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.navigateBack()}>
            <View className="i-mdi-arrow-left-circle text-2xl text-primary" />
            <Text className="text-xs text-primary">返回</Text>
          </View>
        </View>
      </View>
    </View>
  )
}
