export default definePageConfig({
  navigationBarTitleText: '轮播图管理'
})
