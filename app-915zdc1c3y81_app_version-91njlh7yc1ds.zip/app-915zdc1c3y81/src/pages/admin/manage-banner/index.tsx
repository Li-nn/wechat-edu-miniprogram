import {Button, Image, Input, Picker, ScrollView, Text, View} from '@tarojs/components'
import Taro, {chooseImage, showToast, useLoad} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {supabase} from '@/client/supabase'
import {getActiveCourses, getActiveMaterials} from '@/db/api'
import type {Course, Material} from '@/db/types'
import {useUserStore} from '@/store/userStore'

export default function ManageBanner() {
  const [title, setTitle] = useState('')
  const [imageUrl, setImageUrl] = useState('')
  const [linkType, setLinkType] = useState<'none' | 'material' | 'course'>('none')
  const [linkId, setLinkId] = useState('')
  const [sortOrder, setSortOrder] = useState('0')
  const [isActive, setIsActive] = useState(true)
  const [uploading, setUploading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [materials, setMaterials] = useState<Material[]>([])
  const [courses, setCourses] = useState<Course[]>([])
  const [selectedMaterialIndex, setSelectedMaterialIndex] = useState(0)
  const [selectedCourseIndex, setSelectedCourseIndex] = useState(0)
  const {user, isAdmin, loadUser} = useUserStore()

  useLoad(async () => {
    await loadUser()
    if (!user || !isAdmin) {
      showToast({title: '无权限访问', icon: 'none'})
      Taro.navigateBack()
      return
    }

    // 加载资料和课程列表
    const [materialsData, coursesData] = await Promise.all([getActiveMaterials(), getActiveCourses()])
    setMaterials(materialsData)
    setCourses(coursesData)
  })

  // 上传图片
  const uploadImage = useCallback(async (filePath: string) => {
    setUploading(true)
    try {
      const fileName = `banner_${Date.now()}.jpg`

      // 读取文件并上传到Supabase
      const fileSystemManager = Taro.getFileSystemManager()
      const fileData = fileSystemManager.readFileSync(filePath, 'base64') as string
      const buffer = Taro.base64ToArrayBuffer(fileData)
      const blob = new Blob([buffer], {type: 'image/jpeg'})

      const {error} = await supabase.storage.from('banners').upload(fileName, blob, {
        contentType: 'image/jpeg',
        upsert: false
      })

      if (error) {
        showToast({title: '图片上传失败', icon: 'none'})
        return
      }

      // 获取公开URL
      const {data: urlData} = supabase.storage.from('banners').getPublicUrl(fileName)

      setImageUrl(urlData.publicUrl)
      showToast({title: '图片上传成功', icon: 'success'})
    } catch (error) {
      console.error('上传图片失败:', error)
      showToast({title: '上传失败，请重试', icon: 'none'})
    } finally {
      setUploading(false)
    }
  }, [])

  // 选择图片
  const handleChooseImage = useCallback(async () => {
    try {
      const res = await chooseImage({
        count: 1,
        sizeType: ['compressed'],
        sourceType: ['album', 'camera']
      })

      if (res.tempFilePaths.length > 0) {
        await uploadImage(res.tempFilePaths[0])
      }
    } catch (error) {
      console.error('选择图片失败:', error)
      showToast({title: '选择图片失败', icon: 'none'})
    }
  }, [uploadImage])

  // 提交轮播图
  const handleSubmit = useCallback(async () => {
    if (!title.trim()) {
      showToast({title: '请输入标题', icon: 'none'})
      return
    }

    // 如果选择了链接类型，必须选择具体的资料或课程
    if (linkType === 'material' && !linkId) {
      showToast({title: '请选择要链接的资料', icon: 'none'})
      return
    }

    if (linkType === 'course' && !linkId) {
      showToast({title: '请选择要链接的课程', icon: 'none'})
      return
    }

    setSubmitting(true)
    try {
      const {error} = await supabase.from('banners').insert({
        title: title.trim(),
        image_url: imageUrl,
        link_type: linkType === 'none' ? null : linkType,
        link_id: linkType === 'none' ? null : linkId,
        sort_order: parseInt(sortOrder, 10) || 0,
        is_active: isActive
      })

      if (error) {
        console.error('创建轮播图失败:', error)
        showToast({title: '创建失败', icon: 'none'})
        return
      }

      showToast({title: '创建成功', icon: 'success'})
      setTimeout(() => {
        Taro.navigateBack()
      }, 1500)
    } catch (error) {
      console.error('提交失败:', error)
      showToast({title: '提交失败，请重试', icon: 'none'})
    } finally {
      setSubmitting(false)
    }
  }, [title, imageUrl, linkType, linkId, sortOrder, isActive])

  // 处理链接类型变化
  const handleLinkTypeChange = useCallback((e: any) => {
    const index = e.detail.value
    const types: Array<'none' | 'material' | 'course'> = ['none', 'material', 'course']
    const newType = types[index]
    setLinkType(newType)
    setLinkId('') // 重置链接ID
  }, [])

  // 处理资料选择
  const handleMaterialChange = useCallback(
    (e: any) => {
      const index = e.detail.value
      setSelectedMaterialIndex(index)
      if (materials[index]) {
        setLinkId(materials[index].id)
      }
    },
    [materials]
  )

  // 处理课程选择
  const handleCourseChange = useCallback(
    (e: any) => {
      const index = e.detail.value
      setSelectedCourseIndex(index)
      if (courses[index]) {
        setLinkId(courses[index].id)
      }
    },
    [courses]
  )

  const linkTypeOptions = ['不链接', '链接到资料', '链接到课程']
  const linkTypeIndex = linkType === 'none' ? 0 : linkType === 'material' ? 1 : 2

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        <View className="px-6 py-6">
          {/* 标题 */}
          <View className="mb-6">
            <Text className="text-sm font-bold text-foreground mb-2">
              标题 <Text className="text-destructive">*</Text>
            </Text>
            <View className="bg-input rounded-xl border border-border px-4 py-3">
              <Input
                className="w-full text-foreground"
                style={{padding: 0, border: 'none', background: 'transparent'}}
                placeholder="请输入轮播图标题"
                value={title}
                onInput={(e) => setTitle(e.detail.value)}
              />
            </View>
          </View>

          {/* 图片上传 */}
          <View className="mb-6">
            <Text className="text-sm font-bold text-foreground mb-2">轮播图图片（选填）</Text>
            {imageUrl ? (
              <View className="relative">
                <Image src={imageUrl} mode="aspectFill" className="w-full h-48 rounded-xl" />
                <View
                  className="absolute top-2 right-2 bg-destructive px-3 py-1 rounded-lg"
                  onClick={() => setImageUrl('')}>
                  <Text className="text-white text-xs">删除</Text>
                </View>
              </View>
            ) : (
              <View
                className="bg-secondary border-2 border-dashed border-border rounded-xl h-48 flex flex-col items-center justify-center"
                onClick={handleChooseImage}>
                <View className="i-mdi-cloud-upload text-5xl text-muted-foreground mb-2" />
                <Text className="text-muted-foreground text-sm">{uploading ? '上传中...' : '点击上传图片'}</Text>
              </View>
            )}
          </View>

          {/* 链接类型 */}
          <View className="mb-6">
            <Text className="text-sm font-bold text-foreground mb-2">链接类型</Text>
            <Picker mode="selector" range={linkTypeOptions} value={linkTypeIndex} onChange={handleLinkTypeChange}>
              <View className="bg-input rounded-xl border border-border px-4 py-3 flex items-center justify-between">
                <Text className="text-foreground">{linkTypeOptions[linkTypeIndex]}</Text>
                <View className="i-mdi-chevron-down text-xl text-muted-foreground" />
              </View>
            </Picker>
          </View>

          {/* 选择资料 */}
          {linkType === 'material' && materials.length > 0 && (
            <View className="mb-6">
              <Text className="text-sm font-bold text-foreground mb-2">
                选择资料 <Text className="text-destructive">*</Text>
              </Text>
              <Picker
                mode="selector"
                range={materials.map((m) => m.title)}
                value={selectedMaterialIndex}
                onChange={handleMaterialChange}>
                <View className="bg-input rounded-xl border border-border px-4 py-3 flex items-center justify-between">
                  <Text className="text-foreground">{materials[selectedMaterialIndex]?.title || '请选择资料'}</Text>
                  <View className="i-mdi-chevron-down text-xl text-muted-foreground" />
                </View>
              </Picker>
            </View>
          )}

          {/* 选择课程 */}
          {linkType === 'course' && courses.length > 0 && (
            <View className="mb-6">
              <Text className="text-sm font-bold text-foreground mb-2">
                选择课程 <Text className="text-destructive">*</Text>
              </Text>
              <Picker
                mode="selector"
                range={courses.map((c) => c.title)}
                value={selectedCourseIndex}
                onChange={handleCourseChange}>
                <View className="bg-input rounded-xl border border-border px-4 py-3 flex items-center justify-between">
                  <Text className="text-foreground">{courses[selectedCourseIndex]?.title || '请选择课程'}</Text>
                  <View className="i-mdi-chevron-down text-xl text-muted-foreground" />
                </View>
              </Picker>
            </View>
          )}

          {/* 排序 */}
          <View className="mb-6">
            <Text className="text-sm font-bold text-foreground mb-2">排序（数字越小越靠前）</Text>
            <View className="bg-input rounded-xl border border-border px-4 py-3">
              <Input
                className="w-full text-foreground"
                style={{padding: 0, border: 'none', background: 'transparent'}}
                type="number"
                placeholder="请输入排序数字"
                value={sortOrder}
                onInput={(e) => setSortOrder(e.detail.value)}
              />
            </View>
          </View>

          {/* 是否启用 */}
          <View className="mb-6">
            <View className="flex items-center justify-between bg-card rounded-xl p-4 border border-border">
              <Text className="text-sm font-bold text-foreground">是否启用</Text>
              <View className="flex items-center gap-3">
                <View
                  className={`px-4 py-2 rounded-lg ${isActive ? 'bg-accent' : 'bg-muted'}`}
                  onClick={() => setIsActive(true)}>
                  <Text className={`text-sm ${isActive ? 'text-white' : 'text-muted-foreground'}`}>启用</Text>
                </View>
                <View
                  className={`px-4 py-2 rounded-lg ${!isActive ? 'bg-muted' : 'bg-secondary'}`}
                  onClick={() => setIsActive(false)}>
                  <Text className={`text-sm ${!isActive ? 'text-foreground' : 'text-muted-foreground'}`}>禁用</Text>
                </View>
              </View>
            </View>
          </View>

          {/* 提交按钮 */}
          <Button
            className="w-full bg-primary text-white py-4 rounded-xl break-keep text-base mb-6"
            size="default"
            onClick={submitting ? undefined : handleSubmit}>
            {submitting ? '提交中...' : '创建轮播图'}
          </Button>
        </View>
      </ScrollView>

      {/* 底部导航栏 */}
      <View className="fixed bottom-0 left-0 right-0 bg-card border-t border-border safe-area-bottom">
        <View className="flex items-center justify-around py-3 px-6">
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.switchTab({url: '/pages/home/index'})}>
            <View className="i-mdi-home text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">首页</Text>
          </View>
          <View
            className="flex flex-col items-center gap-1"
            onClick={() => Taro.navigateTo({url: '/pages/admin/content/index'})}>
            <View className="i-mdi-cog text-2xl text-muted-foreground" />
            <Text className="text-xs text-muted-foreground">管理</Text>
          </View>
          <View className="flex flex-col items-center gap-1" onClick={() => Taro.navigateBack()}>
            <View className="i-mdi-arrow-left-circle text-2xl text-primary" />
            <Text className="text-xs text-primary">返回</Text>
          </View>
        </View>
      </View>
    </View>
  )
}
