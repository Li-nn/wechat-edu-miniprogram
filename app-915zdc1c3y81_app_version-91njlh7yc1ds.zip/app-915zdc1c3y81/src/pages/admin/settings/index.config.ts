export default {
  navigationBarTitleText: '系统设置'
}
