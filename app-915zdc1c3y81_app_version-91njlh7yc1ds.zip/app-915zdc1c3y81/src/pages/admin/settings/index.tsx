import {Button, Image, Input, ScrollView, Text, View} from '@tarojs/components'
import Taro, {chooseImage, showToast, useDidShow} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {supabase} from '@/client/supabase'
import {getSystemSettings, updateSystemSettings} from '@/db/api'
import {useUserStore} from '@/store/userStore'

export default function AdminSettings() {
  const [adminWechat, setAdminWechat] = useState('')
  const [qrCodeUrl, setQrCodeUrl] = useState('')
  const [uploading, setUploading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [loading, setLoading] = useState(true)
  const {user, isAdmin, loadUser} = useUserStore()

  useDidShow(() => {
    checkAuth()
  })

  const loadSettings = useCallback(async () => {
    setLoading(true)
    try {
      const settings = await getSystemSettings()
      if (settings) {
        setAdminWechat(settings.admin_wechat || '')
        setQrCodeUrl(settings.wechat_qr_code || '')
      }
    } catch (error) {
      console.error('加载设置失败:', error)
    } finally {
      setLoading(false)
    }
  }, [])

  const checkAuth = useCallback(async () => {
    await loadUser()
    if (!user || !isAdmin) {
      showToast({title: '无权限访问', icon: 'none'})
      setTimeout(() => {
        Taro.navigateBack()
      }, 1500)
      return
    }
    loadSettings()
  }, [user, isAdmin, loadUser, loadSettings])

  // 上传二维码
  const handleUploadQrCode = useCallback(async () => {
    try {
      const res = await chooseImage({
        count: 1,
        sizeType: ['compressed'],
        sourceType: ['album', 'camera']
      })

      if (res.tempFilePaths.length === 0) return

      setUploading(true)
      const filePath = res.tempFilePaths[0]
      const fileName = `wechat_qr_${Date.now()}.jpg`

      // 读取文件并上传到Supabase
      const fileSystemManager = Taro.getFileSystemManager()
      const fileData = fileSystemManager.readFileSync(filePath, 'base64') as string
      const buffer = Taro.base64ToArrayBuffer(fileData)
      const blob = new Blob([buffer], {type: 'image/jpeg'})

      const {error} = await supabase.storage.from('app-915zdc1c3y81_images').upload(fileName, blob, {
        contentType: 'image/jpeg',
        upsert: false
      })

      if (error) {
        console.error('上传二维码失败:', error)
        showToast({title: `上传失败: ${error.message}`, icon: 'none'})
        return
      }

      // 获取公开URL
      const {data: urlData} = supabase.storage.from('app-915zdc1c3y81_images').getPublicUrl(fileName)

      setQrCodeUrl(urlData.publicUrl)
      showToast({title: '二维码上传成功', icon: 'success'})
    } catch (err) {
      console.error('上传二维码异常:', err)
      showToast({title: '上传失败，请重试', icon: 'none'})
    } finally {
      setUploading(false)
    }
  }, [])

  // 提交设置
  const handleSubmit = useCallback(async () => {
    if (!adminWechat.trim()) {
      showToast({title: '请输入管理员微信号', icon: 'none'})
      return
    }

    setSubmitting(true)
    try {
      const success = await updateSystemSettings({
        admin_wechat: adminWechat,
        wechat_qr_code: qrCodeUrl
      })

      if (success) {
        showToast({title: '保存成功', icon: 'success'})
      } else {
        showToast({title: '保存失败', icon: 'none'})
      }
    } catch (error) {
      console.error('保存设置失败:', error)
      showToast({title: '保存失败，请重试', icon: 'none'})
    } finally {
      setSubmitting(false)
    }
  }, [adminWechat, qrCodeUrl])

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        <View className="px-6 py-8">
          {loading ? (
            <View className="flex flex-col items-center justify-center py-20">
              <Text className="text-muted-foreground">加载中...</Text>
            </View>
          ) : (
            <View className="bg-card rounded-2xl p-6 border border-border">
              <View className="flex items-center mb-6">
                <View className="i-mdi-cog text-4xl text-primary mr-3" />
                <Text className="text-2xl font-bold text-foreground">系统设置</Text>
              </View>

              {/* 管理员微信号 */}
              <View className="mb-6">
                <Text className="text-sm font-bold text-foreground mb-2">
                  管理员微信号 <Text className="text-destructive">*</Text>
                </Text>
                <View className="bg-input rounded-xl border border-border px-4 py-3">
                  <Input
                    className="w-full text-foreground"
                    style={{padding: 0, border: 'none', background: 'transparent'}}
                    placeholder="请输入管理员微信号"
                    value={adminWechat}
                    onInput={(e) => setAdminWechat(e.detail.value)}
                  />
                </View>
              </View>

              {/* 微信二维码 */}
              <View className="mb-6">
                <Text className="text-sm font-bold text-foreground mb-2">微信二维码（选填）</Text>
                {qrCodeUrl ? (
                  <View className="relative">
                    <View className="bg-white p-4 rounded-2xl border border-border">
                      <Image src={qrCodeUrl} mode="aspectFit" className="w-full h-64" />
                    </View>
                    <View
                      className="absolute top-2 right-2 bg-destructive px-3 py-1 rounded-lg"
                      onClick={() => setQrCodeUrl('')}>
                      <Text className="text-white text-xs">删除</Text>
                    </View>
                  </View>
                ) : (
                  <View
                    className="bg-secondary border-2 border-dashed border-border rounded-xl h-48 flex flex-col items-center justify-center"
                    onClick={handleUploadQrCode}>
                    <View className="i-mdi-qrcode text-5xl text-muted-foreground mb-2" />
                    <Text className="text-muted-foreground text-sm">{uploading ? '上传中...' : '点击上传二维码'}</Text>
                  </View>
                )}
              </View>

              {/* 提交按钮 */}
              <Button
                className="w-full bg-primary text-white py-4 rounded-xl break-keep text-base"
                size="default"
                onClick={submitting ? undefined : handleSubmit}>
                {submitting ? '保存中...' : '保存设置'}
              </Button>

              {/* 提示信息 */}
              <View className="bg-secondary rounded-xl p-4 mt-6">
                <View className="flex items-start">
                  <View className="i-mdi-information text-xl text-primary mr-2 mt-0.5" />
                  <View className="flex-1">
                    <Text className="text-sm text-muted-foreground leading-relaxed">
                      设置后，用户点击"微信咨询"时将看到您设置的微信号和二维码，方便用户添加客服微信。
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  )
}
