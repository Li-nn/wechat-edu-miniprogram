import {ScrollView, Text, View} from '@tarojs/components'
import Taro, {showToast, useDidShow} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {getStatistics} from '@/db/api'
import type {Statistics} from '@/db/types'
import {useUserStore} from '@/store/userStore'

export default function Admin() {
  const [stats, setStats] = useState<Statistics | null>(null)
  const {user, isAdmin, loadUser} = useUserStore()

  useDidShow(() => {
    checkAuth()
  })

  const loadStats = useCallback(async () => {
    const data = await getStatistics()
    setStats(data)
  }, [])

  const checkAuth = useCallback(async () => {
    await loadUser()
    if (!user || !isAdmin) {
      showToast({title: '无权限访问', icon: 'none'})
      Taro.navigateBack()
      return
    }
    loadStats()
  }, [user, isAdmin, loadUser, loadStats])

  const menuItems = [
    {
      icon: 'i-mdi-account-group',
      title: '用户管理',
      desc: '管理用户信息和权限',
      color: 'text-primary',
      url: '/pages/admin/users/index'
    },
    {
      icon: 'i-mdi-folder-edit',
      title: '内容管理',
      desc: '管理资料和课程',
      color: 'text-accent',
      url: '/pages/admin/content/index'
    },
    {
      icon: 'i-mdi-chart-line',
      title: '数据统计',
      desc: '查看平台数据统计',
      color: 'text-chart-3',
      url: '/pages/admin/statistics/index'
    },
    {
      icon: 'i-mdi-cog',
      title: '系统设置',
      desc: '设置管理员微信等信息',
      color: 'text-chart-4',
      url: '/pages/admin/settings/index'
    }
  ]

  return (
    <View className="min-h-screen bg-background">
      <ScrollView scrollY style={{height: '100vh', background: 'transparent'}}>
        {/* 顶部标题 */}
        <View className="bg-primary px-6 pt-12 pb-6 rounded-b-3xl mb-6">
          <Text className="text-white text-2xl font-bold mb-2">管理后台</Text>
          <Text className="text-white text-opacity-90 text-sm">欢迎回来，管理员</Text>
        </View>

        {/* 数据概览 */}
        {stats && (
          <View className="px-6 mb-6">
            <Text className="text-base font-bold text-foreground mb-4">数据概览</Text>
            <View className="grid grid-cols-2 gap-4">
              <View className="bg-gradient-card rounded-2xl p-5 border border-border">
                <View className="i-mdi-account-group text-3xl text-primary mb-2" />
                <Text className="text-2xl font-bold text-foreground mb-1">{stats.totalUsers}</Text>
                <Text className="text-xs text-muted-foreground">总用户数</Text>
              </View>
              <View className="bg-gradient-card rounded-2xl p-5 border border-border">
                <View className="i-mdi-file-document text-3xl text-accent mb-2" />
                <Text className="text-2xl font-bold text-foreground mb-1">{stats.totalMaterials}</Text>
                <Text className="text-xs text-muted-foreground">资料数量</Text>
              </View>
              <View className="bg-gradient-card rounded-2xl p-5 border border-border">
                <View className="i-mdi-video text-3xl text-chart-3 mb-2" />
                <Text className="text-2xl font-bold text-foreground mb-1">{stats.totalCourses}</Text>
                <Text className="text-xs text-muted-foreground">课程数量</Text>
              </View>
              <View className="bg-gradient-card rounded-2xl p-5 border border-border">
                <View className="i-mdi-download text-3xl text-chart-4 mb-2" />
                <Text className="text-2xl font-bold text-foreground mb-1">{stats.totalDownloads}</Text>
                <Text className="text-xs text-muted-foreground">总下载量</Text>
              </View>
            </View>
          </View>
        )}

        {/* 功能菜单 */}
        <View className="px-6 pb-6">
          <Text className="text-base font-bold text-foreground mb-4">管理功能</Text>
          <View className="flex flex-col gap-4">
            {menuItems.map((item, index) => (
              <View
                key={index}
                className="bg-card rounded-2xl p-5 border border-border flex items-center justify-between"
                onClick={() => Taro.navigateTo({url: item.url})}>
                <View className="flex items-center flex-1">
                  <View className={`w-12 h-12 bg-secondary rounded-xl flex items-center justify-center mr-4`}>
                    <View className={`${item.icon} text-2xl ${item.color}`} />
                  </View>
                  <View className="flex-1">
                    <Text className="text-base font-bold text-foreground mb-1">{item.title}</Text>
                    <Text className="text-xs text-muted-foreground">{item.desc}</Text>
                  </View>
                </View>
                <View className="i-mdi-chevron-right text-2xl text-muted-foreground" />
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  )
}
