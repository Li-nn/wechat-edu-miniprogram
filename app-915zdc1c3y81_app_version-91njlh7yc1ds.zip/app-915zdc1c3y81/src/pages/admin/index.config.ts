export default {
  navigationBarTitleText: '管理后台'
}
