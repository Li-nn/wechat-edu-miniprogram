import {supabase} from '@/client/supabase'
import type {
  Banner,
  Course,
  CourseCategory,
  ImageSearchRecord,
  Material,
  MaterialCategory,
  ParentContact,
  Profile,
  Statistics,
  SystemSettings
} from './types'

// ==================== 用户相关 ====================

// 获取当前用户信息
export async function getCurrentUser(): Promise<Profile | null> {
  const {
    data: {user}
  } = await supabase.auth.getUser()
  if (!user) return null

  const {data, error} = await supabase.from('profiles').select('*').eq('id', user.id).single()

  if (error) {
    console.error('获取用户信息失败:', error)
    return null
  }

  return data
}

// 获取所有用户（管理员）
export async function getAllUsers(): Promise<Profile[]> {
  const {data, error} = await supabase.from('profiles').select('*').order('created_at', {ascending: false})

  if (error) {
    console.error('获取用户列表失败:', error)
    return []
  }

  return data || []
}

// 更新用户角色
export async function updateUserRole(userId: string, role: 'user' | 'admin'): Promise<boolean> {
  const {error} = await supabase.from('profiles').update({role}).eq('id', userId)

  if (error) {
    console.error('更新用户角色失败:', error)
    return false
  }

  return true
}

// 更新用户手机号
export async function updateUserPhone(userId: string, phone: string): Promise<boolean> {
  const {error} = await supabase.from('profiles').update({phone}).eq('id', userId)

  if (error) {
    console.error('更新用户手机号失败:', error)
    return false
  }

  return true
}

// ==================== 积分系统相关 ====================

// 检查并发放每日登录奖励
export async function checkAndGrantDailyLogin(userId: string): Promise<{
  success: boolean
  message: string
  points: number
}> {
  const {data, error} = await supabase.rpc('check_and_grant_daily_login', {uid: userId})

  if (error) {
    console.error('检查每日登录奖励失败:', error)
    return {success: false, message: '操作失败', points: 0}
  }

  return data
}

// 发放分享积分
export async function grantSharePoints(userId: string): Promise<{
  success: boolean
  message: string
  points: number
}> {
  const {data, error} = await supabase.rpc('grant_share_points', {uid: userId})

  if (error) {
    console.error('发放分享积分失败:', error)
    return {success: false, message: '操作失败', points: 0}
  }

  return data
}

// 扣除下载积分
export async function deductDownloadPoints(
  userId: string,
  materialId: string
): Promise<{
  success: boolean
  message: string
  points_spent?: number
  remaining_points?: number
  current_points?: number
  required_points?: number
}> {
  const {data, error} = await supabase.rpc('deduct_download_points', {
    uid: userId,
    material_id_param: materialId
  })

  if (error) {
    console.error('扣除下载积分失败:', error)
    return {success: false, message: '操作失败'}
  }

  return data
}

// 获取用户积分记录
export async function getUserPointsRecords(userId: string): Promise<import('./types').PointsRecord[]> {
  const {data, error} = await supabase
    .from('points_records')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', {ascending: false})
    .limit(50)

  if (error) {
    console.error('获取积分记录失败:', error)
    return []
  }

  return data || []
}

// 获取今日积分汇总
export async function getTodayPointsSummary(userId: string): Promise<import('./types').DailyPointsSummary | null> {
  const today = new Date().toISOString().split('T')[0]
  const {data, error} = await supabase
    .from('daily_points_summary')
    .select('*')
    .eq('user_id', userId)
    .eq('date', today)
    .single()

  if (error) {
    if (error.code === 'PGRST116') {
      // 记录不存在
      return null
    }
    console.error('获取今日积分汇总失败:', error)
    return null
  }

  return data
}

// ==================== 轮播图相关 ====================

// 获取活跃的轮播图
export async function getActiveBanners(): Promise<Banner[]> {
  const {data, error} = await supabase
    .from('banners')
    .select('*')
    .eq('is_active', true)
    .order('sort_order', {ascending: true})

  if (error) {
    console.error('获取轮播图失败:', error)
    return []
  }

  return data || []
}

// 获取所有轮播图（管理员）
export async function getAllBanners(): Promise<Banner[]> {
  const {data, error} = await supabase.from('banners').select('*').order('sort_order', {ascending: true})

  if (error) {
    console.error('获取轮播图失败:', error)
    return []
  }

  return data || []
}

// 创建轮播图
export async function createBanner(banner: Omit<Banner, 'id' | 'created_at'>): Promise<Banner | null> {
  const {data, error} = await supabase.from('banners').insert(banner).select().single()

  if (error) {
    console.error('创建轮播图失败:', error)
    return null
  }

  return data
}

// 更新轮播图
export async function updateBanner(id: string, updates: Partial<Banner>): Promise<boolean> {
  const {error} = await supabase.from('banners').update(updates).eq('id', id)

  if (error) {
    console.error('更新轮播图失败:', error)
    return false
  }

  return true
}

// 删除轮播图
export async function deleteBanner(id: string): Promise<boolean> {
  const {error} = await supabase.from('banners').delete().eq('id', id)

  if (error) {
    console.error('删除轮播图失败:', error)
    return false
  }

  return true
}

// ==================== 资料分类相关 ====================

// 获取所有资料分类
export async function getMaterialCategories(): Promise<MaterialCategory[]> {
  const {data, error} = await supabase.from('material_categories').select('*').order('sort_order', {ascending: true})

  if (error) {
    console.error('获取资料分类失败:', error)
    return []
  }

  return data || []
}

// ==================== 学科分类相关 ====================

// 获取所有学科分类
export async function getSubjectCategories(): Promise<import('./types').SubjectCategory[]> {
  const {data, error} = await supabase.from('subject_categories').select('*').order('sort_order', {ascending: true})

  if (error) {
    console.error('获取学科分类失败:', error)
    return []
  }

  return data || []
}

// ==================== 资料相关 ====================

// 获取活跃的资料列表
export async function getActiveMaterials(categoryId?: string): Promise<Material[]> {
  let query = supabase.from('materials').select('*').eq('is_active', true)

  if (categoryId) {
    query = query.eq('category_id', categoryId)
  }

  const {data, error} = await query.order('created_at', {ascending: false})

  if (error) {
    console.error('获取资料列表失败:', error)
    return []
  }

  return data || []
}

// 获取最新资料（用于首页展示）
export async function getLatestMaterials(limit: number = 2): Promise<Material[]> {
  const {data, error} = await supabase
    .from('materials')
    .select('*')
    .eq('is_active', true)
    .order('created_at', {ascending: false})
    .limit(limit)

  if (error) {
    console.error('获取最新资料失败:', error)
    return []
  }

  return data || []
}

// 获取资料详情
export async function getMaterialById(id: string): Promise<Material | null> {
  const {data, error} = await supabase.from('materials').select('*').eq('id', id).single()

  if (error) {
    console.error('获取资料详情失败:', error)
    return null
  }

  return data
}

// 创建资料
export async function createMaterial(
  material: Omit<Material, 'id' | 'created_at' | 'download_count' | 'view_count'>
): Promise<Material | null> {
  const {data, error} = await supabase.from('materials').insert(material).select().single()

  if (error) {
    console.error('创建资料失败:', error)
    return null
  }

  return data
}

// 更新资料
export async function updateMaterial(id: string, updates: Partial<Material>): Promise<boolean> {
  const {error} = await supabase.from('materials').update(updates).eq('id', id)

  if (error) {
    console.error('更新资料失败:', error)
    return false
  }

  return true
}

// 删除资料
export async function deleteMaterial(id: string): Promise<boolean> {
  const {error} = await supabase.from('materials').delete().eq('id', id)

  if (error) {
    console.error('删除资料失败:', error)
    return false
  }

  return true
}

// 增加资料查看次数
export async function incrementMaterialView(id: string): Promise<boolean> {
  const {error} = await supabase.rpc('increment_material_view', {material_id: id})

  if (error) {
    // 如果RPC不存在，使用普通更新
    const material = await getMaterialById(id)
    if (material) {
      return updateMaterial(id, {view_count: material.view_count + 1})
    }
    return false
  }

  return true
}

// 增加资料下载次数
export async function incrementMaterialDownload(id: string): Promise<boolean> {
  const {error} = await supabase.rpc('increment_material_download', {material_id: id})

  if (error) {
    // 如果RPC不存在，使用普通更新
    const material = await getMaterialById(id)
    if (material) {
      return updateMaterial(id, {download_count: material.download_count + 1})
    }
    return false
  }

  return true
}

// ==================== 课程分类相关 ====================

// 获取所有课程分类
export async function getCourseCategories(): Promise<CourseCategory[]> {
  const {data, error} = await supabase.from('course_categories').select('*').order('sort_order', {ascending: true})

  if (error) {
    console.error('获取课程分类失败:', error)
    return []
  }

  return data || []
}

// ==================== 课程相关 ====================

// 获取活跃的课程列表
export async function getActiveCourses(categoryId?: string): Promise<Course[]> {
  let query = supabase.from('courses').select('*').eq('is_active', true)

  if (categoryId) {
    query = query.eq('category_id', categoryId)
  }

  const {data, error} = await query.order('created_at', {ascending: false})

  if (error) {
    console.error('获取课程列表失败:', error)
    return []
  }

  return data || []
}

// 获取最新课程（用于首页展示）
export async function getLatestCourses(limit: number = 2): Promise<Course[]> {
  const {data, error} = await supabase
    .from('courses')
    .select('*')
    .eq('is_active', true)
    .order('created_at', {ascending: false})
    .limit(limit)

  if (error) {
    console.error('获取最新课程失败:', error)
    return []
  }

  return data || []
}

// 获取课程详情
export async function getCourseById(id: string): Promise<Course | null> {
  const {data, error} = await supabase.from('courses').select('*').eq('id', id).single()

  if (error) {
    console.error('获取课程详情失败:', error)
    return null
  }

  return data
}

// 创建课程
export async function createCourse(course: Omit<Course, 'id' | 'created_at' | 'view_count'>): Promise<Course | null> {
  const {data, error} = await supabase.from('courses').insert(course).select().single()

  if (error) {
    console.error('创建课程失败:', error)
    return null
  }

  return data
}

// 更新课程
export async function updateCourse(id: string, updates: Partial<Course>): Promise<boolean> {
  const {error} = await supabase.from('courses').update(updates).eq('id', id)

  if (error) {
    console.error('更新课程失败:', error)
    return false
  }

  return true
}

// 删除课程
export async function deleteCourse(id: string): Promise<boolean> {
  const {error} = await supabase.from('courses').delete().eq('id', id)

  if (error) {
    console.error('删除课程失败:', error)
    return false
  }

  return true
}

// 增加课程观看次数
export async function incrementCourseView(id: string): Promise<boolean> {
  const {error} = await supabase.rpc('increment_course_view', {course_id: id})

  if (error) {
    // 如果RPC不存在，使用普通更新
    const course = await getCourseById(id)
    if (course) {
      return updateCourse(id, {view_count: course.view_count + 1})
    }
    return false
  }

  return true
}

// ==================== 用户行为记录 ====================

// 记录用户资料操作
export async function recordUserMaterial(userId: string, materialId: string, actionType: string): Promise<boolean> {
  const {error} = await supabase
    .from('user_materials')
    .insert({user_id: userId, material_id: materialId, action_type: actionType})

  if (error) {
    console.error('记录用户资料操作失败:', error)
    return false
  }

  return true
}

// 记录用户课程观看
export async function recordUserCourse(userId: string, courseId: string, watchDuration: number): Promise<boolean> {
  const {data: existing} = await supabase
    .from('user_courses')
    .select('*')
    .eq('user_id', userId)
    .eq('course_id', courseId)
    .single()

  if (existing) {
    const {error} = await supabase
      .from('user_courses')
      .update({watch_duration: watchDuration, updated_at: new Date().toISOString()})
      .eq('id', existing.id)

    if (error) {
      console.error('更新用户课程观看记录失败:', error)
      return false
    }
  } else {
    const {error} = await supabase
      .from('user_courses')
      .insert({user_id: userId, course_id: courseId, watch_duration: watchDuration})

    if (error) {
      console.error('创建用户课程观看记录失败:', error)
      return false
    }
  }

  return true
}

// 记录咨询
export async function recordConsultation(userId: string, type: string): Promise<boolean> {
  const {error} = await supabase.from('consultations').insert({user_id: userId, type})

  if (error) {
    console.error('记录咨询失败:', error)
    return false
  }

  return true
}

// ==================== 统计数据 ====================

// 获取统计数据
export async function getStatistics(): Promise<Statistics> {
  const [usersResult, materialsResult, coursesResult, downloadsResult, viewsResult] = await Promise.all([
    supabase.from('profiles').select('id', {count: 'exact', head: true}),
    supabase.from('materials').select('id', {count: 'exact', head: true}),
    supabase.from('courses').select('id', {count: 'exact', head: true}),
    supabase.from('user_materials').select('id', {count: 'exact', head: true}).eq('action_type', 'download'),
    supabase.from('user_materials').select('id', {count: 'exact', head: true}).eq('action_type', 'view')
  ])

  return {
    totalUsers: usersResult.count || 0,
    totalMaterials: materialsResult.count || 0,
    totalCourses: coursesResult.count || 0,
    totalDownloads: downloadsResult.count || 0,
    totalViews: viewsResult.count || 0
  }
}

// 获取用户留资数据（管理员）
export async function getUserLeads(): Promise<Profile[]> {
  const {data, error} = await supabase
    .from('profiles')
    .select('*')
    .not('phone', 'is', null)
    .order('created_at', {ascending: false})

  if (error) {
    console.error('获取用户留资数据失败:', error)
    return []
  }

  return data || []
}

// 搜索资料
export async function searchMaterials(keyword: string): Promise<Material[]> {
  if (!keyword.trim()) {
    return []
  }

  const {data, error} = await supabase
    .from('materials')
    .select('*')
    .eq('is_active', true)
    .or(`title.ilike.%${keyword}%,description.ilike.%${keyword}%`)
    .order('created_at', {ascending: false})

  if (error) {
    console.error('搜索资料失败:', error)
    return []
  }

  return data || []
}

// 搜索课程
export async function searchCourses(keyword: string): Promise<Course[]> {
  if (!keyword.trim()) {
    return []
  }

  const {data, error} = await supabase
    .from('courses')
    .select('*')
    .eq('is_active', true)
    .or(`title.ilike.%${keyword}%,description.ilike.%${keyword}%`)
    .order('created_at', {ascending: false})

  if (error) {
    console.error('搜索课程失败:', error)
    return []
  }

  return data || []
}

// ==================== 系统设置相关 ====================

// 获取系统设置
export async function getSystemSettings(): Promise<SystemSettings | null> {
  const {data, error} = await supabase.from('system_settings').select('*').limit(1).maybeSingle()

  if (error) {
    console.error('获取系统设置失败:', error)
    return null
  }

  return data
}

// 更新系统设置
export async function updateSystemSettings(settings: {
  admin_wechat?: string
  wechat_qr_code?: string
}): Promise<boolean> {
  // 先获取现有设置
  const existing = await getSystemSettings()

  if (existing) {
    // 更新现有记录
    const {error} = await supabase
      .from('system_settings')
      .update({
        ...settings,
        updated_at: new Date().toISOString()
      })
      .eq('id', existing.id)

    if (error) {
      console.error('更新系统设置失败:', error)
      return false
    }
  } else {
    // 创建新记录
    const {error} = await supabase.from('system_settings').insert({
      ...settings
    })

    if (error) {
      console.error('创建系统设置失败:', error)
      return false
    }
  }

  return true
}

// ==================== 家长留资相关 ====================

// 创建家长留资记录
export async function createParentContact(contact: {
  user_id?: string
  parent_name: string
  phone: string
  student_name?: string | null
  grade?: string | null
  notes?: string | null
}): Promise<boolean> {
  const {error} = await supabase.from('parent_contacts').insert({
    user_id: contact.user_id || null,
    parent_name: contact.parent_name,
    phone: contact.phone,
    student_name: contact.student_name || null,
    grade: contact.grade || null,
    notes: contact.notes || null,
    status: 'pending'
  })

  if (error) {
    console.error('创建家长留资失败:', error)
    return false
  }

  return true
}

// 获取所有家长留资记录（管理员）
export async function getAllParentContacts(): Promise<ParentContact[]> {
  const {data, error} = await supabase.from('parent_contacts').select('*').order('created_at', {ascending: false})

  if (error) {
    console.error('获取家长留资列表失败:', error)
    return []
  }

  return data || []
}

// 更新家长留资状态
export async function updateParentContactStatus(
  id: string,
  status: 'pending' | 'contacted' | 'completed'
): Promise<boolean> {
  const {error} = await supabase.from('parent_contacts').update({status}).eq('id', id)

  if (error) {
    console.error('更新家长留资状态失败:', error)
    return false
  }

  return true
}

// ==================== 图片搜题相关 ====================

// 检查每日图片搜题限制
export async function checkDailyImageSearchLimit(userId: string): Promise<{canUse: boolean; remaining: number}> {
  const today = new Date().toISOString().split('T')[0]

  const {data, error} = await supabase
    .from('daily_image_search_limits')
    .select('*')
    .eq('user_id', userId)
    .eq('date', today)
    .maybeSingle()

  if (error) {
    console.error('检查图片搜题限制失败:', error)
    return {canUse: false, remaining: 0}
  }

  const count = data?.count || 0
  const remaining = Math.max(0, 5 - count)

  return {
    canUse: count < 5,
    remaining
  }
}

// 创建图片搜题记录
export async function createImageSearchRecord(record: {
  user_id: string
  image_url: string
  answer?: string
}): Promise<boolean> {
  const today = new Date().toISOString().split('T')[0]

  // 创建搜题记录
  const {error: recordError} = await supabase.from('image_search_records').insert({
    user_id: record.user_id,
    image_url: record.image_url,
    answer: record.answer || null
  })

  if (recordError) {
    console.error('创建图片搜题记录失败:', recordError)
    return false
  }

  // 更新每日使用次数
  const {data: limitData} = await supabase
    .from('daily_image_search_limits')
    .select('*')
    .eq('user_id', record.user_id)
    .eq('date', today)
    .maybeSingle()

  if (limitData) {
    // 更新现有记录
    const {error: updateError} = await supabase
      .from('daily_image_search_limits')
      .update({count: limitData.count + 1})
      .eq('id', limitData.id)

    if (updateError) {
      console.error('更新图片搜题次数失败:', updateError)
      return false
    }
  } else {
    // 创建新记录
    const {error: insertError} = await supabase.from('daily_image_search_limits').insert({
      user_id: record.user_id,
      date: today,
      count: 1
    })

    if (insertError) {
      console.error('创建图片搜题次数记录失败:', insertError)
      return false
    }
  }

  return true
}

// 获取用户的图片搜题历史
export async function getUserImageSearchRecords(userId: string): Promise<ImageSearchRecord[]> {
  const {data, error} = await supabase
    .from('image_search_records')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', {ascending: false})

  if (error) {
    console.error('获取图片搜题历史失败:', error)
    return []
  }

  return data || []
}

// 扣除积分（用于图片搜题）
export async function deductPoints(userId: string, amount: number, reason: string): Promise<boolean> {
  const {error} = await supabase.rpc('deduct_user_points', {
    p_user_id: userId,
    p_amount: amount,
    p_reason: reason
  })

  if (error) {
    console.error('扣除积分失败:', error)
    return false
  }

  return true
}
