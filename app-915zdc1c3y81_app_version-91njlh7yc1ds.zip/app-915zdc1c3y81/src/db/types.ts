// 用户角色类型
export type UserRole = 'user' | 'admin'

// 用户信息
export interface Profile {
  id: string
  username: string | null
  phone: string | null
  openid: string | null
  nickname: string | null
  avatar: string | null
  role: UserRole
  points: number
  created_at: string
}

// 积分变动记录
export interface PointsRecord {
  id: string
  user_id: string
  change_type: 'earn' | 'spend'
  amount: number
  reason: 'daily_login' | 'share' | 'download'
  created_at: string
}

// 每日积分汇总
export interface DailyPointsSummary {
  id: string
  user_id: string
  date: string
  earned_today: number
  has_daily_login: boolean
  created_at: string
}

// 轮播图
export interface Banner {
  id: string
  title: string
  image_url: string
  link_type: string | null
  link_url: string | null
  link_id: string | null
  sort_order: number
  is_active: boolean
  created_at: string
}

// 资料分类
export interface MaterialCategory {
  id: string
  name: string
  parent_id: string | null
  sort_order: number
  created_at: string
}

// 学科分类
export interface SubjectCategory {
  id: string
  name: string
  sort_order: number
  created_at: string
}

// 资料
export interface Material {
  id: string
  title: string
  description: string | null
  cover_image: string | null
  file_url: string | null
  file_type: string
  category_id: string | null
  subject_id: string | null
  download_count: number
  view_count: number
  is_active: boolean
  created_at: string
}

// 课程分类
export interface CourseCategory {
  id: string
  name: string
  type: string
  sort_order: number
  created_at: string
}

// 课程
export interface Course {
  id: string
  title: string
  description: string | null
  cover_image: string | null
  video_url: string
  preview_duration: number
  total_duration: number
  category_id: string | null
  subject_id: string | null
  price: number
  view_count: number
  is_active: boolean
  created_at: string
}

// 用户资料记录
export interface UserMaterial {
  id: string
  user_id: string
  material_id: string
  action_type: string
  created_at: string
}

// 用户课程记录
export interface UserCourse {
  id: string
  user_id: string
  course_id: string
  watch_duration: number
  is_purchased: boolean
  created_at: string
  updated_at: string
}

// 咨询记录
export interface Consultation {
  id: string
  user_id: string
  type: string
  created_at: string
}

// 统计数据
export interface Statistics {
  totalUsers: number
  totalMaterials: number
  totalCourses: number
  totalDownloads: number
  totalViews: number
}

// 系统设置
export interface SystemSettings {
  id: string
  admin_wechat: string | null
  wechat_qr_code: string | null
  created_at: string
  updated_at: string
}

// 家长留资
export interface ParentContact {
  id: string
  user_id: string | null
  parent_name: string
  phone: string
  student_name: string | null
  grade: string | null
  notes: string | null
  status: 'pending' | 'contacted' | 'completed'
  created_at: string
}

// 图片搜题记录
export interface ImageSearchRecord {
  id: string
  user_id: string
  image_url: string
  answer: string | null
  created_at: string
}

// 每日图片搜题限制
export interface DailyImageSearchLimit {
  id: string
  user_id: string
  date: string
  count: number
  created_at: string
}
