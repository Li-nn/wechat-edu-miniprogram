import {create} from 'zustand'
import {supabase} from '@/client/supabase'
import {getCurrentUser} from '@/db/api'
import type {Profile} from '@/db/types'

interface UserState {
  user: Profile | null
  loading: boolean
  isAdmin: boolean
  setUser: (user: Profile | null) => void
  loadUser: () => Promise<void>
  logout: () => Promise<void>
}

export const useUserStore = create<UserState>((set) => ({
  user: null,
  loading: true,
  isAdmin: false,

  setUser: (user) =>
    set({
      user,
      isAdmin: user?.role === 'admin',
      loading: false
    }),

  loadUser: async () => {
    set({loading: true})
    const user = await getCurrentUser()
    set({
      user,
      isAdmin: user?.role === 'admin',
      loading: false
    })
  },

  logout: async () => {
    await supabase.auth.signOut()
    set({user: null, isAdmin: false, loading: false})
  }
}))
